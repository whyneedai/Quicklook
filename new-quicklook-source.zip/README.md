# new-quicklook

Rust / Win32 原生 Windows 11 文件预览 Demo，现有 69 个格式组件。**Markdown 显示渲染结果**，Python 显示源码与高亮，PNG/JPEG/GIF/WebP/BMP/ICO 按窗口缩小显示，GIF/WebP 支持有界动画。没有 WebView、.NET、Electron 或额外图片运行库。独立实现，未复制 QuickLook 上游代码。

## 运行

完整验证通过后，项目根目录 `new-quicklook.exe` 是主程序；公式预览需随带 `worker/math-worker.exe`，PDF 预览需随带 `worker/pdf-worker.exe`，保持相对目录。缺少 Worker 时公式保留 LaTeX 原文，其他格式仍可用。开发产物位于 `target\x86_64-pc-windows-msvc\release\new-quicklook.exe`。

1. 双击 `new-quicklook.exe`，程序进入托盘。
2. 在 Windows 文件资源管理器中选中一个本地或 WSL Linux 节点下的支持文件（`.md`、`.py`、`.rs`、`.pdf`、`.png`、`.jpg/.jpeg`、`.gif`、`.webp`、`.bmp`、`.ico`、`.ps1/.cmd/.bat`、`.rb/.cs/.mjs/.scss/.zsh/.svg/.proto/.tf`、`.tex/.sty/.bib`（LaTeX **只做源码预览，不编译**）等，及 [新增 55 种文本/源码扩展名](docs/FORMATS.md)），按空格。
3. Esc / Space 关闭预览，P 或 PIN 按钮切换置顶；拖动标题区域移动，拖动边缘缩放。M 切换组件支持的模式（Markdown、CSV/TSV：渲染/源码，默认渲染）。
4. 滚动用鼠标滚轮与滚动条（滚动不依赖键盘，无方向键滚动）；拖动选中文字，Ctrl+A 全选，Ctrl+C 复制。预览打开后，一维列表用上下键，二维图标网格用四向键（左右支持跨行），切换保持窗口位置与尺寸。焦点默认留在 Explorer；Space/Esc 无需点击即可关闭。切到其他窗口或预览被盖住后，键盘不会影响旧预览。
5. 图片用滚轮缩放、放大后左键拖拽平移、双击复位；缩放使用已有预览像素，不增加原图解码内存。
6. PDF 在预览内用滚轮翻页、Ctrl+滚轮缩放，页码常显；暂不支持文字选择/搜索。系统接口与限额见 [PDF.md](docs/PDF.md)。
7. 右键托盘图标选择退出；也可执行 `new-quicklook.exe --quit`。

支持把文件拖到 exe 上或命令行直接传入路径，这种独立预览关闭后退出进程：

```powershell
.\new-quicklook.exe .\samples\welcome.md
.\new-quicklook.exe .\samples\hello.py
.\new-quicklook.exe .\samples\gradient.png
```

Demo 不设置自启动、文件关联或全局快捷键配置。如果已有其他空格预览程序运行，需由用户选择退出其中一个，避免键盘钩子争用。本项目不会修改或终止它们。

## 仓库内容说明

仓库只包含**源码、构建/测试脚本、样例夹具与面向用户的文档**。以下内容有意不提交（均保留在本地工作区）：

| 不提交的内容 | 位置 | 原因 |
|---|---|---|
| 验证证据（截图、日志、JSON 报告） | `artifacts/` | 每次运行都会重新生成 |
| 内部工程记录与交接 | `AGENTS.md`、`NEXT.md`、`mathworker.md`、`docs/HANDOFF.md`、`docs/VALIDATION.md`、`docs/MATH-BOUNDARY.md`、`docs/TEXT-LAYOUT.md`、`docs/IMAGE-WIC.md` | 过程性材料，非使用所需 |
| 一次性探针 crate | `archive/` | 实验代码，不参与构建 |
| 构建产物 | `new-quicklook.exe`、`worker/*.exe`、`target/` | 由 `scripts\check.cmd` 生成 |

运行 `scripts\check.cmd` 即可从源码重建全部产物。源码上传副本与旧历史隔离方法见 [源码分发准备](docs/SOURCE-DISTRIBUTION.md)。

## 构建与验证

**前置条件**（Windows 10/11 x64）：

- Rust stable 的 MSVC 工具链（`rustup default stable-x86_64-pc-windows-msvc`）；
- Visual Studio 或 Build Tools，含 **“使用 C++ 的桌面开发”** 工作负载（`crates/app/build.rs` 需要 `rc.exe` 编译图标资源）。安装位置由 `scripts\env.cmd` 通过 `vswhere` 自动发现；特殊情况可用 `set QL_VCVARS=<vcvars64.bat 完整路径>` 覆盖；
- 首次构建需要网络，之后依赖由 `Cargo.lock` 固定。

在仓库根目录运行（Windows cmd/PowerShell，或从 WSL 调用 Windows `cmd.exe`）：

```bat
scripts\check.cmd
scripts\cargo.cmd build --release --locked
powershell -NoProfile -ExecutionPolicy Bypass -File scripts\architecture.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File scripts\smoke.ps1 -Capture
powershell -NoProfile -ExecutionPolicy Bypass -File scripts\interaction.ps1
```

`check.cmd` 先按完整路径退出本仓库内的旧进程（不操作其他 QuickLook 程序），成功后同步主 exe 与 worker；它顺序执行 fmt 检查、Windows 单元/集成/属性测试、架构检查、Clippy `-D warnings`、release 构建。`env.cmd` 把 `CARGO_HOME`/`TEMP` 放在仓库 `.cache` 下，且只影响当前命令行进程；`.cargo/config.toml` 固定目标与静态 CRT，若网络受限可按其中的注释启用 crates.io 镜像。

`interaction.ps1` 会临时打开项目 samples 的 Explorer 窗口并模拟键盘输入；运行期间请不要操作键盘。它只取消项目样例的重命名编辑，不提交任何改名，并退出自己启动的应用/Explorer 窗口。截图与探针 JSON 写入 `artifacts`；详细可信结果记录在本地 `docs/VALIDATION.md`（不随仓库发布）。

预览文本默认 900×680 逻辑像素；图片不小于文本尺寸，按需增大。窗口验收运行 `window-placement.ps1`，使用真实 Explorer 与键鼠。

此前三项已完成：方向键导航与前台隔离、WSL 文件预览、源码高亮层次与克制配色。完整验收记录在本地 `docs/VALIDATION.md`，本地四文件截图、配色理由和性能对比见 [SYNTAX-COLORS](docs/SYNTAX-COLORS.md)。

通用进程/协议与交付清单见 [WORKERS.md](docs/WORKERS.md)。

## 测试指引（给后续 AI/接手者）

**总原则**

- Windows 构建与 GUI 测试为准；WSL 负责编辑，也能直接跑不依赖桌面的探针（如 `python3 scripts/math-corpus.py`、`cargo fmt --all -- --check`）。
- 脚本存在不等于执行通过：只认 `artifacts/` 里的日志与 JSON，并且 **`error` 与首帧字段必须一起看**；退出码 0 不代表预览成功。
- 先分清「产品错」与「环境抖动」：脚本失败时先看报告里的 `shell_resolution`/`file_name`/`error`。若报告显示 `selected_count=1; resolved=<预期文件>; error=false`，只是就绪慢（扫描/焦点），不是产品 bug。

**测试分层（按顺序跑）**

1. 无头/编译层：`scripts\check.cmd`（fmt、87 项测试：app 13/core 8/display 20/engine 22/render 24、五 crate 依赖、Clippy `-D warnings`、release，并复制主 exe 与 worker）；`scripts\architecture.ps1`；`scripts\pe-audit.cmd`。
2. 单进程探针（无需交互桌面）：`smoke.ps1 -Capture`（md/py/rs/png/损坏 PNG/截断大文本/空闲）、`source-formats.ps1`（55）、`image-formats.ps1`（23）、`math-corpus.py`（120 渲染 + 7 结构拒绝 + 7 旧白名单命令渲染，WSL 可直接跑）。
   - PDF：`python scripts/pdf-fixtures.py` 后运行 `scripts\pdf-preview.ps1`（7 条 smoke + 真实 Explorer/滚轮/切文件/worker 生命周期）和 `scripts\pdf-failures.ps1`（缺失、超时、坏协议、错握手、坏页图）。
3. 真实 Explorer + 真键盘（需要干净桌面，运行期间不要碰键盘）：
   - `restart-preview.ps1 -Rounds 4 -Label <label>`：每轮覆盖 hello.py / gradient.png / welcome.md / **NONE（空选）** / **MULTI（多选）** / hello.rs，后两者必须**不**打开任何预览窗；
   - 同脚本 `-IssueImages`（从入库样例生成三个图片夹具）、`-Mouse`（真实鼠标点选后再按空格）；
   - `restart-tabs.ps1 -Rounds 4 -Label <label>`：双标签交替 24 步；
   - `scroll-rebuild.ps1`：真实滚动条拖到中部 → 右边缘一次拖宽，实际 partial 绘制帧保留 scroll 意图，完成后的位置/滚动条正确；布局说明见本地 `docs/TEXT-LAYOUT.md`。
   - `window-placement.ps1`：真实 Explorer/键鼠检查 900×680 DIP、图片下限/增长、拖宽与环境变量覆盖。
   - `raise-preview.ps1`：真实 Z 序覆盖 → 同文件 Space 只抬升（代次/哈希/排版/滚动/几何不变）→ 再按关闭；改选其他文件正常切换；其他根窗口/同根另一标签页 Space 隔离。
   - `wsl-preview.ps1`：两种 WSL UNC 的文本/代码/公式/PNG/截断大文本与 sha256sum 对拍、可读错误、真实 Linux 节点点击 + Space；夹具生成于 Linux /tmp，证据 wsl-preview-results.json；
   - `freshness.ps1`：40 次同扩展名切换 + 独立 FNV 正文哈希（识别“显示上一个文件”）；
   - `stale-math.ps1`：公式 Pending 时切文件 6 次，晚到结果不得污染新内容；
   - `interaction.ps1 -Rounds 10 -Layout -Navigation`：方向键导航、地址栏/重命名空格透传、布局缓存；`-Features` 另含合成拖选复制（见下）。
4. 交付核对：`verify-delivery.ps1`（旧进程为 0、根目录与 release 哈希一致、拉起唯一常驻、未提前启动 worker）。

**跑 GUI 测试前必须做的环境准备**

- 退出所有 `new-quicklook.exe` 实例（`freshness.ps1`/`interaction.ps1` 见到已开实例会直接 throw）；用 `scripts\stop-project.ps1` 按**完整可执行路径**清理，绝不按名字杀本仓库之外的程序。
- **记录 Shell 窗口基线**：跑前 `(New-Object -ComObject Shell.Application).Windows().Count`，跑后若多出本仓库的窗口就清理（`$w.Quit()`，标签页窗口常不响应，必要时对 HWND 发 `WM_CLOSE`）。
- 残留窗口会自我放大：窗口越多，每次空格解析选区越慢（实测约 **35ms/窗口**），越容易超出脚本等待，再留下更多窗口。先清理再测，失败率会大幅下降。
- GUI 脚本会抢占前台/焦点，请在机器空闲时跑。

**已知脆弱点与判读（避免假失败）**

- `restart-preview.ps1`/`restart-tabs.ps1` 已从“固定 350ms 等待”改为**轮询报告文件（最多 2.5s）**；若仍超时，按上文的 `shell_resolution` 判读，不要直接判定产品回归。
- `restart-preview.ps1 -Mouse` 依赖 UIA 坐标与前台焦点，抢焦点时会报 “Real mouse selection mismatch expected=… selected=…”（此时还没按空格），属合成输入问题，重试通常通过。
- `interaction.ps1 -Features` 的“合成拖选复制”偶发拖选不全（`did not copy` / `selection is incorrect`），与 Shell/预览逻辑无关；用不带 `-Features` 的 `-Layout -Navigation` 覆盖导航与真键盘路径，并把它当已知脆弱步骤。
- 脚本抛异常时结果文件可能只写到中断那一步（`finally` 语义），不要据此判断“整体没跑”。
- 断言口径：`first_content_paint_ms` 是空格→内容 EndPaint；`math_paint_ms` 是到公式全部就绪/回退；`paint_ms` 只是单次 GDI 绘制，不能替代前两者。

**诊断哈希口径**

`content_hash` 为送入 engine 的原始输入 SHA-256；`content_hash_bytes`/`content_hash_scope` 明确全文或有界前缀（大文本仍最多 256 KiB）。`body_hash` 是呈现正文 FNV-1a，供 freshness/stale-math 校验显示身份；两者用途不同。只有 --smoke/--trace 计算输入 SHA-256。

**改动后跑哪些**

- 动 Shell 选区/窗口行为：`check.cmd` + `restart-preview`（默认/IssueImages/Mouse）+ `restart-tabs` + `freshness`。
- 动提示浮窗：`check.cmd` + `scripts/overlay-keys.ps1 -Label overlay-after`；必须确认方向键切换后在预览内移动鼠标、首次 Space/Esc、真实行中心悬停至少 1500ms、无相交可见提示、关闭后同一行提示恢复及 `infotips_hidden>0`。脚本自建窄露出区域，不点击悬停行，并记录鼠标干扰；探针与应用使用相同遮挡排除表。
- 动键盘/导航：`check.cmd` + `scripts/navigation.ps1`（真实点击选区；一维上下、二维四向/两种跨行、切换几何、点击预览后继续导航、Space/Esc/P、其他前台与遮挡隔离；navigation-results.json 必须 success=true）；预览不抢焦点，所以复制正文前要先点一下预览窗口（`math-lifecycle.ps1` 已如此）。
- 动窗口定位/尺寸：`QUICKLOOK_WINDOW=WxH` 可覆盖文本默认尺寸（诊断/偏好）；`check.cmd`（含 `native::action::placement_tests` 单测）+ `scripts/window-placement.ps1`（真实预览后校验居中/自适应尺寸/可手动缩放；脚本自身要 DPI 感知，否则坐标被虚拟化）。
- 动选择/鼠标：`check.cmd` + `scripts/word-select.ps1`（真实双击：英文词、双引号内整体、中文词典词、标识符；以及单击拖动），样本 `samples/word-select.md`。GUI 脚本需要能抢到前台（若 Firefox/DSH 窗口持有前台，`interaction.ps1` 会因前台锁失败，属环境问题）。
- 动图标：源图是 `icon.ico`（多尺寸，画稿不变），`python3 scripts/make-icon.py` 无损重打包成 `crates/app/assets/app.ico`（PNG 压缩 7 档，117KB→30KB），`icon.png` 是 256 档预览；再跑 `scripts/icon-audit.ps1`。旧流程：替换 `crates/app/assets/app.ico`（**必须保持 PNG 压缩的 7 档 16/24/32/48/64/128/256**，否则 EXE 会白涨几十 KB），再跑 `check.cmd` 并用 `ExtractIconExW` 对比取出的图标与源文件像素；资源由 `crates/app/build.rs` 用 `rc.exe` 编译，必须通过 `scripts/cargo.cmd` 构建。
- 动文本排版：`new-quicklook.exe --smoke <文件> <报告>` 读 `load_ms`/`layout_ms`/`layout_measure_ms`/`draw_ms`/`layout_complete`/`layout_extensions`（多语言性能调查与增量排版见 docs/TEXT-LAYOUT.md；`QUICKLOOK_FULL_LAYOUT=1` 强制一次成型对比），再跑 `smoke.ps1` 与 `interaction.ps1 -Rounds 2 -Layout`；
- 动公式：`check.cmd` + `math-corpus.py`（120 渲染 + 结构拒绝 + 命令覆盖）+ `math-crops.py`（逐像素无损对照）+ `math-lifecycle.ps1`（需无常驻实例；脚本会重试并打印 owner 诊断）+ `math-failures.ps1` + `stale-math.ps1`。
- 动源码角色/配色：`check.cmd` + `source-formats.ps1` + `smoke.ps1 -Capture`；修改前后分别跑 `highlight-review.ps1 -Phase before|after -Runs 20`，核对同输入、DPI/窗口与首帧/layout 时序，见 [源码配色说明](docs/SYNTAX-COLORS.md)。
- 动排版/绘制：`smoke.ps1 -Capture` + `interaction.ps1 -Layout -Navigation`。
- **新增文本格式**：按“一扩展名一文件 + 本地 RULES”加组件 → 更新 `text::components()`、engine 契约清单与组件总数断言 → 加 `samples/formats/example.<ext>` 与 `source-formats.ps1` 清单 → 跑 `check.cmd` + `source-formats.ps1`（每一项都要 SOURCE/行号/无 error/首帧）→ 同步 FORMATS/README 计数。
- 任何 release 交付前：`check.cmd` → `verify-delivery.ps1`。

**当前交付基线（改动后需同步更新）**

- 最新质量门：原目录与含空格的新源码目录均通过 `scripts\check.cmd`（各 87 项全绿）；新目录的 17 组格式/真实 Explorer/WSL/PDF/故障回归通过，旧窗口基线恢复。源码目录不含预制 exe、缓存或内部记录；验证副本的首次依赖下载使用上述可选镜像。日志与 JSON 仅保存在本地 `artifacts/`，以下哈希由 `verify-delivery.ps1` 产出。
- `new-quicklook.exe`：1,122,304 bytes，SHA-256 `46FD329124871C3F8904852B50DB0CAAE917B23C12444769619B5B20F88D391C`。
- `worker\math-worker.exe`：239,616 bytes，SHA-256 `E026E79158B1E604C00167B0EE942943162B4F41CE09B2F9CF56378C156094A7`。
- `worker\pdf-worker.exe`：243,200 bytes，SHA-256 `2C1FBC738520850D8BB3D323CAE96EC98815F3EA1AD21CB803E11A3C43D083C6`。

## 实现范围

| 内容 | 首版行为 |
|---|---|
| Markdown | CommonMark 标题、段落、列表、引用、粗体、斜体、分隔线、行内代码、代码块；默认渲染模式不显示行号或 Markdown 标记；M 可切换有行号的源码模式 |
| Python / Rust | 源行号、关键字/字符串/注释/数字及类型/函数/常量/属性词法层次；克制深色配色，保留 Unicode，Tab 展开 4 空格 |
| 文本/配置/其他源码 | 新增 55 个独立扩展名组件；行号、基本词法高亮、选择复制；JSON/XML/HTML/SVG 为源码文本视图；CSV/TSV 默认按列对齐，M 可看源码；PowerShell/批处理/Ruby/C#/JS 变体/SCSS/Less/Zsh/Protobuf/HCL/字幕等按各自规则着色 |
| PNG | WIC 优先（含 **Adam7 交错**、调色板/灰度/16bit）；非交错且 >200 万像素回退有界扫描行解码；按比例缩小并显示透明棋盘背景；窗口改变大小后重建预览 |
| JPEG/JPG/JFIF、BMP、ICO、TIFF、DDS、CUR、HEIF | WIC 系统 codec，生成有界缩略图；ICO 选最大内嵌图像；CUR 复用 ICO 解码器；DDS 需 DXT/BC 压缩系；HEIC/HEIF/AVIF 依赖系统扩展 |
| PDF | 系统 Windows.Data.Pdf 独立 worker；显示/滚轮翻页，Ctrl+滚轮缩放，无文字选择/搜索 |
| GIF / WebP | Rust 解码；动画循环、帧延迟与透明背景，受帧数/像素/缓存限额约束 |
| 窗口 | 原生暗色无标题栏框架、DWM 圆角、置顶、移动、调整尺寸、键盘关闭、鼠标滚动与交互滚动条 |
| 文件选择 | 低级键盘钩子 + 前台 Explorer 的 IShellWindows / IShellBrowser / IFolderView2 |

Markdown 不使用浏览器；原始 HTML 被忽略，链接仅显示文字，不执行脚本、打开网址或加载图片。Markdown 数学公式由独立 RichEdit Worker 异步渲染，支持常用分式/根式/上下标/积分/求和，失败保留 LaTeX；不支持完整 TeX。GFM 表格、图片嵌入和完整排版保真不在本 Demo 范围内。源码高亮是轻量词法处理，不是完整语法解析器。

文本最多读 256 KiB、最多 6000 行/块、每行 2000 字符；截断会在内容区显示提示（release 也保留）。文本按内容/宽度/DPI 缓存排版，滚动只绘制可见片段。PNG 输入最多 32 MiB，边长不超过 32768，总像素不超过 100M；预览画布不超过 1600×1200。**Adam7 交错 PNG 由 WIC 解码**（不再拒绝）；非交错大图走有界扫描行解码（实测 4096×3072 比 WIC 快 27%、省约 7MB），WIC 失败时回退扫描行。超预算文件和损坏文件显示错误。APNG 仅首帧，不播放动画。小图默认保持原尺寸上限。GIF 最终画布最多 800×600；GIF/WebP 动画最多 300 帧、64 MiB 最终帧缓存。用户批准 WebP 原尺寸缓冲例外：最多 400 万像素、64 MiB 解码预算；库内 scratch 限额并非硬保证，缩小后释放原图。JPEG 的 EXIF 旋转和 ICC 色彩管理尚未实现。

支持普通 Explorer 文件窗口和单个常规文件，包括 `\\wsl.localhost\<发行版>\...` / `\\wsl$\<发行版>\...` 的 Linux 文件；普通网络 UNC 仍拒绝。WSL 发行版/路径不可用或权限不足会显示可读错误；桌面、第三方文件管理器、对话框、多选、虚拟项目和在线占位文件不支持。窗口在打开时靠近选中位置，无法取坐标时靠近 Explorer；预览打开时用方向键同步原 Explorer 选区并切换文件；一维上下、二维四向/两种横向跨行及前台隔离已有真实键鼠证据，多屏/分组视图组合仍待验证。

## 架构与接手

```text
app（行为/有界读取） → engine（注册与调度） → render（模型生成）
           ↓                  ↓                  ↓
        display ───────────→ core ←───────────────┘
        （呈现）           （零依赖契约/模型）
```

五个 crate 的内部依赖是 `render→core`、`engine→core+render`、`display→core`、`app→core+engine+display`。组件以 FormatPreview 自报 id、扩展名、魔数、模式和限额；前端不直接依赖具体渲染模块。简单/安全的格式随主程序构建；重型格式采用独立 worker，通用机制见 [WORKERS](docs/WORKERS.md)，PDF 见 [PDF](docs/PDF.md)。读取和解析在 app 的后台线程，engine 本身不访问文件或窗口。文本/图片解析仍在主进程，没有进程崩溃隔离/硬超时；公式/PDF Worker 有 Job 资源限制及请求超时，但不等于完整安全沙箱。

原始 icon.png 已转换为多尺寸 ICO 并作为同一 PE 资源用于 exe、窗口和托盘。release 默认隐藏左下角诊断状态；debug、--trace 和 --smoke 保留测量信息。新的 exe 预算为理想 ≤10MB、可接受 ≤25MB、硬上限 ≤40MB；功能完整优先；公开格式、资源限额和 worker 契约见上面的文档索引。

配色索引：[源码配色、四文件前后截图与同机性能](docs/SYNTAX-COLORS.md)。

仅在相同条件下测得的结果可用于与其他预览软件比较。

## 参考

- [QL-Win/QuickLook](https://github.com/QL-Win/QuickLook)：对标项目；不把用户给出的历史技术栈、星数和内存数当成当前测量结果。
- [Windows 低级键盘钩子](https://learn.microsoft.com/en-us/windows/win32/winmsg/lowlevelkeyboardproc)：钩子专用线程及时返回。
- [IFolderView2](https://learn.microsoft.com/en-us/windows/win32/api/shobjidl_core/nn-shobjidl_core-ifolderview2)：当前 Shell 视图与选择。
- [png Reader](https://docs.rs/png/latest/png/struct.Reader.html)：扫描行解码接口。
- [pulldown-cmark](https://docs.rs/pulldown-cmark/latest/pulldown_cmark/)：CommonMark 事件解析。

本项目尚未选定发布许可证；发布前由所有者确认，并按 Cargo.lock 中依赖许可随包附带第三方声明。

公式接口、兼容范围和复验见 [MATH.md](docs/MATH.md)；PNG/GIF/WebP 与 WIC 的对照数据与切换决定见本地 `docs/IMAGE-WIC.md`。CSV/TSV 表格最多 1000 行、32 列、每格 256 字符；截断提示可见，M 源码模式仍保留原有 256 KiB 有界文本查看能力。窄窗口中长单元格换行，极窄列可能裁剪，调整窗口或切源码查看。
