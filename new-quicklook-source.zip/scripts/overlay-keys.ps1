﻿param([switch]$Baseline,[string]$Label='overlay',[string]$Exe='')
$repo = Split-Path $PSScriptRoot -Parent
. "$PSScriptRoot\process-args.ps1"
if(-not $Exe){$Exe="$repo\new-quicklook.exe"}

$ErrorActionPreference='Stop'
Set-Location $repo
. "$PSScriptRoot\gui-test.ps1"
. "$PSScriptRoot\preview-windows.ps1"
if((Get-PreviewHandle) -ne [IntPtr]::Zero){throw 'Exit project resident before GUI validation'}
$fixture="$repo\samples"
$shell=New-Object -ComObject Shell.Application;$before=@($shell.Windows()|ForEach-Object {$_.HWND})
$explorer=$null;$process=$null;$success=$false;$failure=$null;$steps=[Collections.Generic.List[object]]::new()
$report="$repo\artifacts\$Label-current.json"
function Save-Step($Name,$Data){$steps.Add([pscustomobject]@{step=$Name;data=$Data;foreground=[PreviewGui]::GetForegroundWindow().ToInt64()});Write-Output $Name}
function Hover-Row($Row){
 [void][PreviewGui]::SetThreadDpiAwarenessContext([IntPtr](-4))
 $x=[int]($Row.x+$Row.width/2);$y=[int]($Row.y+$Row.height/2)
 if(-not [PreviewGui]::SetCursorPos($x,$y)){throw 'Cannot place real mouse'}
 [PreviewGui]::mouse_event(1,1,0,0,[UIntPtr]::Zero)
 for($j=0;$j -lt 16;$j++){
  Start-Sleep -Milliseconds 100;$point=[PreviewWindows]::Cursor()
  if([Math]::Abs($point.x-$x) -gt 8 -or [Math]::Abs($point.y-$y) -gt 8){throw "Mouse interrupted during hover: target=$x,$y actual=$($point.x),$($point.y)"}
 }
}
function Move-Away {[void][PreviewGui]::SetCursorPos(40,40);Start-Sleep -Milliseconds 300}
function Check-Visible([bool]$Expected){for($i=0;$i -lt 80 -and [PreviewGui]::IsWindowVisible($hwnd) -ne $Expected;$i++){Start-Sleep -Milliseconds 25};if([PreviewGui]::IsWindowVisible($hwnd) -ne $Expected){throw "Preview visible expected=$Expected"}}
try {
 Remove-Item $report -ErrorAction SilentlyContinue
 $process=Start-Process $Exe -ArgumentList (Join-ProcessArguments @('--trace',$report)) -PassThru
 Start-Process explorer.exe -ArgumentList ('/n,"'+$fixture+'"') | Out-Null
 for($i=0;$i -lt 60;$i++){Start-Sleep -Milliseconds 100;$explorer=@($shell.Windows()|Where-Object {$before -notcontains $_.HWND -and $_.Document.Folder.Self.Path -eq $fixture})|Select-Object -First 1;if($explorer -and (Get-PreviewHandle) -ne [IntPtr]::Zero){break}}
 if(-not $explorer){throw 'Test Explorer missing'};$eh=[IntPtr]$explorer.HWND;$hwnd=Get-PreviewHandle
 [void][PreviewGui]::ShowWindow($eh,9)
 [void][PreviewGui]::SetWindowPos($eh,[IntPtr]::Zero,0,30,2100,1640,0x14)
 $explorer.Document.CurrentViewMode=4;Start-Sleep -Milliseconds 400
 [PreviewGui]::Click(800,60);Focus-TestWindow $eh
 Click-ExplorerFile $explorer 'math-stale-0.md'
 $row=@(Get-ExplorerItems $eh|Where-Object {$_.name -eq 'math-stale-0.md'})[0]
 [PreviewGui]::Key(32);Check-Visible $true
 $initial=Read-PreviewReport $report {param($m) $m.file_name -eq 'math-stale-0.md' -and $m.layout_complete}
 $pr=Get-TestRect $hwnd
 [PreviewGui]::Key(0x28)
 Read-PreviewReport $report {param($m) $m.file_name -eq 'math-stale-1.md'} | Out-Null
 [void][PreviewGui]::SetCursorPos(($pr.x+$pr.width/2),($pr.y+$pr.height/2));[PreviewGui]::mouse_event(1,1,0,0,[UIntPtr]::Zero);Start-Sleep -Milliseconds 1600
 Save-Step 'arrow-then-move-inside' @{tips=(Get-OverlappingInfotips $hwnd $eh);metrics=(Read-PreviewReport $report);under_cursor=(Get-WindowProbe ([PreviewWindows]::UnderCursor()))}
 if($Baseline){
  & "$PSScriptRoot\capture-window.ps1" -WindowHandle $hwnd.ToInt32() -Path "artifacts\$Label-hover.png" | Out-Null
  if((Get-OverlappingInfotips $hwnd $eh).Count -eq 0){throw 'Baseline arrow/move did not reproduce real overlapping infotip'}
  $success=$true;return
 }
 if(-not $Baseline){
  if((Get-OverlappingInfotips $hwnd $eh).Count -ne 0){throw 'Infotip appeared after arrow/move inside preview'}
  [PreviewGui]::Key(32);Check-Visible $false;Save-Step 'arrow-move-space-first-press' $null
  [PreviewGui]::Key(32);Check-Visible $true;Read-PreviewReport $report {param($m) $m.file_name -eq 'math-stale-1.md'} | Out-Null
  [PreviewGui]::Key(0x26);Read-PreviewReport $report {param($m) $m.file_name -eq 'math-stale-0.md'} | Out-Null
 }
 [void][PreviewGui]::SetWindowPos($hwnd,[IntPtr]::Zero,680,$pr.y,1600,$pr.height,0x14)
 [void][PreviewGui]::SetWindowPos($eh,[IntPtr]::Zero,0,30,900,1640,0x14)
 Start-Sleep -Milliseconds 200
 $pr=Get-TestRect $hwnd
 $row=@(Get-ExplorerItems $eh|Where-Object {$_.name -eq 'math-stale-0.md'})[0]
 if($row.x+$row.width/2 -ge $pr.x -or $row.x+$row.width/2 -lt 0){throw 'No exposed on-screen file row centre'}
 Move-Away;Hover-Row $row
 $tips=Get-OverlappingInfotips $hwnd $eh
 Save-Step 'hover-visible' @{tips=$tips;all_tips=@([PreviewWindows]::Tips([PreviewWindows]::Pid($eh))|ForEach-Object {Get-WindowProbe $_});under_cursor=(Get-WindowProbe ([PreviewWindows]::UnderCursor()));row=$row;cursor=[PreviewWindows]::Cursor();hover_ms=1600;preview=$pr;metrics=(Read-PreviewReport $report);selection=@($explorer.Document.SelectedItems()|ForEach-Object {$_.Name});above=@([PreviewWindows]::Above($hwnd)|ForEach-Object {Get-WindowProbe $_})}
 & "$PSScriptRoot\capture-window.ps1" -WindowHandle $hwnd.ToInt32() -Path "artifacts\$Label-hover.png" | Out-Null
 if($Baseline){if($tips.Count -eq 0){throw 'Baseline did not reproduce a real overlapping Explorer infotip'};$success=$true;return}
 if($tips.Count -ne 0){throw 'Explorer infotip covers visible preview'}
 if([PreviewGui]::GetForegroundWindow() -ne $eh){throw 'Hover stole Explorer focus'}
 if(@($explorer.Document.SelectedItems())[0].Name -ne 'math-stale-0.md'){throw 'Hover changed selection'}
 $old=Read-PreviewReport $report
 [void][PreviewGui]::SetCursorPos(($pr.x+150),($pr.y+300));[PreviewGui]::mouse_event(0x800,0,0,4294966936,[UIntPtr]::Zero)
 $scrolled=Read-PreviewReport $report {param($m) $m.scroll -gt $old.scroll}
 if((Get-OverlappingInfotips $hwnd $eh).Count -ne 0){throw 'Infotip remained after wheel'}
 Save-Step 'wheel' $scrolled
 # Keys act while Explorer still owns the keyboard; there are no clicks here.
 [PreviewGui]::Key(0x50);$pin=Read-PreviewReport $report {param($m) $m.topmost};[PreviewGui]::Key(0x50)
 [PreviewGui]::Key(0x4d);$source=Read-PreviewReport $report {param($m) $m.mode -eq 'SOURCE'};[PreviewGui]::Key(0x4d)
 Read-PreviewReport $report {param($m) $m.mode -eq 'RENDERED'} | Out-Null
 [PreviewGui]::Key(0x28);$next=Read-PreviewReport $report {param($m) $m.file_name -eq 'math-stale-1.md'}
 [PreviewGui]::Key(0x26);Read-PreviewReport $report {param($m) $m.file_name -eq 'math-stale-0.md'} | Out-Null
 Save-Step 'P-M-arrows-no-click' @{pin=$pin;source=$source;next=$next}
 Move-Away;Hover-Row $row
 if((Get-OverlappingInfotips $hwnd $eh).Count -ne 0){throw 'Infotip returned before Space'}
 [PreviewGui]::Key(32);Check-Visible $false;Save-Step 'space-close-first-press' $null
 Move-Away;Hover-Row $row
 $restored=@([PreviewWindows]::Tips([PreviewWindows]::Pid($eh)) | ForEach-Object {Get-WindowProbe $_})
 if($restored.Count -eq 0){throw 'Explorer infotip not restored after closing preview'}
 if(@($restored|Where-Object {$_.region_type -eq 1}).Count -ne 0){throw 'Tooltip visual region was not restored'}
 Save-Step 'infotip-restored' @{tips=$restored;row=$row;cursor=[PreviewWindows]::Cursor();hover_ms=1600}
 & "$PSScriptRoot\capture-window.ps1" -WindowHandle $eh.ToInt32() -Path "artifacts\$Label-restored.png" | Out-Null
 Move-Away;[PreviewGui]::Key(32);Check-Visible $true
 [void][PreviewGui]::SetWindowPos($hwnd,[IntPtr]::Zero,680,$pr.y,1600,$pr.height,0x14)
 Read-PreviewReport $report {param($m) $m.file_name -eq 'math-stale-0.md'} | Out-Null
 Hover-Row $row
 if((Get-OverlappingInfotips $hwnd $eh).Count -ne 0){throw 'Infotip covers reopened preview'}
 $suppressed=Read-PreviewReport $report {param($m) $m.infotips_hidden -gt 0}
 Save-Step 'real-tip-suppressed' $suppressed
 [PreviewGui]::Key(27);Check-Visible $false;Save-Step 'escape-close-first-press' $null
 $success=$true
} catch {$failure=$_.Exception.Message;throw} finally {
 if($process -and -not $process.HasExited){& "$repo\new-quicklook.exe" --quit;if(-not $process.WaitForExit(3000)){$process.Kill()}}
 Close-TestExplorer $explorer $before
 [pscustomobject]@{success=$success;failure=$failure;baseline_mode=[bool]$Baseline;executable=$Exe;executable_sha256=(Get-FileHash $Exe).Hash;shell_baseline=$before;shell_after=@($shell.Windows()|ForEach-Object {$_.HWND});steps=$steps.ToArray()} | ConvertTo-Json -Depth 10 | Set-Content "artifacts\$Label-results.json" -Encoding UTF8
}
