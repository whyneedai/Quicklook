"""Windows RichEdit worker validation. Outputs remain under artifacts/."""
import pathlib, subprocess, struct, json, time, threading
root=pathlib.Path(__file__).resolve().parents[1]
exe=root/'target/x86_64-pc-windows-msvc/release/math-worker.exe'
corpus=json.loads((root/'samples/math-corpus.json').read_text())
rows=[]
p=subprocess.Popen([str(exe)],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
watch=threading.Timer(30,p.kill);watch.start()
try:
 for dpi in [96,144,192]:
  for i,tex in enumerate(corpus):
   start=time.perf_counter();raw=tex.encode();rid=len(rows)
   p.stdin.write(b'NQM1'+struct.pack('<QQIII',rid,7,dpi,1,len(raw))+raw);p.stdin.flush()
   header=p.stdout.read(52)
   if len(header)!=52:raise RuntimeError('Worker stopped or timed out')
   magic,response_id,g,w,h,base,n,rdpi,convert,draw,backend=struct.unpack('<4sQQIIIIIIII',header)
   assert magic==b'NQR2' and response_id==rid and g==7 and dpi==rdpi and backend in (0,1,2)
   assert 0<w<=2048 and 0<h<=512 and 0<base<=h and n==w*h*4,(dpi,tex,w,h,base)
   pixels=p.stdout.read(n);assert len(pixels)==n
   rows.append(dict(tex=tex,dpi=dpi,width=w,height=h,baseline=base,convert_us=convert,draw_us=draw,backend=backend,total_ms=(time.perf_counter()-start)*1000))
finally:watch.cancel();p.kill();p.wait()
# Structurally invalid: the worker must refuse without writing a response.
structural=['x\0y','x'*2049,'{'*17+'x'+'}'*17,'{x','x}','\x01','']
for tex in structural:
 raw=tex.encode();packet=b'NQM1'+struct.pack('<QQIII',0,1,96,1,len(raw))+raw
 result=subprocess.run([str(exe)],input=packet,stdout=subprocess.PIPE,timeout=5)
 assert result.returncode==0 and not result.stdout,repr(tex)
# Commands that used to be whitelist-rejected: they must now reach the worker and
# come back as a bitmap (routing/preprocessing happens inside the worker).
commands=[r'\unknown{x}',r'\begin{bmatrix}x\end{bmatrix}',r'\begin{cases}x\end{cases}',r'\begin{aligned}x\end{aligned}',r'\begin{array}{cc}x\end{array}',r'\operatorname{foo}',r'\color{red}x']
command_rows=[]
for tex in commands:
 raw=tex.encode();packet=b'NQM1'+struct.pack('<QQIII',0,1,96,1,len(raw))+raw
 result=subprocess.run([str(exe)],input=packet,stdout=subprocess.PIPE,timeout=5)
 assert result.returncode==0 and len(result.stdout)>=52,repr(tex)
 magic,rid,g,w,h,base,n,rdpi,convert,draw,backend=struct.unpack('<4sQQIIIIIIII',result.stdout[:52])
 assert magic==b'NQR2' and w>0 and h>0 and n==w*h*4,(tex,w,h)
 command_rows.append(dict(tex=tex,width=w,height=h,backend=backend))
(root/'artifacts/math-corpus-results.json').write_text(json.dumps(rows,indent=2))
(root/'artifacts/math-command-cases.json').write_text(json.dumps(command_rows,indent=2))
from collections import Counter
dist=Counter(r['backend'] for r in rows)
print(f'Passed {len(rows)} Windows formula renders (40 expressions at 96/144/192 DPI), backend={dict(dist)}; {len(structural)} structural rejects; {len(command_rows)} formerly-whitelisted commands now rendered')
