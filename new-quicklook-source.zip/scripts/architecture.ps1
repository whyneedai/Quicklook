﻿$ErrorActionPreference='Stop'

$repo = Split-Path $PSScriptRoot -Parent
Set-Location $repo
$metadataText=& "$repo\scripts\cargo.cmd" metadata --no-deps --format-version 1 --locked
if ($LASTEXITCODE -ne 0) {throw 'cargo metadata failed'}
$metadata=$metadataText | ConvertFrom-Json
$expected=@{
 'quicklook-core'=@();
 'quicklook-render'=@('quicklook-core');
 'quicklook-engine'=@('quicklook-core','quicklook-render');
 'quicklook-display'=@('quicklook-core');
 'new-quicklook'=@('quicklook-core','quicklook-engine','quicklook-display')
}
$packages=@($metadata.packages | Where-Object {$metadata.workspace_members -contains $_.id})
if ($packages.Count -ne 5) {throw 'Expected exactly five workspace crates'}
$result=@()
foreach ($package in $packages) {
 if (-not $expected.ContainsKey($package.name)) {throw "Unexpected crate: $($package.name)"}
 $normal=@($package.dependencies | Where-Object {$null -eq $_.kind})
 $internal=@($normal | Where-Object {$expected.ContainsKey($_.name)} | ForEach-Object {$_.name})
 if (@(Compare-Object @($expected[$package.name] | Sort-Object) @($internal | Sort-Object)).Count -ne 0) {throw "Dependency boundary violated: $($package.name)"}
 if ($package.name -eq 'quicklook-core' -and $normal.Count -ne 0) {throw 'core must have zero runtime dependencies'}
 $result += [pscustomobject]@{crate=$package.name;internal_dependencies=$internal;runtime_dependencies=@($normal | ForEach-Object {$_.name})}
}
$result | ConvertTo-Json -Depth 4 | Set-Content artifacts\architecture.json -Encoding UTF8
$result | ConvertTo-Json -Depth 4
# Family boundaries and the approved thin platform entrypoints.
$textRoot="$repo\crates\render\src\text"
$imageRoot="$repo\crates\render\src\image"
foreach($root in @($textRoot,$imageRoot)){if(-not (Test-Path "$root\common.rs")){throw "Missing family core: $root"}}
foreach($file in Get-ChildItem $textRoot -Filter *.rs){if((Get-Content $file.FullName -Raw) -match '(crate|super)::(?:super::)?image::'){throw "Cross-family text import: $file"}}
foreach($file in Get-ChildItem $imageRoot -Filter *.rs){if((Get-Content $file.FullName -Raw) -match '(crate|super)::(?:super::)?text::'){throw "Cross-family image import: $file"}}
$pagesRoot="$repo\crates\render\src\pages"
foreach($file in Get-ChildItem $pagesRoot -Filter *.rs){if((Get-Content $file.FullName -Raw) -match '(crate|super)::(?:super::)?(?:text|image)::'){throw "Cross-family pages import: $file"}}
foreach($root in @("$repo\crates\core\src","$repo\crates\render\src","$repo\crates\engine\src","$repo\crates\display\src","$repo\crates\app\src\native")) {
 foreach($file in Get-ChildItem $root -Recurse -Filter *.rs){if((Get-Content $file.FullName -Raw) -match 'Data::Pdf|PdfDocument::|RenderWithOptionsToStreamAsync'){throw "PDF parser must stay inside its worker: $file"}}
}
if(Test-Path "$repo\crates\app\src\native.rs"){throw 'native.rs must be native/mod.rs'}
foreach($name in @('mod','action','hook','wndproc','bootstrap')){if(-not (Test-Path "$repo\crates\app\src\native\$name.rs")){throw "Missing native module: $name"}}
if(@(Get-Content "$repo\crates\display\src\windows.rs").Count -gt 20){throw 'Windows presentation facade is no longer thin'}
$render=$packages|Where-Object name -eq 'quicklook-render'
if(@($render.dependencies|Where-Object {$_.name -in @('libwebp-sys','libwebp-sys2','zenwebp')}).Count -ne 0){throw 'Unapproved WebP dependency returned'}
Write-Output 'Text/image/pages families, isolated PDF APIs, native modules, display facade and WebP dependency policy passed'
