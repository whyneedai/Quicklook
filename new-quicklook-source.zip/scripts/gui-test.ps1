﻿# Shared real-input helpers. Dot source from Windows PowerShell GUI tests.
$ErrorActionPreference='Stop'

$repo = Split-Path $PSScriptRoot -Parent
$env:TEMP="$repo\.cache\tmp"; $env:TMP=$env:TEMP
New-Item -ItemType Directory -Force $env:TEMP | Out-Null
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
Add-Type @'
using System; using System.Runtime.InteropServices;
public static class PreviewGui {
 [StructLayout(LayoutKind.Sequential)] public struct RECT { public int left,top,right,bottom; }
 [DllImport("user32.dll")] public static extern IntPtr SetThreadDpiAwarenessContext(IntPtr c);
 [DllImport("user32.dll")] public static extern uint GetDpiForWindow(IntPtr h);
 [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
 [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
 [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint a,uint b,bool attach);
 [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h,IntPtr p);
 [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
 [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h,int mode);
 [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
 [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h,out RECT r);
 [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h,IntPtr after,int x,int y,int w,int height,uint flags);
 [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr h,uint m,IntPtr w,IntPtr l);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] public static extern IntPtr FindWindow(string c,string n);
 [DllImport("user32.dll")] public static extern int GetWindowLongW(IntPtr h,int index);
 [DllImport("user32.dll")] public static extern void keybd_event(byte k,byte scan,uint flags,UIntPtr extra);
 [DllImport("user32.dll")] public static extern bool SetCursorPos(int x,int y);
 [DllImport("user32.dll")] public static extern void mouse_event(uint flags,uint x,uint y,uint data,UIntPtr extra);
 public static void Key(byte k) { keybd_event(k,0,0,UIntPtr.Zero);System.Threading.Thread.Sleep(35);keybd_event(k,0,2,UIntPtr.Zero); }
 public static void Click(int x,int y) { SetCursorPos(x,y);System.Threading.Thread.Sleep(60);mouse_event(2,0,0,0,UIntPtr.Zero);System.Threading.Thread.Sleep(35);mouse_event(4,0,0,0,UIntPtr.Zero); }
 public static bool Focus(IntPtr h) { uint a=GetCurrentThreadId(), b=GetWindowThreadProcessId(GetForegroundWindow(),IntPtr.Zero);bool joined=a!=b && AttachThreadInput(a,b,true);try { ShowWindow(h,9);return SetForegroundWindow(h); }finally { if(joined)AttachThreadInput(a,b,false); } }
}
'@
[void][PreviewGui]::SetThreadDpiAwarenessContext([IntPtr](-4))
function Focus-TestWindow([IntPtr]$Handle) {
 for($i=0;$i -lt 20 -and [PreviewGui]::GetForegroundWindow() -ne $Handle;$i++) {
  [void][PreviewGui]::Focus($Handle)
  if([PreviewGui]::GetForegroundWindow() -ne $Handle) {
   [PreviewGui]::keybd_event(18,0,0,[UIntPtr]::Zero);[PreviewGui]::keybd_event(18,0,2,[UIntPtr]::Zero)
   [void][PreviewGui]::Focus($Handle)
  }
  Start-Sleep -Milliseconds 50
 }
 if([PreviewGui]::GetForegroundWindow() -ne $Handle){throw "Cannot focus test window $Handle"}
}
function Get-PreviewHandle {
 [PreviewGui]::FindWindow('NewQuickLook.Native.Window','new-quicklook')
}
function Get-TestRect([IntPtr]$Handle) {
 $r=New-Object PreviewGui+RECT
 if(-not [PreviewGui]::GetWindowRect($Handle,[ref]$r)){throw 'GetWindowRect failed'}
 [pscustomobject]@{x=$r.left;y=$r.top;width=($r.right-$r.left);height=($r.bottom-$r.top)}
}
function Read-PreviewReport([string]$Path,[scriptblock]$Predicate={param($m) $null -ne $m.first_content_paint_ms},[int]$TimeoutMs=4000) {
 $watch=[Diagnostics.Stopwatch]::StartNew();$last=$null
 while($watch.ElapsedMilliseconds -lt $TimeoutMs) {
  try { $last=Get-Content -LiteralPath $Path -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json; if(& $Predicate $last){return $last} } catch { }
  Start-Sleep -Milliseconds 25
 }
 throw "Timed out waiting for $Path; last report: $($last | ConvertTo-Json -Compress)"
}
function Get-ExplorerItems([IntPtr]$Handle) {
 $window=Get-TestRect $Handle
 $root=[Windows.Automation.AutomationElement]::FromHandle($Handle)
 $condition=[Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::ControlTypeProperty,[Windows.Automation.ControlType]::ListItem)
 @($root.FindAll([Windows.Automation.TreeScope]::Descendants,$condition) | ForEach-Object {
  $r=$_.Current.BoundingRectangle
  # Details rows can extend past the visible client area when columns are wide.
  $left=[Math]::Max($r.X,$window.x);$right=[Math]::Min($r.Right,$window.x+$window.width)
  $top=[Math]::Max($r.Y,$window.y);$bottom=[Math]::Min($r.Bottom,$window.y+$window.height)
  if(-not $_.Current.IsOffscreen -and $right -gt $left -and $bottom -gt $top){
   [pscustomobject]@{name=$_.Current.Name;x=$left;y=$top;width=($right-$left);height=($bottom-$top)}
  }
 })
}
function Click-ExplorerFile($Explorer,[string]$Name) {
 Focus-TestWindow ([IntPtr]$Explorer.HWND)
 $row=@(Get-ExplorerItems ([IntPtr]$Explorer.HWND) | Where-Object {$_.name -eq $Name}) | Select-Object -First 1
 if(-not $row){throw "Visible Explorer row missing: $Name"}
 [PreviewGui]::Click([int]($row.x+$row.width/2),[int]($row.y+$row.height/2))
 Start-Sleep -Milliseconds 120
 $selected=@($Explorer.Document.SelectedItems())
 if($selected.Count -ne 1 -or $selected[0].Name -ne $Name){throw "Real mouse selected wrong file: expected $Name"}
}
function Close-TestExplorer($Explorer,[object[]]$Baseline) {
 if($Explorer -and $Baseline -notcontains $Explorer.HWND) {
  $h=[IntPtr]$Explorer.HWND
  try {$Explorer.Quit()} catch { }
  # Win11 can interpret WM_CLOSE as closing just the active tab.
  for($j=0;$j -lt 16;$j++){
   Start-Sleep -Milliseconds 200
   if(-not [PreviewGui]::IsWindowVisible($h)){break}
   [void][PreviewGui]::PostMessage($h,16,[IntPtr]::Zero,[IntPtr]::Zero)
  }
 }
}
