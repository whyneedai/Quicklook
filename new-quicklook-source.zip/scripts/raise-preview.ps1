﻿param([string]$Label='raise')
$repo = Split-Path $PSScriptRoot -Parent
. "$PSScriptRoot\process-args.ps1"
$repoUri = ([Uri]($repo+'\')).AbsoluteUri.TrimEnd('/')

$ErrorActionPreference='Stop'
Set-Location $repo
. "$PSScriptRoot\gui-test.ps1"
. "$PSScriptRoot\preview-windows.ps1"
$exe="$repo\new-quicklook.exe";$report="$repo\artifacts\$Label-current.json"
if((Get-PreviewHandle) -ne [IntPtr]::Zero){throw 'Exit resident before recall validation'}
$fixture="$repo\artifacts\raise-fixtures";New-Item $fixture -ItemType Directory -Force | Out-Null
Set-Content "$fixture\01.txt" ('first file ' * 200) -Encoding UTF8
Set-Content "$fixture\02.txt" ('second file ' * 200) -Encoding UTF8
$shell=New-Object -ComObject Shell.Application;$before=@($shell.Windows()|ForEach-Object {$_.HWND})
$explorer=$null;$other=$null;$process=$null;$success=$false;$failure=$null;$steps=[Collections.Generic.List[object]]::new()
function Save-Step($Name) {
 $steps.Add([pscustomobject]@{step=$Name;foreground=[PreviewGui]::GetForegroundWindow().ToInt64();selection=@($explorer.Document.SelectedItems()|ForEach-Object {$_.Name});visible=[PreviewGui]::IsWindowVisible($hwnd);uncovered=[PreviewWindows]::Uncovered($hwnd);geometry=(Get-TestRect $hwnd);metrics=(Read-PreviewReport $report);above=@([PreviewWindows]::Above($hwnd)|ForEach-Object {Get-WindowProbe $_})})
 Write-Output $Name
}
function Assert-Visible([bool]$Value){for($j=0;$j -lt 80 -and [PreviewGui]::IsWindowVisible($hwnd) -ne $Value;$j++){Start-Sleep -Milliseconds 25};if([PreviewGui]::IsWindowVisible($hwnd) -ne $Value){throw "Visible expected=$Value"}}
function Cover {
 [void][PreviewGui]::SetWindowPos($eh,[IntPtr]::Zero,0,0,0,0,0x43)
 Focus-TestWindow $eh;Start-Sleep -Milliseconds 200
 if([PreviewWindows]::Uncovered($hwnd) -or @([PreviewWindows]::Above($hwnd)|Where-Object {$_ -eq $eh -and [PreviewWindows]::Visible($_) -and [PreviewWindows]::Intersects($_,$hwnd)}).Count -ne 1){throw 'Explorer did not really cover preview'}
}
try {
 Remove-Item $report -ErrorAction SilentlyContinue
 $process=Start-Process $exe -ArgumentList (Join-ProcessArguments @('--trace',$report)) -PassThru
 Start-Process explorer.exe -ArgumentList ('/n,"'+$fixture+'"') | Out-Null
 for($j=0;$j -lt 60;$j++){Start-Sleep -Milliseconds 100;$explorer=@($shell.Windows()|Where-Object {$before -notcontains $_.HWND -and $_.Document.Folder.Self.Path -eq $fixture})|Select-Object -First 1;$hwnd=Get-PreviewHandle;if($explorer -and $hwnd -ne [IntPtr]::Zero){break}}
 if(-not $explorer){throw 'Owned Explorer missing'};$eh=[IntPtr]$explorer.HWND
 [void][PreviewGui]::ShowWindow($eh,9);[void][PreviewGui]::SetWindowPos($eh,[IntPtr]::Zero,0,30,2100,1640,0x14)
 $explorer.Document.CurrentViewMode=4;Start-Sleep -Milliseconds 400
 Click-ExplorerFile $explorer '01.txt';[PreviewGui]::Key(32);Assert-Visible $true
 $initial=Read-PreviewReport $report {param($m) $m.file_name -eq '01.txt' -and $m.layout_complete}
 $geometry=Get-TestRect $hwnd|ConvertTo-Json -Compress;Save-Step 'opened'
 Cover;Save-Step 'same-file-really-covered'
 & "$PSScriptRoot\capture-window.ps1" -Path "artifacts\$Label-covered.png" | Out-Null
 [PreviewGui]::Key(32);Assert-Visible $true
 for($j=0;$j -lt 60 -and -not [PreviewWindows]::Uncovered($hwnd);$j++){Start-Sleep -Milliseconds 25}
 $raised=Read-PreviewReport $report
 if(-not [PreviewWindows]::Uncovered($hwnd) -or [PreviewGui]::GetForegroundWindow() -ne $eh){throw 'Space failed to raise without focus theft'}
 foreach($field in @('generation','content_hash','body_hash','layout_builds','scroll')){if($raised.$field -ne $initial.$field){throw "Recall changed $field"}}
 if((Get-TestRect $hwnd|ConvertTo-Json -Compress) -ne $geometry){throw 'Recall changed window geometry'}
 Save-Step 'same-file-raised-without-reload'
 & "$PSScriptRoot\capture-window.ps1" -WindowHandle $hwnd.ToInt32() -Path "artifacts\$Label-raised.png" | Out-Null
 [PreviewGui]::Key(32);Assert-Visible $false;Save-Step 'second-space-closes'
 [PreviewGui]::Key(32);Assert-Visible $true
 $previousGeneration=$initial.generation
 $initial=Read-PreviewReport $report {param($m) $m.file_name -eq '01.txt' -and $m.layout_complete -and $m.generation -gt $previousGeneration}
 Cover;[PreviewGui]::Key(0x28);Start-Sleep -Milliseconds 200
 if(@($explorer.Document.SelectedItems())[0].Name -ne '02.txt'){throw 'Real Down did not change Explorer selection'}
 if((Read-PreviewReport $report).generation -ne $initial.generation){throw 'Covered preview followed arrow'}
 Save-Step 'other-file-selected-while-covered'
 [PreviewGui]::Key(32);Assert-Visible $true
 $switched=Read-PreviewReport $report {param($m) $m.file_name -eq '02.txt' -and $m.layout_complete -and $m.generation -gt $initial.generation}
 if($switched.content_hash -eq $initial.content_hash -or -not [PreviewWindows]::Uncovered($hwnd)){throw 'Space did not switch the selected file'}
 Save-Step 'covered-other-file-switches'
 Start-Process explorer.exe -ArgumentList ('/n,"'+$repo+'\samples"') | Out-Null
 for($j=0;$j -lt 60;$j++){Start-Sleep -Milliseconds 100;$other=@($shell.Windows()|Where-Object {$before -notcontains $_.HWND -and $_.HWND -ne $eh.ToInt64() -and $_.Document.Folder.Self.Path -eq "$repo\samples"})|Select-Object -First 1;if($other){break}}
 if(-not $other){throw 'Other root missing'}
 [void][PreviewGui]::ShowWindow([IntPtr]$other.HWND,9);[void][PreviewGui]::SetWindowPos([IntPtr]$other.HWND,[IntPtr]::Zero,0,30,2100,1640,0x14);$other.Document.CurrentViewMode=4;Start-Sleep -Milliseconds 250
 Click-ExplorerFile $other 'hello.py';[PreviewGui]::Key(32);Start-Sleep -Milliseconds 250
 if((Read-PreviewReport $report).generation -ne $switched.generation -or [PreviewWindows]::Uncovered($hwnd)){throw 'Unrelated Explorer recalled preview'}
 Save-Step 'different-root-space-ignored'
 Close-TestExplorer $other $before;$other=$null
 Cover
 # Same root and same path in another tab must still have no authority.
 [PreviewGui]::keybd_event(17,0,0,[UIntPtr]::Zero);[PreviewGui]::Key(84);[PreviewGui]::keybd_event(17,0,2,[UIntPtr]::Zero)
 for($j=0;$j -lt 60;$j++){Start-Sleep -Milliseconds 100;if(@($shell.Windows()|Where-Object {$_.HWND -eq $eh.ToInt64()}).Count -eq 2){break}}
 $newTab=@($shell.Windows()|Where-Object {$_.HWND -eq $eh.ToInt64() -and $_.LocationURL -ne "$repoUri/artifacts/raise-fixtures"})|Select-Object -First 1
 if(-not $newTab){throw 'New tab missing'}
 # Configure the fixture folder through Shell; Space behavior below uses real keys.
 $newTab.Navigate2($fixture)
 for($j=0;$j -lt 60;$j++){Start-Sleep -Milliseconds 100;$matching=@($shell.Windows()|Where-Object {$_.HWND -eq $eh.ToInt64() -and $_.Document.Folder.Self.Path -eq $fixture});if($matching.Count -eq 2){break}}
 if($matching.Count -ne 2){& "$PSScriptRoot\capture-window.ps1" -WindowHandle $eh.ToInt32() -Path "artifacts\$Label-tab-failure.png" | Out-Null;throw ('Second real tab navigation failed: '+(@($shell.Windows()|Where-Object {$_.HWND -eq $eh.ToInt64()}|ForEach-Object {$_.LocationURL}) -join ';'))}
 Start-Sleep -Milliseconds 400;Click-ExplorerFile $newTab '02.txt';Start-Sleep -Milliseconds 200
 $tabInitial=Read-PreviewReport $report
 [PreviewGui]::Key(32);Start-Sleep -Milliseconds 200
 if((Read-PreviewReport $report).generation -ne $tabInitial.generation -or [PreviewWindows]::Uncovered($hwnd)){throw 'Other tab recalled preview'}
 Save-Step 'same-root-other-tab-space-ignored'
 [PreviewGui]::keybd_event(17,0,0,[UIntPtr]::Zero);[PreviewGui]::Key(87);[PreviewGui]::keybd_event(17,0,2,[UIntPtr]::Zero);Start-Sleep -Milliseconds 300
 Focus-TestWindow $hwnd;[PreviewGui]::Key(27);Assert-Visible $false
 Save-Step 'final-foreground-first-escape'
 $success=$true
} catch {$failure=$_.Exception.Message;throw} finally {
 if($process -and -not $process.HasExited){& $exe --quit;if(-not $process.WaitForExit(3000)){$process.Kill()}}
 Close-TestExplorer $other $before;Close-TestExplorer $explorer $before
 [pscustomobject]@{success=$success;failure=$failure;exe_sha256=(Get-FileHash $exe).Hash;shell_before=$before;shell_after=@($shell.Windows()|ForEach-Object {$_.HWND});steps=@($steps)}|ConvertTo-Json -Depth 12|Set-Content "artifacts\$Label-results.json" -Encoding UTF8
}
