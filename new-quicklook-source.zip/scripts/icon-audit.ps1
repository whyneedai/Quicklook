$ErrorActionPreference='Stop'

$repo = Split-Path $PSScriptRoot -Parent
Set-Location $repo
$env:TEMP="$repo\.cache\tmp";$env:TMP=$env:TEMP
Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class IconAudit {
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode)] public static extern IntPtr LoadLibraryEx(string path,IntPtr file,uint flags);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode)] public static extern IntPtr FindResource(IntPtr module,IntPtr name,IntPtr type);
 [DllImport("kernel32.dll")] public static extern uint SizeofResource(IntPtr module,IntPtr resource);
 [DllImport("kernel32.dll")] public static extern bool FreeLibrary(IntPtr module);
 [DllImport("shell32.dll",CharSet=CharSet.Unicode)] public static extern uint ExtractIconEx(string path,int index,IntPtr large,IntPtr small,uint count);
}
'@
$exe="$repo\new-quicklook.exe"
$module=[IconAudit]::LoadLibraryEx($exe,[IntPtr]::Zero,2)
if ($module -eq [IntPtr]::Zero){throw 'PE data load failed'}
try {
 $group=[IconAudit]::FindResource($module,[IntPtr]1,[IntPtr]14)
 $manifest=[IconAudit]::FindResource($module,[IntPtr]1,[IntPtr]24)
 $count=[IconAudit]::ExtractIconEx($exe,-1,[IntPtr]::Zero,[IntPtr]::Zero,0)
 if ($group -eq [IntPtr]::Zero -or $manifest -eq [IntPtr]::Zero -or $count -lt 1) {throw 'Expected embedded icon and manifest resources'}
 $result=[pscustomobject]@{exe_bytes=(Get-Item $exe).Length;exe_sha256=(Get-FileHash $exe).Hash;source_png_sha256=(Get-FileHash icon.png).Hash;ico_sha256=(Get-FileHash crates\app\assets\app.ico).Hash;icon_groups=$count;icon_group_bytes=[IconAudit]::SizeofResource($module,$group);manifest_bytes=[IconAudit]::SizeofResource($module,$manifest)}
 $result | ConvertTo-Json | Set-Content artifacts\icon-audit.json -Encoding UTF8
 $result | ConvertTo-Json
} finally {[void][IconAudit]::FreeLibrary($module)}
