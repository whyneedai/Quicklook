﻿param([string]$Distribution='')
$ErrorActionPreference='Stop'
$repo=Split-Path $PSScriptRoot -Parent
Set-Location $repo
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false);$OutputEncoding=[Console]::OutputEncoding
. "$PSScriptRoot\gui-test.ps1"
if((Get-PreviewHandle) -ne [IntPtr]::Zero){throw 'Exit project resident before WSL PDF smoke'}
$encoded=[Convert]::ToBase64String([IO.File]::ReadAllBytes("$repo\samples\pdf\01-pages.pdf"))
$program=@"
import base64,json,pathlib,subprocess,tempfile
root=pathlib.Path(tempfile.mkdtemp(prefix='new-quicklook-preview-pdf-'))
path=root/'document.pdf'
path.write_bytes(base64.b64decode('$encoded'))
print(json.dumps(dict(path=str(path),sha256=subprocess.check_output(['sha256sum',str(path)],text=True).split()[0],distribution=subprocess.check_output(['printenv','WSL_DISTRO_NAME'],text=True).strip())))
"@
$wslArgs=@();if($Distribution){$wslArgs+=@('-d',$Distribution)};$wslArgs+=@('--exec','python3','-c',$program)
$fixture=& wsl.exe @wslArgs
if($LASTEXITCODE -ne 0){throw 'Isolated Linux PDF fixture generation failed'}
$fixture=$fixture|ConvertFrom-Json
$fixture|ConvertTo-Json|Set-Content artifacts\pdf-wsl-fixture.json -Encoding UTF8
$results=@()
foreach($hostName in @('wsl.localhost','wsl$')) {
 $unc='\\'+$hostName+'\'+$fixture.distribution+$fixture.path.Replace('/','\')
 $report="$repo\artifacts\pdf-wsl-$hostName.json";Remove-Item $report -ErrorAction SilentlyContinue
 $p=Start-Process "$repo\new-quicklook.exe" -ArgumentList @('--smoke',('"'+$unc+'"'),('"'+$report+'"')) -PassThru
 try{if(-not $p.WaitForExit(15000)){throw 'WSL PDF timed out'};if($p.ExitCode -ne 0){throw 'WSL PDF process crashed'}}finally{if(-not $p.HasExited){$p.Kill();$p.WaitForExit()}}
 $m=Read-PreviewReport $report
 if($m.error -or -not $m.page_ready -or $m.page_count -ne 3 -or $m.file_name -ne 'document.pdf' -or $m.content_hash -ne $fixture.sha256){throw "WSL PDF hash/name/page mismatch: $hostName"}
 $results+=[pscustomobject]@{host=$hostName;linux_sha256sum=$fixture.sha256;metrics=$m};Write-Output "Passed PDF via $hostName with Linux sha256sum"
}
$results|ConvertTo-Json -Depth 6|Set-Content artifacts\pdf-wsl-results.json -Encoding UTF8
