@echo off
chcp 65001 >nul
call "%~dp0env.cmd"
if errorlevel 1 exit /b 1
powershell -NoProfile -ExecutionPolicy Bypass -File scripts\pe-audit.ps1
exit /b %errorlevel%
