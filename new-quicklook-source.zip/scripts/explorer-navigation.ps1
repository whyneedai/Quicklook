﻿# The Win11 navigation pane can expose only its outer UIA Pane. Its native
# SysTreeView32 still supplies MSAA names/geometry; use that system interface.
Add-Type -AssemblyName Accessibility
Add-Type -ReferencedAssemblies Accessibility @'
using System; using System.Text; using System.Runtime.InteropServices; using Accessibility;
public static class ExplorerNavigation {
 public struct Node { public string name; public int x,y,width,height; }
 delegate bool EnumProc(IntPtr h,IntPtr p);
 [DllImport("user32.dll")] static extern bool EnumChildWindows(IntPtr h,EnumProc callback,IntPtr p);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern int GetClassName(IntPtr h,StringBuilder s,int n);
 [DllImport("oleacc.dll")] static extern int AccessibleObjectFromWindow(IntPtr h,uint id,ref Guid iid,[MarshalAs(UnmanagedType.Interface)] out IAccessible a);
 [DllImport("oleacc.dll")] static extern int AccessibleChildren(IAccessible a,int start,int count,[Out,MarshalAs(UnmanagedType.LPArray,SizeParamIndex=2)] object[] children,out int obtained);
 static Node? Search(IAccessible a,string name,int depth) {
  if(depth>32)return null;
  int count=a.accChildCount;if(count<=0||count>5000)return null;
  var children=new object[count];int obtained;
  if(AccessibleChildren(a,0,count,children,out obtained)<0)return null;
  for(int i=0;i<obtained;i++) {
   IAccessible child=children[i] as IAccessible;
   IAccessible container=child??a;object id=child==null?children[i]:(object)0;
   try {
    if(String.Equals(container.get_accName(id),name,StringComparison.OrdinalIgnoreCase)) {
     int x,y,w,h;container.accLocation(out x,out y,out w,out h,id);
     if(w>0&&h>0)return new Node{name=name,x=x,y=y,width=w,height=h};
    }
    if(child!=null){var found=Search(child,name,depth+1);if(found.HasValue)return found;}
   } catch(COMException) { }
  }
  return null;
 }
 public static Node? Find(IntPtr explorer,string name) {
  Node? found=null;
  EnumProc callback=delegate(IntPtr h,IntPtr unused) {
   var text=new StringBuilder(128);GetClassName(h,text,128);
   if(text.ToString()=="SysTreeView32") {
    var iid=new Guid("618736e0-3c3d-11cf-810c-00aa00389b71");IAccessible a;
    if(AccessibleObjectFromWindow(h,0xfffffffc,ref iid,out a)>=0&&a!=null) {
     try {found=Search(a,name,0);}finally {Marshal.ReleaseComObject(a);}
    }
   }
   return !found.HasValue;
  };
  EnumChildWindows(explorer,callback,IntPtr.Zero);GC.KeepAlive(callback);return found;
 }
}
'@
function Get-ExplorerNavigationNode([IntPtr]$Handle,[string]$Name) {
 [ExplorerNavigation]::Find($Handle,$Name)
}
