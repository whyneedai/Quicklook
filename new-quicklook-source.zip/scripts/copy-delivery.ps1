﻿$ErrorActionPreference='Stop'

$repo = Split-Path $PSScriptRoot -Parent
. "$PSScriptRoot\process-args.ps1"
Set-Location $repo
$release='target\x86_64-pc-windows-msvc\release'
New-Item -ItemType Directory -Force worker,"$release\worker" | Out-Null
$p=Start-Process "$release\new-quicklook.exe" -ArgumentList (Join-ProcessArguments @('--worker-specs',"$repo\worker\manifest.json")) -PassThru
$p.WaitForExit()
if($p.ExitCode -ne 0){throw 'Worker inventory export failed'}
$inventory=Get-Content worker\manifest.json -Raw | ConvertFrom-Json
Copy-Item "$release\new-quicklook.exe" new-quicklook.exe -Force
foreach($spec in $inventory.workers){
 Copy-Item "$release\$($spec.exe)" "worker\$($spec.exe)" -Force
 Copy-Item "$release\$($spec.exe)" "$release\worker\$($spec.exe)" -Force
}
Copy-Item worker\manifest.json "$release\worker\manifest.json" -Force
Write-Output "Copied main program and $(@($inventory.workers).Count) declared workers"
