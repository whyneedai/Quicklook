﻿param([string]$Sample='welcome.md')
$repo = Split-Path $PSScriptRoot -Parent
. "$PSScriptRoot\process-args.ps1"
$repoUri = ([Uri]($repo+'\')).AbsoluteUri.TrimEnd('/')

$ErrorActionPreference='Stop'
Set-Location $repo
$env:TEMP="$repo\.cache\tmp"; $env:TMP=$env:TEMP
New-Item -ItemType Directory -Force $env:TEMP | Out-Null
Add-Type @'
using System;
using System.Runtime.InteropServices;
using System.Text;
public static class WordTest {
 [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
 [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint a,uint b,bool attach);
 [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
 [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
 [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h,IntPtr p);
 [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h,int mode);
 [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] public static extern IntPtr FindWindow(string c,string n);
 [DllImport("user32.dll")] public static extern bool ClientToScreen(IntPtr h,ref POINT p);
 [DllImport("user32.dll")] public static extern bool SetCursorPos(int x,int y);
 [DllImport("user32.dll")] public static extern void mouse_event(uint f,uint dx,uint dy,uint data,UIntPtr extra);
 [DllImport("user32.dll")] public static extern void keybd_event(byte vk,byte scan,uint f,UIntPtr extra);
 [StructLayout(LayoutKind.Sequential)] public struct POINT {public int x;public int y;}
 public static bool Focus(IntPtr h){uint c=GetCurrentThreadId(),f=GetWindowThreadProcessId(GetForegroundWindow(),IntPtr.Zero);bool a=c!=f&&AttachThreadInput(c,f,true);try{ShowWindow(h,9);return SetForegroundWindow(h);}finally{if(a)AttachThreadInput(c,f,false);}}
 public static void Key(byte vk){keybd_event(vk,0,0,UIntPtr.Zero);System.Threading.Thread.Sleep(25);keybd_event(vk,0,2,UIntPtr.Zero);}
 public static void DoubleClick(int x,int y){
   SetCursorPos(x,y); System.Threading.Thread.Sleep(60);
   for(int i=0;i<2;i++){mouse_event(0x0002,0,0,0,UIntPtr.Zero);System.Threading.Thread.Sleep(20);mouse_event(0x0004,0,0,0,UIntPtr.Zero);System.Threading.Thread.Sleep(45);}
 }
}
'@
function Focus-Explorer([IntPtr]$handle) {
 if ([WordTest]::GetForegroundWindow() -ne $handle) { [void][WordTest]::Focus($handle) }
 for($retry=0;$retry -lt 20 -and [WordTest]::GetForegroundWindow() -ne $handle;$retry++) {
  Start-Sleep -Milliseconds 50
  # Alt unlocks the foreground lock so SetForegroundWindow is allowed again.
  [WordTest]::keybd_event(18,0,0,[UIntPtr]::Zero); [WordTest]::keybd_event(18,0,2,[UIntPtr]::Zero)
  [void][WordTest]::Focus($handle)
 }
 if ([WordTest]::GetForegroundWindow() -ne $handle) {throw "Cannot obtain Explorer foreground wanted=$handle actual=$([WordTest]::GetForegroundWindow())"}
 [WordTest]::Key(27)
}
$exe="$repo\target\x86_64-pc-windows-msvc\release\new-quicklook.exe"
$report="$repo\artifacts\word-select.json"
if(Test-Path $report){Remove-Item $report}
$shell=New-Object -ComObject Shell.Application
$before=@($shell.Windows()|ForEach-Object {$_.HWND})
$process=Start-Process $exe -ArgumentList (Join-ProcessArguments @('--trace',$report)) -PassThru
$explorer=$null
try {
 Start-Process explorer.exe -ArgumentList ('"'+$repo+'\samples"') | Out-Null
 for($i=0;$i -lt 40;$i++){Start-Sleep -Milliseconds 150;$explorer=@($shell.Windows()|Where-Object {$_.LocationURL -eq "$repoUri/samples" -and $before -notcontains $_.HWND})|Select-Object -First 1;if($explorer){break}}
 if($null -eq $explorer){throw 'Sample Explorer window not found'}
 $hwnd=[WordTest]::FindWindow('NewQuickLook.Native.Window','new-quicklook')
 for($i=0;$i -lt 40 -and $hwnd -eq [IntPtr]::Zero;$i++){Start-Sleep -Milliseconds 150;$hwnd=[WordTest]::FindWindow('NewQuickLook.Native.Window','new-quicklook')}
 if($hwnd -eq [IntPtr]::Zero){throw 'Resident window missing'}
 Focus-Explorer ([IntPtr]$explorer.HWND)
 $explorer.Document.SelectItem($explorer.Document.Folder.ParseName($Sample),29)
 for($i=0;$i -lt 40;$i++){ $sel=@($explorer.Document.SelectedItems()); if($sel.Count -eq 1 -and $sel[0].Name -eq $Sample){break}; Start-Sleep -Milliseconds 25; $explorer.Document.SelectItem($explorer.Document.Folder.ParseName($Sample),29) }
 [WordTest]::Key(32)
 for($i=0;$i -lt 150 -and -not [WordTest]::IsWindowVisible($hwnd);$i++){Start-Sleep -Milliseconds 20}
 if(-not [WordTest]::IsWindowVisible($hwnd)){throw 'Preview did not open'}
 Start-Sleep -Milliseconds 400
 # first heading line of welcome.md: "# A quieter way to preview" -> click inside "quieter"
 $p=New-Object WordTest+POINT; $p.x=60; $p.y=116
 [void][WordTest]::ClientToScreen($hwnd,[ref]$p)
 [WordTest]::DoubleClick($p.x,$p.y)
 Start-Sleep -Milliseconds 250
 [WordTest]::keybd_event(0x11,0,0,[UIntPtr]::Zero); [WordTest]::keybd_event(0x43,0,0,[UIntPtr]::Zero)
 Start-Sleep -Milliseconds 30
 [WordTest]::keybd_event(0x43,0,2,[UIntPtr]::Zero); [WordTest]::keybd_event(0x11,0,2,[UIntPtr]::Zero)
 Start-Sleep -Milliseconds 300
 $copied=(Get-Clipboard -Raw)
 $firstLine=(Get-Content "$repo\samples\$Sample" -TotalCount 1) -replace '^#\s*',''
 $words=$firstLine -split '\s+' | Where-Object {$_ -ne ''}
 $single = ($copied -ne $null) -and ($copied.Trim() -notmatch '\s')
 $member = $words -contains $copied.Trim()
 $result=[pscustomobject]@{sample=$Sample;first_line=$firstLine;double_click_at="$($p.x),$($p.y)";clipboard=$copied;single_word=$single;is_first_line_word=$member}
 $result | ConvertTo-Json | Set-Content artifacts\word-select-results.json -Encoding UTF8
 Write-Output ("double-click at {0},{1} -> clipboard='{2}' single_word={3} in_first_line={4}" -f $p.x,$p.y,$copied,$single,$member)
 if(-not $single){throw "Double-click did not select a single word: '$copied'"}
 if(-not $member){throw "Selected text '$copied' is not a word of the first line"}
 if($single -and $member){ Write-Output 'Passed double-click word selection (clipboard holds one word from the clicked line)' }
 # Phase 2: a plain single-click drag selects a character range of that line.
 $dragEnd=New-Object WordTest+POINT; $dragEnd.x=200; $dragEnd.y=116
 [void][WordTest]::ClientToScreen($hwnd,[ref]$dragEnd)
 [WordTest]::SetCursorPos($p.x,$p.y); Start-Sleep -Milliseconds 80
 [WordTest]::mouse_event(0x0002,0,0,0,[UIntPtr]::Zero); Start-Sleep -Milliseconds 40
 for($step=0;$step -lt 10;$step++){ $x=$p.x + ($dragEnd.x-$p.x)*($step+1)/10; [WordTest]::SetCursorPos([int]$x,$p.y); Start-Sleep -Milliseconds 30 }
 [WordTest]::mouse_event(0x0004,0,0,0,[UIntPtr]::Zero); Start-Sleep -Milliseconds 150
 [WordTest]::keybd_event(0x11,0,0,[UIntPtr]::Zero); [WordTest]::keybd_event(0x43,0,0,[UIntPtr]::Zero)
 Start-Sleep -Milliseconds 30
 [WordTest]::keybd_event(0x43,0,2,[UIntPtr]::Zero); [WordTest]::keybd_event(0x11,0,2,[UIntPtr]::Zero)
 Start-Sleep -Milliseconds 300
 $dragged=(Get-Clipboard -Raw)
 $inLine = $firstLine.Contains($dragged.Trim())
 Write-Output ("single-click drag to x={0} -> clipboard='{1}' substring_of_line={2}" -f $dragEnd.x,$dragged,$inLine)
 if(-not $inLine){throw "Single-click drag did not select text from the line: '$dragged'"}
 Write-Output 'Passed single-click character drag selection'

 # Phase 3: quoted content in a heading -> the whole inside of the quotes.
 function Open-Sample([string]$name){
  if([WordTest]::IsWindowVisible($hwnd)){
   [WordTest]::Key(27)
   for($w=0;$w -lt 50 -and [WordTest]::IsWindowVisible($hwnd);$w++){Start-Sleep -Milliseconds 20}
  }
  Focus-Explorer ([IntPtr]$explorer.HWND)
  $explorer.Document.SelectItem($explorer.Document.Folder.ParseName($name),29)
  for($i=0;$i -lt 40;$i++){ $sel=@($explorer.Document.SelectedItems()); if($sel.Count -eq 1 -and $sel[0].Name -eq $name){break}; Start-Sleep -Milliseconds 25; $explorer.Document.SelectItem($explorer.Document.Folder.ParseName($name),29) }
  [WordTest]::Key(32)
  for($i=0;$i -lt 150 -and -not [WordTest]::IsWindowVisible($hwnd);$i++){Start-Sleep -Milliseconds 20}
  Start-Sleep -Milliseconds 350
 }
 function Click-Copy([int]$cx,[int]$cy){
  $pt=New-Object WordTest+POINT; $pt.x=$cx; $pt.y=$cy
  [void][WordTest]::ClientToScreen($hwnd,[ref]$pt)
  [WordTest]::DoubleClick($pt.x,$pt.y)
  Start-Sleep -Milliseconds 200
  [WordTest]::keybd_event(0x11,0,0,[UIntPtr]::Zero); [WordTest]::keybd_event(0x43,0,0,[UIntPtr]::Zero)
  Start-Sleep -Milliseconds 30
  [WordTest]::keybd_event(0x43,0,2,[UIntPtr]::Zero); [WordTest]::keybd_event(0x11,0,2,[UIntPtr]::Zero)
  Start-Sleep -Milliseconds 250
  return (Get-Clipboard -Raw)
 }
 if([WordTest]::IsWindowVisible($hwnd)){
  [WordTest]::Key(27)
  for($w=0;$w -lt 50 -and [WordTest]::IsWindowVisible($hwnd);$w++){Start-Sleep -Milliseconds 20}
 }
 Open-Sample 'word-select.md'
 $quoteOk=$false
 foreach($x in @(40, 60, 80, 100, 120)){ $got=Click-Copy $x 116; if($got -eq 'quoted content here'){ $quoteOk=$true; break } }
 Write-Output ("quoted heading: double-click inside quotes -> '{0}' ok={1}" -f $got,$quoteOk)
 if(-not $quoteOk){throw "Double-click inside quotes did not select the quoted content: '$got'"}
 # Phase 4: Chinese words come from ICU segmentation, not the whole CJK run.
 $cjkWords=@('双击','已完成','有待','审查','标记','应该','选择','只有','有待应该')
 $cjkOk=$null; $cjkGot=''
 foreach($y in @(150,160,170,180,190,200,210,220,230)){
  foreach($x in @(60, 100, 140, 180, 220)){
   $got=Click-Copy $x $y
   if($cjkWords -contains $got){ $cjkOk=$got; $cjkGot=$got; break }
  }
  if($null -ne $cjkOk){ break }
 }
 Write-Output ("CJK line: double-click -> '{0}' is_dictionary_word={1}" -f $cjkGot,($null -ne $cjkOk))
 if($null -eq $cjkOk){throw "CJK double-click did not yield a dictionary word (last='$got')"}
 # Phase 5: identifiers stay whole.
 $identOk=$null; $identGot=''
 foreach($y in @(150,160,170,180,190,200,210,220,230)){
  foreach($x in @(60, 80, 100, 120)){
   $got=Click-Copy $x $y
   if($got -eq 'foo_bar'){ $identOk=$got; $identGot=$got; break }
  }
  if($null -ne $identOk){ break }
 }
 Write-Output ("code line: double-click -> '{0}' is_foo_bar={1}" -f $identGot,($null -ne $identOk))
 if($null -eq $identOk){throw "Identifier double-click did not select foo_bar (last='$got')"}
 Write-Output 'Passed quote content, CJK word and identifier selection'

} finally {
 $hwnd=[WordTest]::FindWindow('NewQuickLook.Native.Window','new-quicklook')
 if($hwnd -ne [IntPtr]::Zero){[void][WordTest]::Key(27)}
 if(-not $process.HasExited){Start-Sleep -Milliseconds 300; if(-not $process.HasExited){$process.Kill()}}
 if($null -ne $explorer -and $before -notcontains $explorer.HWND){$explorer.Quit()}
}
