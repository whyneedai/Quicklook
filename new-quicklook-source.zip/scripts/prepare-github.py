"""Export committed source with a fresh, anonymous Git history; never publish it.

Run after committing changes: python scripts/prepare-github.py
Requires Git and Python 3; build prerequisites remain those in README.md.
"""
import argparse
import io
import os
from pathlib import Path
import subprocess
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output', type=Path, default=ROOT / 'artifacts/GitHub Ready/new-quicklook')
args = parser.parse_args()
output = args.output.resolve()
zip_path = output.parent / (output.name + '-source.zip')
if output.exists() or zip_path.exists():
    raise SystemExit('Output already exists; choose a new directory to preserve previous exports')
if subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT).strip():
    raise SystemExit('Commit or set aside source changes before exporting HEAD')
blob = subprocess.check_output(['git', 'archive', '--format=tar', 'HEAD'], cwd=ROOT)
with tarfile.open(fileobj=io.BytesIO(blob)) as archive:
    members = archive.getmembers()
    if any(m.issym() or m.islnk() or not (m.isfile() or m.isdir())
           or Path(m.name).is_absolute() or '..' in Path(m.name).parts for m in members):
        raise SystemExit('Unsupported archive entry')
    output.mkdir(parents=True)
    for member in members:
        target = output / member.name
        if member.isdir():
            target.mkdir(parents=True, exist_ok=True)
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(archive.extractfile(member).read())
# Export only archive members. Local screenshots, caches, binaries and .git never enter it.
with zipfile.ZipFile(zip_path, 'x', compression=zipfile.ZIP_DEFLATED) as package:
    for member in members:
        if member.isfile():
            package.write(output / member.name, arcname=member.name)
env = os.environ.copy()
for key in ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',
            'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES'):
    env.pop(key, None)
for role in ('AUTHOR', 'COMMITTER'):
    env['GIT_' + role + '_NAME'] = 'Quicklook Contributors'
    env['GIT_' + role + '_EMAIL'] = 'contributors@users.noreply.github.com'
# Do not inherit hooks, signing or remotes from the original checkout.
subprocess.run(['git', 'init', '--initial-branch=main', '--template=', str(output)], check=True, env=env)
subprocess.run(['git', '-c', 'core.hooksPath=.git/no-hooks', 'add', '.'], cwd=output, check=True, env=env)
subprocess.run(['git', '-c', 'core.hooksPath=.git/no-hooks', 'commit', '--no-gpg-sign',
                '-m', 'Initial public source'], cwd=output, check=True, env=env,
               stdout=subprocess.DEVNULL)
print('Prepared source repository:', output)
print('Prepared source ZIP:', zip_path)
print('One neutral initial commit; no remote; nothing uploaded.')
