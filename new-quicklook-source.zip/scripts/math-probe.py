"""Run the real Windows worker through bounded binary pipes; project-only artifacts."""
import subprocess, struct, pathlib, time, json
root=pathlib.Path(__file__).resolve().parents[1]
exe=root/'target/x86_64-pc-windows-msvc/release/math-worker.exe'
p=subprocess.Popen([str(exe)],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
results=[]
try:
 for i,tex in enumerate([r'x^2+y^2=z^2',r'\frac{1}{2}',r'\sqrt{x+1}',r'\int_0^1 x^2 dx',r'\sum_{i=1}^n i']):
  start=time.perf_counter();data=tex.encode();p.stdin.write(b'NQM1'+struct.pack('<QQIII',i,1,192,1,len(data))+data);p.stdin.flush()
  header=p.stdout.read(52)
  if len(header)!=52:raise RuntimeError(f'worker stopped {p.poll()}: {header!r}')
  magic,rid,gen,w,h,baseline,n,dpi,convert_us,draw_us,backend=struct.unpack('<4sQQIIIIIIII',header)
  if magic!=b'NQR2':raise RuntimeError(f'bad magic {magic!r}')
  if n>4194304:raise RuntimeError('oversize')
  pixels=p.stdout.read(n)
  results.append(dict(tex=tex,width=w,height=h,baseline=baseline,convert_us=convert_us,draw_us=draw_us,ms=(time.perf_counter()-start)*1000))
  if n:
   header_bmp=struct.pack('<2sIHHI',b'BM',54+n,0,0,54)+struct.pack('<IiiHHIIiiII',40,w,-h,1,32,0,n,0,0,0,0)
   (root/f'artifacts/math-probe-{i}.bmp').write_bytes(header_bmp+pixels)
finally:p.kill();p.wait()
(root/'artifacts/math-probe.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
