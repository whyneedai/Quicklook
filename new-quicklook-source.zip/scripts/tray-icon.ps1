$ErrorActionPreference='Stop'

$repo = Split-Path $PSScriptRoot -Parent
Set-Location $repo
$env:TEMP="$repo\.cache\tmp";$env:TMP=$env:TEMP
Add-Type -AssemblyName System.Drawing
Add-Type @'
using System;using System.Runtime.InteropServices;
public static class TrayAudit {
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] public static extern IntPtr FindWindow(string c,string title);
 [DllImport("user32.dll",EntryPoint="GetClassLongPtrW")] public static extern IntPtr GetClassLongPtr(IntPtr h,int index);
 [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr h,uint m,IntPtr w,IntPtr l);
 [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h,out uint pid);
 [StructLayout(LayoutKind.Sequential)]public struct RECT {public int l,t,r,b;}
 [StructLayout(LayoutKind.Sequential)]public struct Identifier {public uint size;public IntPtr hwnd;public uint id;public Guid guid;}
 [DllImport("shell32.dll")]public static extern int Shell_NotifyIconGetRect(ref Identifier id,out RECT rect);
}
'@
if([TrayAudit]::FindWindow('NewQuickLook.Native.Window','new-quicklook') -ne [IntPtr]::Zero){throw 'Existing instance left untouched'}
$p=Start-Process "$repo\new-quicklook.exe" -PassThru
try {
 $hwnd=[IntPtr]::Zero
 for($n=0;$n -lt 40 -and $hwnd -eq [IntPtr]::Zero;$n++){Start-Sleep -Milliseconds 50;$hwnd=[TrayAudit]::FindWindow('NewQuickLook.Native.Window','new-quicklook')}
 if($hwnd -eq [IntPtr]::Zero){throw 'No app window'}
 [uint32]$owner=0;$null=[TrayAudit]::GetWindowThreadProcessId($hwnd,[ref]$owner);if($owner -ne $p.Id){throw 'Wrong app instance'}
 $handle=[TrayAudit]::GetClassLongPtr($hwnd,-14)
 if($handle -eq [IntPtr]::Zero){throw 'App class icon is NULL'}
 $icon=[System.Drawing.Icon]::FromHandle($handle);$bitmap=$icon.ToBitmap()
 try {
  $nontransparent=0
  for($y=0;$y -lt $bitmap.Height;$y++){for($x=0;$x -lt $bitmap.Width;$x++){if($bitmap.GetPixel($x,$y).A -gt 0){$nontransparent++}}}
  if($nontransparent -eq 0){throw 'Loaded icon has no visible pixels'}
  $bitmap.Save("$repo\artifacts\loaded-tray-icon.png")
 }finally{$bitmap.Dispose();$icon.Dispose()}
 $id=New-Object TrayAudit+Identifier;$id.size=[System.Runtime.InteropServices.Marshal]::SizeOf($id);$id.hwnd=$hwnd;$id.id=1
 $rect=New-Object TrayAudit+RECT
 Start-Sleep -Milliseconds 200
 $status=[TrayAudit]::Shell_NotifyIconGetRect([ref]$id,[ref]$rect)
 if($status -ne 0){throw "Shell has no registered tray icon: $status"}
 [pscustomobject]@{non_null_icon=$true;nontransparent_pixels=$nontransparent;shell_icon_rect=$rect;registered=$true}|ConvertTo-Json -Depth 4|Set-Content artifacts\tray-icon-results.json -Encoding UTF8
 Write-Output 'Tray icon handle, visible pixels and Shell registration verified'
}finally{if(-not $p.HasExited){if($hwnd -ne [IntPtr]::Zero){$null=[TrayAudit]::PostMessage($hwnd,16,[IntPtr]::Zero,[IntPtr]::Zero)};if(-not $p.WaitForExit(5000)){$p.Kill()}}}
