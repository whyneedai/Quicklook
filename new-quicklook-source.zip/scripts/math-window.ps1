﻿$ErrorActionPreference='Stop'

$repo = Split-Path $PSScriptRoot -Parent
. "$PSScriptRoot\process-args.ps1"
Set-Location $repo
$p=Start-Process "$repo\new-quicklook.exe" -ArgumentList (Join-ProcessArguments @("$repo\samples\math.md")) -PassThru
try {
 Start-Sleep -Milliseconds 1000
 $p.Refresh()
 if($p.MainWindowHandle -eq 0){throw 'Math window missing'}
 & "$repo\scripts\capture-window.ps1" -WindowHandle $p.MainWindowHandle -Path "$repo\artifacts\math-window.png"
}finally{if(-not $p.HasExited){[void]$p.CloseMainWindow();if(-not $p.WaitForExit(3000)){$p.Kill()}}}
