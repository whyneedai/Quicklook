﻿$ErrorActionPreference='Stop'

$repo = Split-Path $PSScriptRoot -Parent
Set-Location $repo
. .\scripts\worker-inventory.ps1
$records=@()
$owned=@(Get-ProjectProcesses)
foreach($item in $owned) {
 $records += [pscustomobject]@{pid=$item.ProcessId;path=$item.ExecutablePath}
 if($item.Name -eq 'new-quicklook.exe') {& $item.ExecutablePath --quit}
}
if($owned.Count -gt 0){Start-Sleep -Milliseconds 500}
foreach($item in $owned) {
 $still=Get-CimInstance Win32_Process -Filter "ProcessId=$($item.ProcessId)"
 if($still -and $still.ExecutablePath -eq $item.ExecutablePath) {Stop-Process -Id $item.ProcessId -Force}
}
$remaining=@(Get-ProjectProcesses)
if($remaining.Count){throw 'Project processes remain'}
ConvertTo-Json -InputObject $records -Depth 3 | Set-Content artifacts\stopped-project-processes.json -Encoding UTF8
Write-Output "Verified no project process remains (stopped $($owned.Count))"
