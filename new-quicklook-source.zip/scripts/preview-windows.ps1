﻿# Read-only window probes use the same occlusion rules as native/overlays.rs.
Add-Type @'
using System;using System.Text;using System.Runtime.InteropServices;using System.Collections.Generic;
public static class PreviewWindows {
 [StructLayout(LayoutKind.Sequential)] public struct RECT {public int left,top,right,bottom;}
 [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h,out RECT r);
 [DllImport("user32.dll")] static extern int GetWindowRgnBox(IntPtr h,out RECT r);
 public static int RegionType(IntPtr h){RECT r;return GetWindowRgnBox(h,out r);}
 [DllImport("user32.dll")] static extern int GetWindowLongW(IntPtr h,int i);
 public static bool Topmost(IntPtr h){return (GetWindowLongW(h,-20)&8)!=0;}
 [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
 [DllImport("user32.dll")] public static extern IntPtr GetWindow(IntPtr h,uint command);
 [DllImport("user32.dll")] public static extern IntPtr GetTopWindow(IntPtr h);
 [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern int GetClassName(IntPtr h,StringBuilder c,int count);
 [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h,out uint pid);
 [DllImport("dwmapi.dll")] static extern int DwmGetWindowAttribute(IntPtr h,int attribute,out uint value,int size);
 [StructLayout(LayoutKind.Sequential)] public struct POINT {public int x,y;}
 [DllImport("user32.dll")] static extern bool GetCursorPos(out POINT p);
 [DllImport("user32.dll")] static extern IntPtr WindowFromPoint(POINT p);
 public static POINT Cursor(){POINT p;GetCursorPos(out p);return p;}
 [StructLayout(LayoutKind.Sequential)] public struct GUI {public int cbSize;public uint flags;public IntPtr active,focus,capture,menu,move,caret;public RECT caretRect;}
 [DllImport("user32.dll")] static extern bool GetGUIThreadInfo(uint id,ref GUI info);
 public static GUI Input(){var i=new GUI();i.cbSize=Marshal.SizeOf(i);GetGUIThreadInfo(0,ref i);return i;}
 public static IntPtr UnderCursor(){POINT p;GetCursorPos(out p);return WindowFromPoint(p);}
 public static string Class(IntPtr h){var c=new StringBuilder(256);GetClassName(h,c,256);return c.ToString();}
 public static uint Pid(IntPtr h){uint p;GetWindowThreadProcessId(h,out p);return p;}
 public static uint Cloaked(IntPtr h){uint v;DwmGetWindowAttribute(h,14,out v,4);return v;}
 public static bool Intersects(IntPtr a,IntPtr b){RECT x,y;return GetWindowRect(a,out x)&&GetWindowRect(b,out y)&&x.left<y.right&&x.right>y.left&&x.top<y.bottom&&x.bottom>y.top;}
 public static bool Ignored(string c){return c=="Shell_TrayWnd"||c=="Shell_SecondaryTrayWnd"||c=="Progman"||c=="WorkerW"||c=="tooltips_class32"||c=="#32768"||c=="SysShadow";}
 public static bool Visible(IntPtr h){return IsWindowVisible(h)&&!IsIconic(h)&&Cloaked(h)==0;}
 public static IntPtr[] Above(IntPtr preview){var list=new List<IntPtr>();var h=GetWindow(preview,3);for(int n=0;n<256&&h!=IntPtr.Zero;n++){list.Add(h);h=GetWindow(h,3);}return list.ToArray();}
 public static bool Uncovered(IntPtr preview){if(!Visible(preview))return false;foreach(var h in Above(preview)){if(Visible(h)&&Intersects(h,preview)&&!Ignored(Class(h)))return false;}return Above(preview).Length<256;}
 public static bool ExplorerTip(IntPtr tip,uint sourcePid){uint pid=Pid(tip);if(pid!=0&&pid==sourcePid)return true;var h=GetTopWindow(IntPtr.Zero);for(int n=0;n<512&&h!=IntPtr.Zero;n++){if(Pid(h)==pid&&(Class(h)=="CabinetWClass"||Class(h)=="ExploreWClass"))return true;h=GetWindow(h,2);}return false;}
 public static IntPtr[] Tips(uint pid){var list=new List<IntPtr>();var h=GetTopWindow(IntPtr.Zero);for(int n=0;n<1024&&h!=IntPtr.Zero;n++){if(Class(h)=="tooltips_class32"&&Visible(h)&&(pid==0||Pid(h)==pid))list.Add(h);h=GetWindow(h,2);}return list.ToArray();}
}
'@
function Get-WindowProbe([IntPtr]$Handle) {
 [pscustomobject]@{hwnd=$Handle.ToInt64();class=[PreviewWindows]::Class($Handle);pid=[PreviewWindows]::Pid($Handle);visible=[PreviewWindows]::Visible($Handle);cloaked=[PreviewWindows]::Cloaked($Handle);region_type=[PreviewWindows]::RegionType($Handle);topmost=[PreviewWindows]::Topmost($Handle);rectangle=(Get-TestRect $Handle)}
}
function Get-OverlappingInfotips([IntPtr]$Preview,[IntPtr]$Explorer) {
 @([PreviewWindows]::Above($Preview) | Where-Object {[PreviewWindows]::Class($_) -eq 'tooltips_class32' -and [PreviewWindows]::Visible($_) -and [PreviewWindows]::ExplorerTip($_,[PreviewWindows]::Pid($Explorer)) -and [PreviewWindows]::Intersects($_,$Preview)} | ForEach-Object {Get-WindowProbe $_})
}
