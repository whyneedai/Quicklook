﻿param([string]$Executable='',[string]$Report='freshness-results.json')
$repo = Split-Path $PSScriptRoot -Parent
. "$PSScriptRoot\process-args.ps1"
$repoUri = ([Uri]($repo+'\')).AbsoluteUri.TrimEnd('/')
if(-not $Executable){$Executable="$repo\target\x86_64-pc-windows-msvc\release\new-quicklook.exe"}

$ErrorActionPreference='Stop'
Set-Location $repo
. .\scripts\gui-test.ps1
$env:TEMP="$repo\.cache\tmp"; $env:TMP=$env:TEMP
New-Item -ItemType Directory -Force $env:TEMP | Out-Null
Add-Type @'
using System;
using System.Runtime.InteropServices;
using System.Text;
public static class QlTest {
 [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
 [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint a,uint b,bool attach);
 [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
 [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h,int mode);
 public static bool Focus(IntPtr h) {
   uint current=GetCurrentThreadId(), foreground=GetWindowThreadProcessId(GetForegroundWindow(),IntPtr.Zero);
   bool attached=current!=foreground && AttachThreadInput(current,foreground,true);
   try {ShowWindow(h,9);return SetForegroundWindow(h);} finally {if(attached)AttachThreadInput(current,foreground,false);}
 }

 [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
 [DllImport("user32.dll")] public static extern IntPtr GetClipboardOwner();
 [DllImport("user32.dll")] public static extern uint GetDpiForWindow(IntPtr h);
 [DllImport("user32.dll")] public static extern IntPtr SetThreadDpiAwarenessContext(IntPtr context);
 [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h,IntPtr after,int x,int y,int w,int height,uint flags);
 public static void Ctrl(byte key){keybd_event(17,0,0,UIntPtr.Zero);Key(key);keybd_event(17,0,2,UIntPtr.Zero);}
 public static void MouseMessage(IntPtr h,uint message,int x,int y,int buttons){PostMessage(h,message,(IntPtr)buttons,(IntPtr)((y<<16)|(x&65535)));}

 [DllImport("user32.dll")] public static extern IntPtr FindWindow(string c,string n);
 [DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr h,out RECT r);
 [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
 [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr h,uint m,IntPtr w,IntPtr l);
 [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr h,int n);
 [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h,IntPtr p);
 [DllImport("user32.dll")] public static extern bool GetGUIThreadInfo(uint id,ref GUI info);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] public static extern int GetClassName(IntPtr h,StringBuilder text,int size);
 [DllImport("user32.dll")] public static extern void keybd_event(byte key,byte scan,uint flags,UIntPtr extra);
 [StructLayout(LayoutKind.Sequential)] public struct RECT {public int l,t,r,b;}
 [StructLayout(LayoutKind.Sequential)] public struct GUI {public int size,flags;public IntPtr active,focus,capture,menu,movesize,caret;public RECT rect;}
 public static string FocusClass(IntPtr h) {var g=new GUI();g.size=Marshal.SizeOf(g);GetGUIThreadInfo(GetWindowThreadProcessId(h,IntPtr.Zero),ref g);var s=new StringBuilder(128);GetClassName(g.focus,s,128);return s.ToString();}
 public static void Key(byte key) {keybd_event(key,0,0,UIntPtr.Zero);System.Threading.Thread.Sleep(25);keybd_event(key,0,2,UIntPtr.Zero);}
}
'@
[void][QlTest]::SetThreadDpiAwarenessContext([IntPtr](-4))
function Focus-Explorer([IntPtr]$handle) {
 if ([QlTest]::GetForegroundWindow() -ne $handle) {
  [void][QlTest]::Focus($handle)
  if ([QlTest]::GetForegroundWindow() -ne $handle) {
   [QlTest]::keybd_event(18,0,0,[UIntPtr]::Zero);[QlTest]::keybd_event(18,0,2,[UIntPtr]::Zero)
   [void][QlTest]::Focus($handle)
  }
 }
 for($focusRetry=0;$focusRetry -lt 20 -and [QlTest]::GetForegroundWindow() -ne $handle;$focusRetry++) {
  Start-Sleep -Milliseconds 50
  [QlTest]::keybd_event(18,0,0,[UIntPtr]::Zero);[QlTest]::keybd_event(18,0,2,[UIntPtr]::Zero)
  [void][QlTest]::Focus($handle)
 }
 if ([QlTest]::GetForegroundWindow() -ne $handle) {throw "Cannot obtain Explorer foreground wanted=$handle actual=$([QlTest]::GetForegroundWindow())"}
 # Close menus left by a foreground unlock; never send Alt when Explorer is already active.
 [QlTest]::Key(27)
}
$exe=$Executable
if ([QlTest]::FindWindow('NewQuickLook.Native.Window','new-quicklook') -ne [IntPtr]::Zero) {throw 'An existing new-quicklook instance is open; leave it untouched and exit it before this test.'}
$shell=New-Object -ComObject Shell.Application
$before=@($shell.Windows() | ForEach-Object {$_.HWND})
$explorer=$null
$process=Start-Process $exe -ArgumentList (Join-ProcessArguments @('--trace',"$repo\artifacts\interaction-current.json")) -PassThru
Add-Type @'
public static class IdentityHash {
 public static string Hash(string s) {ulong h=14695981039346656037UL;foreach(byte b in System.Text.Encoding.UTF8.GetBytes(s))h=unchecked((h^b)*1099511628211UL);return h.ToString("x16");}
}
'@
$results=@()
try {
 Start-Process explorer.exe -ArgumentList ('"'+$repo+'\samples"')
 for ($i=0;$i -lt 40;$i++) {
  Start-Sleep -Milliseconds 150
  $explorer=@($shell.Windows() | Where-Object {$_.LocationURL -eq "$repoUri/samples" -and $before -notcontains $_.HWND}) | Select-Object -First 1
  if ($null -ne $explorer) {break}
 }
 if ($null -eq $explorer) {throw 'Sample Explorer window not found'}
 for ($i=0;$i -lt 40;$i++) {
  $hwnd=[QlTest]::FindWindow('NewQuickLook.Native.Window','new-quicklook')
  if ($hwnd -ne [IntPtr]::Zero) {break}
  Start-Sleep -Milliseconds 150
 }
 if ($hwnd -eq [IntPtr]::Zero) {throw 'Resident window missing'}


 [IO.File]::WriteAllText("$repo\samples\identity-final.txt",'LATEST-FILE-MUST-STAY')
 for($round=0;$round -lt 6;$round++) {
  $mathName="math-stale-$round.md"
  $mathText=(0..63|ForEach-Object {'$$\frac{'+($_+$round*64)+'}{a+b}$$'}) -join "`n`n"
  [IO.File]::WriteAllText("$repo\samples\$mathName",$mathText)
  Start-Sleep -Milliseconds 300
  if([QlTest]::IsWindowVisible($hwnd)){[QlTest]::Key(27)}
  Focus-Explorer ([IntPtr]$explorer.HWND)
  $explorer.Document.SelectItem($explorer.Document.Folder.ParseName($mathName),29)
  Start-Sleep -Milliseconds 100
  [QlTest]::Key(32)
  $pending=$false
  for($i=0;$i -lt 100;$i++) {
   Start-Sleep -Milliseconds 10
   try{$m=Get-Content artifacts\interaction-current.json -Raw|ConvertFrom-Json}catch{continue}
   if($m.file_name -eq $mathName -and $m.math_pending -gt 0 -and $null -ne $m.first_content_paint_ms){$pending=$true;break}
  }
  if(-not $pending){throw 'Did not observe asynchronous formula phase'}
  [QlTest]::Key(27)
  Focus-Explorer ([IntPtr]$explorer.HWND)
  $explorer.Document.SelectItem($explorer.Document.Folder.ParseName('identity-final.txt'),29)
  Start-Sleep -Milliseconds 100
  [QlTest]::Key(32)
  for($i=0;$i -lt 100;$i++) {
   Start-Sleep -Milliseconds 10
   try{$m=Get-Content artifacts\interaction-current.json -Raw|ConvertFrom-Json}catch{continue}
   if($m.file_name -eq 'identity-final.txt' -and $null -ne $m.first_content_paint_ms){break}
  }
  for($i=0;$i -lt 25;$i++) {
   Start-Sleep -Milliseconds 20
   $m=Get-Content artifacts\interaction-current.json -Raw|ConvertFrom-Json
   if($m.file_name -ne 'identity-final.txt' -or $m.body_hash -ne [IdentityHash]::Hash('LATEST-FILE-MUST-STAY') -or $m.math_ready -ne 0){throw 'Late math result replaced the current file'}
  }
  $results+=$m
 }
 $results|ConvertTo-Json -Depth 5|Set-Content artifacts\stale-math-results.json -Encoding UTF8
 Write-Output 'Passed 6 cancellations during pending math; latest file identity and content stayed correct'
} finally {
 $hwnd=[QlTest]::FindWindow('NewQuickLook.Native.Window','new-quicklook')
 if ($hwnd -ne [IntPtr]::Zero) {[void][QlTest]::PostMessage($hwnd,16,[IntPtr]::Zero,[IntPtr]::Zero)}
 if (-not $process.WaitForExit(5000)) {$process.Kill()}
 Close-TestExplorer $explorer $before
}
