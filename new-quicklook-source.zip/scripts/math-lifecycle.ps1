﻿param([int]$Rounds=5,[switch]$Features,[switch]$Layout,[switch]$Navigation)
$repo = Split-Path $PSScriptRoot -Parent
. "$PSScriptRoot\process-args.ps1"
$repoUri = ([Uri]($repo+'\')).AbsoluteUri.TrimEnd('/')

$ErrorActionPreference='Stop'
Set-Location $repo
. .\scripts\gui-test.ps1
$env:TEMP="$repo\.cache\tmp"; $env:TMP=$env:TEMP
New-Item -ItemType Directory -Force $env:TEMP | Out-Null
Add-Type @'
using System;
using System.Runtime.InteropServices;
using System.Text;
public static class QlTest {
 [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
 [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint a,uint b,bool attach);
 [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
 [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h,int mode);
 public static bool Focus(IntPtr h) {
   uint current=GetCurrentThreadId(), foreground=GetWindowThreadProcessId(GetForegroundWindow(),IntPtr.Zero);
   bool attached=current!=foreground && AttachThreadInput(current,foreground,true);
   try {ShowWindow(h,9);return SetForegroundWindow(h);} finally {if(attached)AttachThreadInput(current,foreground,false);}
 }

 [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
 [DllImport("user32.dll")] public static extern IntPtr GetClipboardOwner();
 [DllImport("user32.dll")] public static extern uint GetDpiForWindow(IntPtr h);
 [DllImport("user32.dll")] public static extern IntPtr SetThreadDpiAwarenessContext(IntPtr context);
 [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h,IntPtr after,int x,int y,int w,int height,uint flags);
 public static void Ctrl(byte key){keybd_event(17,0,0,UIntPtr.Zero);Key(key);keybd_event(17,0,2,UIntPtr.Zero);}
 public static void MouseMessage(IntPtr h,uint message,int x,int y,int buttons){PostMessage(h,message,(IntPtr)buttons,(IntPtr)((y<<16)|(x&65535)));}

 [DllImport("user32.dll")] public static extern IntPtr FindWindow(string c,string n);
 [DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr h,out RECT r);
 [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
 [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr h,uint m,IntPtr w,IntPtr l);
 [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr h,int n);
 [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h,IntPtr p);
 [DllImport("user32.dll")] public static extern bool GetGUIThreadInfo(uint id,ref GUI info);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] public static extern int GetClassName(IntPtr h,StringBuilder text,int size);
 [DllImport("user32.dll")] public static extern void keybd_event(byte key,byte scan,uint flags,UIntPtr extra);
 [DllImport("user32.dll")] public static extern bool ClientToScreen(IntPtr h,ref POINT p);
 [DllImport("user32.dll")] public static extern bool SetCursorPos(int x,int y);
 [DllImport("user32.dll")] public static extern void mouse_event(uint f,uint dx,uint dy,uint data,UIntPtr extra);
 [StructLayout(LayoutKind.Sequential)] public struct POINT {public int x;public int y;}
 [StructLayout(LayoutKind.Sequential)] public struct RECT {public int l,t,r,b;}
 [StructLayout(LayoutKind.Sequential)] public struct GUI {public int size,flags;public IntPtr active,focus,capture,menu,movesize,caret;public RECT rect;}
 public static string FocusClass(IntPtr h) {var g=new GUI();g.size=Marshal.SizeOf(g);GetGUIThreadInfo(GetWindowThreadProcessId(h,IntPtr.Zero),ref g);var s=new StringBuilder(128);GetClassName(g.focus,s,128);return s.ToString();}
 public static void Key(byte key) {keybd_event(key,0,0,UIntPtr.Zero);System.Threading.Thread.Sleep(25);keybd_event(key,0,2,UIntPtr.Zero);}
}
'@
[void][QlTest]::SetThreadDpiAwarenessContext([IntPtr](-4))
function Focus-Explorer([IntPtr]$handle) {
 if ([QlTest]::GetForegroundWindow() -ne $handle) {
  [void][QlTest]::Focus($handle)
  if ([QlTest]::GetForegroundWindow() -ne $handle) {
   [QlTest]::keybd_event(18,0,0,[UIntPtr]::Zero);[QlTest]::keybd_event(18,0,2,[UIntPtr]::Zero)
   [void][QlTest]::Focus($handle)
  }
 }
 for($focusRetry=0;$focusRetry -lt 20 -and [QlTest]::GetForegroundWindow() -ne $handle;$focusRetry++) {
  Start-Sleep -Milliseconds 50
  [QlTest]::keybd_event(18,0,0,[UIntPtr]::Zero);[QlTest]::keybd_event(18,0,2,[UIntPtr]::Zero)
  [void][QlTest]::Focus($handle)
 }
 if ([QlTest]::GetForegroundWindow() -ne $handle) {throw "Cannot obtain Explorer foreground wanted=$handle actual=$([QlTest]::GetForegroundWindow())"}
 # Close menus left by a foreground unlock; never send Alt when Explorer is already active.
 [QlTest]::Key(27)
}
$exe="$repo\target\x86_64-pc-windows-msvc\release\new-quicklook.exe"
if ([QlTest]::FindWindow('NewQuickLook.Native.Window','new-quicklook') -ne [IntPtr]::Zero) {throw 'An existing new-quicklook instance is open; leave it untouched and exit it before this test.'}
$shell=New-Object -ComObject Shell.Application
$before=@($shell.Windows() | ForEach-Object {$_.HWND})
$explorer=$null
if(Test-Path artifacts\interaction-current.json){Remove-Item artifacts\interaction-current.json}
$script:MathGeneration=0
$process=Start-Process $exe -ArgumentList (Join-ProcessArguments @('--trace',"$repo\artifacts\interaction-current.json")) -PassThru
Add-Type @'
public static class IdentityHash {
 [System.Runtime.InteropServices.DllImport("user32.dll")] public static extern uint GetGuiResources(System.IntPtr process,uint flags);
 public static string Hash(string s) {ulong h=14695981039346656037UL;foreach(byte b in System.Text.Encoding.UTF8.GetBytes(s))h=unchecked((h^b)*1099511628211UL);return h.ToString("x16");}
}
'@
$results=@()
try {
 Start-Process explorer.exe -ArgumentList ('"'+$repo+'\samples"')
 for ($i=0;$i -lt 40;$i++) {
  Start-Sleep -Milliseconds 150
  $explorer=@($shell.Windows() | Where-Object {$_.LocationURL -eq "$repoUri/samples" -and $before -notcontains $_.HWND}) | Select-Object -First 1
  if ($null -ne $explorer) {break}
 }
 if ($null -eq $explorer) {throw 'Sample Explorer window not found'}
 for ($i=0;$i -lt 40;$i++) {
  $hwnd=[QlTest]::FindWindow('NewQuickLook.Native.Window','new-quicklook')
  if ($hwnd -ne [IntPtr]::Zero) {break}
  Start-Sleep -Milliseconds 150
 }
 if ($hwnd -eq [IntPtr]::Zero) {throw 'Resident window missing'}


 function Open-Math($name,$expected) {
  $last=$null
  for($attempt=0;$attempt -lt 3;$attempt++) {
   if([QlTest]::IsWindowVisible($hwnd)){
    [QlTest]::Key(27)
    # The app writes one report on the Esc keydown (old content) before hiding;
    # wait until it is really hidden so that report cannot land after the removal.
    for($w=0;$w -lt 50 -and [QlTest]::IsWindowVisible($hwnd);$w++){Start-Sleep -Milliseconds 20}
   }
   Focus-Explorer ([IntPtr]$explorer.HWND)
   $explorer.Document.SelectItem($explorer.Document.Folder.ParseName($name),29)
   for($s=0;$s -lt 50;$s++){
    $sel=@($explorer.Document.SelectedItems())
    if($sel.Count -eq 1 -and $sel[0].Name -eq $name){break}
    Start-Sleep -Milliseconds 20
    $explorer.Document.SelectItem($explorer.Document.Folder.ParseName($name),29)
   }
   Start-Sleep -Milliseconds 100
   if(Test-Path artifacts\interaction-current.json){Remove-Item artifacts\interaction-current.json}
   [QlTest]::Key(32)
   $m=$null
   for($n=0;$n -lt 150;$n++) {
    Start-Sleep -Milliseconds 20
    try{$m=Get-Content artifacts\interaction-current.json -Raw|ConvertFrom-Json}catch{continue}
    if($m.generation -gt $script:MathGeneration -and $m.file_name -eq $name -and $m.math_pending -eq 0 -and $m.math_ready -eq $expected -and $null -ne $m.first_content_paint_ms){$script:MathGeneration=$m.generation;return $m}
   }
   $last=$m
   # Diagnose focus/selection races instead of failing blind, then retry.
   $owner=''
   if($m -and $m.shell_resolution -match 'owner=HWND\(0x([0-9a-f]+)\)'){$owner=[Convert]::ToInt64($Matches[1],16)}
   Write-Output ("Open-Math retry: want={0} got_file={1} ready={2} fb={3} owner={4} our_explorer={5}" -f $name,$m.file_name,$m.math_ready,$m.math_fallback,$owner,$explorer.HWND)
   Start-Sleep -Milliseconds 300
  }
  throw "Math preview failed: $name $($last|ConvertTo-Json -Compress)"
 }
 function Owned-Worker {
  @(Get-CimInstance Win32_Process -Filter "ParentProcessId=$($process.Id) AND Name='math-worker.exe'")
 }
 if(@(Owned-Worker).Count -ne 0){throw 'Worker started without math'}
 $first=Open-Math 'math-fast.md' 3
 # The preview never steals the focus: ensure its real client click reaches it.
 Focus-TestWindow $hwnd
 $pt=New-Object QlTest+POINT; $pt.x=400; $pt.y=400
 [void][QlTest]::ClientToScreen($hwnd,[ref]$pt)
 [QlTest]::SetCursorPos($pt.x,$pt.y); Start-Sleep -Milliseconds 80
 [QlTest]::mouse_event(0x0002,0,0,0,[UIntPtr]::Zero); Start-Sleep -Milliseconds 30
 [QlTest]::mouse_event(0x0004,0,0,0,[UIntPtr]::Zero); Start-Sleep -Milliseconds 250
 [QlTest]::Ctrl(65);[QlTest]::Ctrl(67);Start-Sleep -Milliseconds 100
 if([QlTest]::GetClipboardOwner() -ne $hwnd){throw 'Math copy not owned by preview'}
 $copied=Get-Clipboard -Raw
 if(-not $copied.Contains('\frac{1}{2}') -or -not $copied.Contains('x^2')){throw 'Math copy lost LaTeX source'}
 $children=@(Owned-Worker)
 if($children.Count -ne 1){throw 'Expected one formula worker'}
 $workerPid=$children[0].ProcessId
 for($i=0;$i -lt 24;$i++) {
  $m=Open-Math 'math-fast.md' 3
  $wp=Get-Process -Id $workerPid
  $process.Refresh()
  $results += [pscustomobject]@{metrics=$m;worker_private=$wp.PrivateMemorySize64;worker_gdi=[IdentityHash]::GetGuiResources($wp.Handle,0);app_private=$process.PrivateMemorySize64;app_gdi=[IdentityHash]::GetGuiResources($process.Handle,0)}
 }
 # Kill only this test's worker; first uncached request falls back, next request recovers.
 [IO.File]::WriteAllText("$repo\samples\math-crash.md",'$$\sqrt{1234567}$$')
 Start-Sleep -Milliseconds 500
 Stop-Process -Id $workerPid
 $crash=Open-Math 'math-crash.md' 0
 if($crash.math_fallback -ne 1){throw 'Worker crash did not preserve source fallback'}
 $recovered=Open-Math 'math-crash.md' 1
 $children=@(Owned-Worker)
 $recoveredPid=$children[0].ProcessId
 # Idle process and cache are reclaimed after 30 seconds, without closing the app.
 Start-Sleep -Seconds 32
 if(@(Owned-Worker).Count -ne 0){throw 'Idle worker did not exit'}
 $restarted=Open-Math 'math-crash.md' 1
 $newChildren=@(Owned-Worker)
 if($newChildren.Count -ne 1 -or $newChildren[0].ProcessId -eq $recoveredPid){throw 'Worker did not restart after idle'}
 $childPid=$newChildren[0].ProcessId
 [void][QlTest]::PostMessage($hwnd,16,[IntPtr]::Zero,[IntPtr]::Zero)
 [void]$process.WaitForExit(5000)
 Start-Sleep -Milliseconds 200
 if(Get-Process -Id $childPid -ErrorAction SilentlyContinue){throw 'Worker survived parent shutdown'}
 [pscustomobject]@{cold=$first;warm=$results;crash=$crash;recovered=$recovered;idle_restart=$restarted;parent_exit_killed_worker=$true}|ConvertTo-Json -Depth 7|Set-Content artifacts\math-lifecycle-results.json -Encoding UTF8
 Write-Output 'Passed worker lazy start, reuse, 24 warm previews, crash fallback/recovery, idle exit and parent exit cleanup'
} finally {
 $hwnd=[QlTest]::FindWindow('NewQuickLook.Native.Window','new-quicklook')
 if ($hwnd -ne [IntPtr]::Zero) {[void][QlTest]::PostMessage($hwnd,16,[IntPtr]::Zero,[IntPtr]::Zero)}
 if (-not $process.WaitForExit(5000)) {$process.Kill()}
 Close-TestExplorer $explorer $before
}
