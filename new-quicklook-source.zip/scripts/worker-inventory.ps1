﻿
$repo = Split-Path $PSScriptRoot -Parent
function Get-WorkerInventory {
 $path="$repo\worker\manifest.json"
 if(Test-Path $path){return (Get-Content $path -Raw | ConvertFrom-Json)}
 # Bootstrap an older delivery; later inventories always come from Rust specs.
 return [pscustomobject]@{workers=@([pscustomobject]@{exe='math-worker.exe'})}
}
function Get-ProjectProcesses {
 $names=@('new-quicklook.exe')+@((Get-WorkerInventory).workers|ForEach-Object {$_.exe})
 $filter=($names|ForEach-Object {"Name='$_'"}) -join ' OR '
 @(Get-CimInstance Win32_Process -Filter $filter | Where-Object {$_.ExecutablePath -and $_.ExecutablePath.StartsWith("$repo\",[StringComparison]::OrdinalIgnoreCase)})
}
