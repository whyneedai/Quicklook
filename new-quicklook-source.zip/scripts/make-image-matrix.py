"""Generate the PNG part of the WIC comparison matrix (pure Python, incl. real Adam7).

Outputs to samples/matrix/; GIF fixtures are already checked into the repository.
"""
import pathlib, struct, zlib

ROOT = pathlib.Path(__file__).resolve().parents[1]
OUT = ROOT / 'samples/matrix'

def chunk(tag, data):
    return struct.pack('>I', len(data)) + tag + data + struct.pack('>I', zlib.crc32(tag + data) & 0xffffffff)

def write_png(path, w, h, color_type, bit_depth, rows, palette=None, interlace=0):
    """rows: list of raw scanline bytes (no filter byte)."""
    ihdr = struct.pack('>IIBBBBB', w, h, bit_depth, color_type, 0, 0, interlace)
    data = b''
    for row in rows:
        data += b'\x00' + row
    out = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', ihdr)
    if palette:
        out += chunk(b'PLTE', palette)
    out += chunk(b'IDAT', zlib.compress(data, 6)) + chunk(b'IEND', b'')
    path.write_bytes(out)
    print(path, len(out))

def rgb_rows(w, h):
    return [bytes(v for x in range(w) for v in ((x * 255) // w, (y * 255) // h, 128)) for y in range(h)]

def rgba_rows(w, h):
    return [bytes(v for x in range(w) for v in ((x * 255) // w, 64, (y * 255) // h, (x * 255) // w)) for y in range(h)]

def gray_rows(w, h):
    return [bytes(((x + y) * 255) // (w + h) for x in range(w)) for y in range(h)]

def adam7_rows(w, h, base):
    """Real Adam7 interlacing: 7 passes, each a sub-image with filter bytes."""
    passes = [(0,0,8,8),(4,0,8,8),(0,4,4,8),(2,0,4,4),(0,2,2,4),(1,0,2,2),(0,1,1,2)]
    out = b''
    for (xs, ys, xstep, ystep) in passes:
        pw = len(range(xs, w, xstep)); ph = len(range(ys, h, ystep))
        if pw == 0 or ph == 0:
            continue
        for y in range(ys, h, ystep):
            row = bytearray()
            for x in range(xs, w, xstep):
                row += base(x, y)
            out += b'\x00' + bytes(row)
    return out

def interlaced_png(path, w, h):
    raw = adam7_rows(w, h, lambda x, y: bytes(((x * 255) // w, (y * 255) // h, 200)))
    ihdr = struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 1)
    out = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', ihdr) + chunk(b'IDAT', zlib.compress(raw, 6)) + chunk(b'IEND', b'')
    path.write_bytes(out); print(path, len(out))

OUT.mkdir(parents=True, exist_ok=True)
write_png(OUT/'png-rgb-320x200.png', 320, 200, 2, 8, rgb_rows(320, 200))
write_png(OUT/'png-rgb-1024x768.png', 1024, 768, 2, 8, rgb_rows(1024, 768))
write_png(OUT/'png-rgba-800x600.png', 800, 600, 6, 8, rgba_rows(800, 600))
write_png(OUT/'png-gray-800x600.png', 800, 600, 0, 8, gray_rows(800, 600))
pal = bytes(v for i in range(256) for v in (i, 255 - i, (i * 3) % 256))
write_png(OUT/'png-palette-800x600.png', 800, 600, 3, 8,
          [bytes((x + y) % 256 for x in range(800)) for y in range(600)], palette=pal)
write_png(OUT/'png-16bit-512x512.png', 512, 512, 0, 16,
          [b''.join(struct.pack('>H', ((x + y) * 65535) // 1024) for x in range(512)) for y in range(512)])
interlaced_png(OUT/'png-interlaced-800x600.png', 800, 600)
big = ROOT / 'samples/big.png'
if big.exists():
    (OUT/'png-large-4096x3072.png').write_bytes(big.read_bytes())
    print(OUT/'png-large-4096x3072.png', big.stat().st_size)
