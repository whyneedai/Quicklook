﻿function New-TestImageFixtures {
 $repository=Split-Path $PSScriptRoot -Parent
 $folder=Join-Path $repository 'artifacts\issue-image-fixtures'
 New-Item -ItemType Directory -Force $folder | Out-Null
 $images=@('big.png','gradient.png','small.png')
 for($imageIndex=0;$imageIndex -lt $images.Count;$imageIndex++) {
  Copy-Item (Join-Path "$repository\samples" $images[$imageIndex]) (Join-Path $folder "$($imageIndex+1).png") -Force
 }
 return $folder
}
