﻿$ErrorActionPreference='Stop'

$repo = Split-Path $PSScriptRoot -Parent
. "$PSScriptRoot\process-args.ps1"
Set-Location $repo
$env:TEMP="$repo\.cache\tmp"; $env:TMP=$env:TEMP
New-Item -ItemType Directory -Force $env:TEMP | Out-Null
$extensions=@('txt','log','ini','cfg','conf','properties','json','xml','csv','tsv','toml','yaml','yml','js','ts','jsx','tsx','go','java','c','h','cpp','hpp','sh','bash','css','html','php','lua','sql','kt','swift','r','ps1','psm1','psd1','cmd','bat','rb','cs','mjs','cjs','scss','less','zsh','htm','svg','proto','tf','diff','srt','vtt','tex','sty','bib')
$exe="$repo\new-quicklook.exe"
$results=@()
foreach($ext in $extensions) {
 $report="$repo\artifacts\source-$ext.json"
 if(Test-Path $report){Remove-Item $report}
 $process=Start-Process $exe -ArgumentList (Join-ProcessArguments @('--smoke',"$repo\samples\formats\example.$ext",$report)) -PassThru
 if(-not $process.WaitForExit(15000)){$process.Kill();throw "Timeout: $ext"}
 if($process.ExitCode -ne 0){throw "Crash: $ext"}
 $data=Get-Content $report -Raw | ConvertFrom-Json
 $table=$ext -in @('csv','tsv')
 $expectedMode=if($table){'RENDERED'}else{'SOURCE'}
 if($data.error -or $data.format -ne $ext -or $data.mode -ne $expectedMode -or $data.line_numbers -eq $table -or $null -eq $data.first_content_paint_ms){throw "Bad preview: $ext"}
 $results += [pscustomobject]@{extension=$ext;metrics=$data}
}
$results | ConvertTo-Json -Depth 5 | Set-Content artifacts\source-formats-results.json -Encoding UTF8
Write-Output "Passed: $($results.Count) independent Windows source previews"
