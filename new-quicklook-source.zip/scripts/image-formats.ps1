﻿$ErrorActionPreference='Stop'

$repo = Split-Path $PSScriptRoot -Parent
. "$PSScriptRoot\process-args.ps1"
Set-Location $repo
$env:TEMP="$repo\.cache\tmp";$env:TMP=$env:TEMP
$results=@()
foreach($file in @('example.jpeg','example.jpg','example.jfif','example.gif','example.webp','alpha.webp','animated.webp','oversized.webp','example.bmp','example.ico','example.tiff','example.dds','example.cur','interlaced.png','broken.jpeg','broken.gif','broken.webp','broken.bmp','broken.ico','broken.tiff','broken.dds','broken.cur','broken.heic')) {
 $report="$repo\artifacts\image-$file.json"
 if(Test-Path $report){Remove-Item $report}
 $p=Start-Process "$repo\new-quicklook.exe" -ArgumentList (Join-ProcessArguments @('--smoke',"$repo\samples\images\$file",$report)) -PassThru
 $indices=@()
 try {
  $until=[DateTime]::UtcNow.AddSeconds(15)
  while(-not $p.HasExited -and [DateTime]::UtcNow -lt $until){
   if($file -in @('example.gif','animated.webp') -and (Test-Path $report)){
    try{$d=Get-Content $report -Raw | ConvertFrom-Json;if($d.frame_count -eq 3){$indices+=$d.frame_index}}catch{}
   }
   Start-Sleep -Milliseconds 25
  }
  if(-not $p.HasExited){throw "Timed out: $file"}
  $p.WaitForExit()
  if($p.ExitCode -ne 0){throw "Crash: $file"}
  $d=Get-Content $report -Raw | ConvertFrom-Json
  if(($file.StartsWith('broken.') -or $file -eq 'oversized.webp')){if(-not $d.error){throw "Malformed image accepted: $file"}}
  elseif($d.error -or $null -eq $d.first_content_paint_ms -or $d.image_width -le 0 -or $d.image_width -gt 1600 -or $d.image_height -gt 1200){throw "Preview failed: $file $($d | ConvertTo-Json -Compress)"}
  if(-not $d.icon_loaded){throw 'Resource icon did not load'}
  $unique=@($indices|Sort-Object -Unique)
  if($file -in @('example.gif','animated.webp') -and $unique.Count -ne 3){throw "Animation did not present all frames: $unique"}
  $results+=[pscustomobject]@{file=$file;metrics=$d;observed_frames=$unique}
 }finally{if(-not $p.HasExited){$p.Kill();$p.WaitForExit()}}
}
$results|ConvertTo-Json -Depth 6|Set-Content artifacts\image-formats-results.json -Encoding UTF8
Write-Output "Passed $($results.Count) Windows image cases, including all GIF animation frames and icon handle"
