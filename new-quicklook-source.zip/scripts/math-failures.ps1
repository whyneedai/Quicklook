﻿$ErrorActionPreference='Stop'

$repo = Split-Path $PSScriptRoot -Parent
. "$PSScriptRoot\process-args.ps1"
Set-Location $repo
$env:TEMP="$repo\.cache\tmp";$env:TMP=$env:TEMP
$results=@()
foreach($kind in @('missing','timeout','malformed')) {
 $root="$repo\artifacts\math-fault-$kind"
 [void](New-Item -ItemType Directory -Force "$root\worker")
 Copy-Item "$repo\new-quicklook.exe" "$root\new-quicklook.exe" -Force
 $helper="$root\worker\math-worker.exe"
 if($kind -ne 'missing') {
  if(Test-Path $helper){Remove-Item $helper}
  $body=if($kind -eq 'timeout'){'System.Threading.Thread.Sleep(60000);'}else{'byte[] h=new byte[52];h[0]=78;h[1]=81;h[2]=82;h[3]=50;for(int i=20;i<52;i++)h[i]=255;System.Console.OpenStandardOutput().Write(h,0,h.Length);System.Threading.Thread.Sleep(60000);'}
  Add-Type -TypeDefinition "public static class Fault_$kind {public static void Main(){$body}}" -OutputAssembly $helper -OutputType ConsoleApplication
 }
 $report="$root\result.json"
 $p=Start-Process "$root\new-quicklook.exe" -ArgumentList (Join-ProcessArguments @('--smoke',"$repo\samples\math-fast.md",$report)) -PassThru
 try {
  if(-not $p.WaitForExit(10000)){throw "Fault test hung: $kind"}
  $m=Get-Content $report -Raw|ConvertFrom-Json
  if($m.error -or $m.math_pending -ne 0 -or $m.math_fallback -ne 3 -or $m.math_ready -ne 0){throw "Fault did not safely fall back: $kind $($m|ConvertTo-Json -Compress)"}
  $left=@(Get-CimInstance Win32_Process -Filter "Name='math-worker.exe'"|Where-Object ExecutablePath -eq $helper)
  if($left.Count){throw "Fault worker survived: $kind"}
  $results+=[pscustomobject]@{kind=$kind;metrics=$m;worker_cleaned=$true}
 }finally{if(-not $p.HasExited){$p.Kill();$p.WaitForExit()}}
}
$results|ConvertTo-Json -Depth 6|Set-Content artifacts\math-failure-results.json -Encoding UTF8
Write-Output 'Passed missing worker, 1-second timeout, malformed IPC, source fallback and child cleanup'
