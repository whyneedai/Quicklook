﻿param([int]$Rounds=5,[switch]$Features,[switch]$Layout,[switch]$Navigation)
$repo = Split-Path $PSScriptRoot -Parent
. "$PSScriptRoot\process-args.ps1"
$repoUri = ([Uri]($repo+'\')).AbsoluteUri.TrimEnd('/')

$ErrorActionPreference='Stop'
Set-Location $repo
$env:TEMP="$repo\.cache\tmp"; $env:TMP=$env:TEMP
New-Item -ItemType Directory -Force $env:TEMP | Out-Null
Add-Type @'
using System;
using System.Runtime.InteropServices;
using System.Text;
public static class QlTest {
 [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
 [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint a,uint b,bool attach);
 [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
 [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h,int mode);
 public static bool Focus(IntPtr h) {
   uint current=GetCurrentThreadId(), foreground=GetWindowThreadProcessId(GetForegroundWindow(),IntPtr.Zero);
   bool attached=current!=foreground && AttachThreadInput(current,foreground,true);
   try {ShowWindow(h,9);return SetForegroundWindow(h);} finally {if(attached)AttachThreadInput(current,foreground,false);}
 }

 [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
 [DllImport("user32.dll")] public static extern IntPtr GetClipboardOwner();
 [DllImport("user32.dll")] public static extern uint GetDpiForWindow(IntPtr h);
 [DllImport("user32.dll")] public static extern IntPtr SetThreadDpiAwarenessContext(IntPtr context);
 [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h,IntPtr after,int x,int y,int w,int height,uint flags);
 public static void Ctrl(byte key){keybd_event(17,0,0,UIntPtr.Zero);Key(key);keybd_event(17,0,2,UIntPtr.Zero);}
 public static void MouseMessage(IntPtr h,uint message,int x,int y,int buttons){PostMessage(h,message,(IntPtr)buttons,(IntPtr)((y<<16)|(x&65535)));}

 [DllImport("user32.dll")] public static extern IntPtr FindWindow(string c,string n);
 [DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr h,out RECT r);
 [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
 [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr h,uint m,IntPtr w,IntPtr l);
 [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr h,int n);
 [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h,IntPtr p);
 [DllImport("user32.dll")] public static extern bool GetGUIThreadInfo(uint id,ref GUI info);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] public static extern int GetClassName(IntPtr h,StringBuilder text,int size);
 [DllImport("user32.dll")] public static extern void keybd_event(byte key,byte scan,uint flags,UIntPtr extra);
 [StructLayout(LayoutKind.Sequential)] public struct RECT {public int l,t,r,b;}
 [StructLayout(LayoutKind.Sequential)] public struct GUI {public int size,flags;public IntPtr active,focus,capture,menu,movesize,caret;public RECT rect;}
 public static string FocusClass(IntPtr h) {var g=new GUI();g.size=Marshal.SizeOf(g);GetGUIThreadInfo(GetWindowThreadProcessId(h,IntPtr.Zero),ref g);var s=new StringBuilder(128);GetClassName(g.focus,s,128);return s.ToString();}
 public static void Key(byte key) {keybd_event(key,0,0,UIntPtr.Zero);System.Threading.Thread.Sleep(25);keybd_event(key,0,2,UIntPtr.Zero);}
}
'@
[void][QlTest]::SetThreadDpiAwarenessContext([IntPtr](-4))
function Focus-Explorer([IntPtr]$handle) {
 if ([QlTest]::GetForegroundWindow() -ne $handle) {
  [void][QlTest]::Focus($handle)
  if ([QlTest]::GetForegroundWindow() -ne $handle) {
   [QlTest]::keybd_event(18,0,0,[UIntPtr]::Zero);[QlTest]::keybd_event(18,0,2,[UIntPtr]::Zero)
   [void][QlTest]::Focus($handle)
  }
 }
 if ([QlTest]::GetForegroundWindow() -ne $handle) {throw 'Cannot obtain Explorer foreground'}
 # Close menus left by a foreground unlock; never send Alt when Explorer is already active.
 [QlTest]::Key(27)
}
$exe="$repo\target\x86_64-pc-windows-msvc\release\new-quicklook.exe"
if ([QlTest]::FindWindow('NewQuickLook.Native.Window','new-quicklook') -ne [IntPtr]::Zero) {throw 'An existing new-quicklook instance is open; leave it untouched and exit it before this test.'}
$shell=New-Object -ComObject Shell.Application
$before=@($shell.Windows() | ForEach-Object {$_.HWND})
$explorer=$null
$process=Start-Process $exe -ArgumentList (Join-ProcessArguments @('--trace',"$repo\artifacts\interaction-current.json")) -PassThru
$results=@()
try {
 Start-Process explorer.exe -ArgumentList ('"'+$repo+'\samples"')
 for ($i=0;$i -lt 40;$i++) {
  Start-Sleep -Milliseconds 150
  $explorer=@($shell.Windows() | Where-Object {$_.LocationURL -eq "$repoUri/samples"}) | Select-Object -First 1
  if ($null -ne $explorer) {break}
 }
 if ($null -eq $explorer) {throw 'Sample Explorer window not found'}
 for ($i=0;$i -lt 40;$i++) {
  $hwnd=[QlTest]::FindWindow('NewQuickLook.Native.Window','new-quicklook')
  if ($hwnd -ne [IntPtr]::Zero) {break}
  Start-Sleep -Milliseconds 150
 }
 if ($hwnd -eq [IntPtr]::Zero) {throw 'Resident window missing'}
 for ($round=0;$round -lt $Rounds;$round++) {
  foreach ($file in @('welcome.md','hello.py','hello.rs','gradient.png')) {
   $item=$explorer.Document.Folder.ParseName($file)
   Focus-Explorer ([IntPtr]$explorer.HWND)
   $explorer.Document.SelectItem($item,29)
   Start-Sleep -Milliseconds 300
   $focus=[QlTest]::FocusClass([IntPtr]$explorer.HWND)
   if ([QlTest]::GetForegroundWindow() -ne [IntPtr]$explorer.HWND) {throw "Cannot focus sample Explorer safely: wanted=$($explorer.HWND) actual=$([QlTest]::GetForegroundWindow()) focus=$focus"}
   if (Test-Path artifacts\interaction-current.json) {Remove-Item artifacts\interaction-current.json}
   [QlTest]::Key(32)
   Start-Sleep -Milliseconds 1000
   if (-not [QlTest]::IsWindowVisible($hwnd)) {
    Add-Type -AssemblyName UIAutomationClient
    $element=[System.Windows.Automation.AutomationElement]::FocusedElement
    for ($depth=0;$depth -lt 6 -and $null -ne $element;$depth++) {
     $element.Current | Select-Object ControlType,ClassName,AutomationId | ConvertTo-Json -Depth 3 | Write-Host
     $element=[System.Windows.Automation.TreeWalker]::ControlViewWalker.GetParent($element)
    }
    throw "Space did not open preview (focus: $focus)"
   }
   $metric=Get-Content artifacts\interaction-current.json -Raw | ConvertFrom-Json
   if ($metric.error -or $null -eq $metric.first_content_paint_ms) {throw "Selection/load failed: $file $($metric | ConvertTo-Json -Compress)"}
   if ($Features -and $round -eq 0) {
    if ($file -eq 'welcome.md') {
     if ($metric.mode -ne 'RENDERED' -or $metric.line_numbers) {throw 'Markdown default must render without line numbers'}
     [QlTest]::Key(77); Start-Sleep -Milliseconds 500
     $source=Get-Content artifacts\interaction-current.json -Raw | ConvertFrom-Json
     if ($source.mode -ne 'SOURCE' -or -not $source.line_numbers -or $source.error) {throw 'Markdown source mode failed'}
     [QlTest]::Key(77); Start-Sleep -Milliseconds 500
     $rendered=Get-Content artifacts\interaction-current.json -Raw | ConvertFrom-Json
     if ($rendered.mode -ne 'RENDERED' -or $rendered.line_numbers -or $rendered.error) {throw 'Markdown rendered mode failed'}
     # Exercise native hit testing and a partial drag, then read only our own copied data.
     $dpi=[QlTest]::GetDpiForWindow($hwnd);$x=[int](25*$dpi/96);$y=[int](108*$dpi/96)
     [QlTest]::MouseMessage($hwnd,513,$x,$y,1);Start-Sleep -Milliseconds 70
     [QlTest]::MouseMessage($hwnd,512,([int](270*$dpi/96)),$y,1);Start-Sleep -Milliseconds 70
     [QlTest]::MouseMessage($hwnd,514,([int](270*$dpi/96)),$y,0);Start-Sleep -Milliseconds 100
     [QlTest]::Ctrl(67);Start-Sleep -Milliseconds 150
     if ([QlTest]::GetClipboardOwner() -ne $hwnd) {throw 'Partial selection did not copy; refusing to read another clipboard owner'}
     Add-Type -AssemblyName System.Windows.Forms
     $selection=[System.Windows.Forms.Clipboard]::GetText()
     if ($selection.Length -eq 0 -or -not 'A quieter way to preview'.StartsWith($selection)) {& "$repo\scripts\capture-window.ps1" -Path "$repo\artifacts\selection-failure.png" -WindowHandle $hwnd.ToInt32() | Out-Null; throw "Partial rendered-text selection is incorrect: $($selection | ConvertTo-Json -Compress)"}
     & "$repo\scripts\capture-window.ps1" -Path "$repo\artifacts\selection.png" -WindowHandle $hwnd.ToInt32() | Out-Null
    }
    if ($file -ne 'gradient.png') {
     [QlTest]::Ctrl(65);[QlTest]::Ctrl(67);Start-Sleep -Milliseconds 150
     if ([QlTest]::GetClipboardOwner() -ne $hwnd) {throw 'Ctrl+C did not transfer clipboard ownership; refusing to read it'}
     Add-Type -AssemblyName System.Windows.Forms
     $copied=[System.Windows.Forms.Clipboard]::GetText()
     if ($file -eq 'welcome.md' -and -not $copied.StartsWith('A quieter way to preview')) {throw 'Rendered Markdown copy failed'}
     if ($file -eq 'hello.py' -and -not $copied.Contains('class Preview:')) {throw 'Python source copy failed'}
     if ($file -eq 'hello.rs' -and -not $copied.Contains('fn main()')) {throw 'Rust source copy failed'}
    } else {
     [void][QlTest]::SetWindowPos($hwnd,[IntPtr]::Zero,0,0,700,500,6)
     [void][QlTest]::PostMessage($hwnd,562,[IntPtr]::Zero,[IntPtr]::Zero)
     Start-Sleep -Milliseconds 500
     $resized=Get-Content artifacts\interaction-current.json -Raw | ConvertFrom-Json
     if ($resized.error -or $resized.image_width -gt 700 -or $resized.image_height -gt 500) {throw 'PNG resize did not rebuild a bounded canvas'}
     for($z=0;$z -lt 8;$z++){[void][QlTest]::PostMessage($hwnd,522,[IntPtr]7864320,[IntPtr]::Zero)}
     Start-Sleep -Milliseconds 150
     $zoom=Get-Content artifacts\interaction-current.json -Raw|ConvertFrom-Json
     if($zoom.zoom -le 1){throw 'Image wheel did not zoom'}
     [QlTest]::MouseMessage($hwnd,513,350,250,1)
     [QlTest]::MouseMessage($hwnd,512,300,220,1)
     [QlTest]::MouseMessage($hwnd,514,300,220,0)
     Start-Sleep -Milliseconds 150
     $pan=Get-Content artifacts\interaction-current.json -Raw|ConvertFrom-Json
     if($pan.pan_x -eq $zoom.pan_x -and $pan.pan_y -eq $zoom.pan_y){throw 'Image drag did not pan'}
     [QlTest]::MouseMessage($hwnd,515,350,250,1)
     Start-Sleep -Milliseconds 150
     $reset=Get-Content artifacts\interaction-current.json -Raw|ConvertFrom-Json
     if($reset.zoom -ne 1 -or $reset.pan_x -ne 0 -or $reset.pan_y -ne 0){throw 'Image double click did not reset'}
     [pscustomobject]@{zoom=$zoom;pan=$pan;reset=$reset}|ConvertTo-Json -Depth 5|Set-Content artifacts\canvas-results.json -Encoding UTF8

    }
   }
   if ($Navigation -and $round -eq 0 -and $file -eq 'hello.py') {
    $oldMode=$explorer.Document.CurrentViewMode
    try {
     $explorer.Document.CurrentViewMode=4
     Start-Sleep -Milliseconds 200
     foreach($step in @(@(40,'hello.rs'),@(38,'hello.py'),@(38,'gradient.png'),@(40,'hello.py'))) {
      [QlTest]::Key([byte]$step[0]);Start-Sleep -Milliseconds 350
      $selected=$explorer.Document.SelectedItems().Item(0).Name
      if($selected -ne $step[1]){throw "Navigation key $($step[0]): expected $($step[1]), got $selected"}
      $nmetric=Get-Content artifacts\interaction-current.json -Raw|ConvertFrom-Json
      if($nmetric.file_name -ne $step[1] -or $nmetric.error -or $null -eq $nmetric.first_content_paint_ms){throw 'Navigation preview failed'}
     }
    } finally {$explorer.Document.CurrentViewMode=$oldMode}
   }
   [QlTest]::Key(80)
   for($i=0;$i -lt 30 -and (([QlTest]::GetWindowLong($hwnd,-20) -band 8) -eq 0);$i++){Start-Sleep -Milliseconds 50}
   if (([QlTest]::GetWindowLong($hwnd,-20) -band 8) -eq 0) {throw "P did not enable topmost: preview=$hwnd foreground=$([QlTest]::GetForegroundWindow()) focus=$([QlTest]::FocusClass([QlTest]::GetForegroundWindow()))"}
   [QlTest]::Key(80)
   for($i=0;$i -lt 30 -and (([QlTest]::GetWindowLong($hwnd,-20) -band 8) -ne 0);$i++){Start-Sleep -Milliseconds 50}
   if (([QlTest]::GetWindowLong($hwnd,-20) -band 8) -ne 0) {throw 'P did not disable topmost'}
   [QlTest]::Key($(if ($round%2 -eq 0) {27}else{32}))
   Start-Sleep -Milliseconds 100
   if ([QlTest]::IsWindowVisible($hwnd)) {throw 'Esc/Space did not close preview'}
   $process.Refresh()
   $results += [pscustomobject]@{round=$round;file=$file;focus=$focus;first_content_paint_ms=$metric.first_content_paint_ms;closed_working_set=$process.WorkingSet64;closed_private_bytes=$process.PrivateMemorySize64}
  }
 }
 if ($Layout) {
  Focus-Explorer ([IntPtr]$explorer.HWND)
  $explorer.Document.SelectItem($explorer.Document.Folder.ParseName('large.py'),29)
  [QlTest]::Key(32); Start-Sleep -Milliseconds 800
  $initial=Get-Content artifacts\interaction-current.json -Raw | ConvertFrom-Json
  if ($initial.format -ne 'python' -or -not $initial.truncated -or $initial.max_scroll -le 0) {throw 'Large preview missing'}
  $paints=@()
  for($n=0;$n -lt 40;$n++) {
   [void][QlTest]::PostMessage($hwnd,522,[IntPtr](-7864320),[IntPtr]::Zero)
   Start-Sleep -Milliseconds 35
   $current=Get-Content artifacts\interaction-current.json -Raw | ConvertFrom-Json
   if ($current.layout_builds -ne $initial.layout_builds) {throw 'Wheel invalidated layout'}
   if ($current.visible_runs -gt 1000) {throw 'Offscreen content drawn'}
   $paints += $current.paint_ms
  }
  if ($current.scroll -le 0) {throw 'Wheel did not scroll'}
  $oldScroll=$current.scroll
  foreach($key in @(33,34,35,36)) {[void][QlTest]::PostMessage($hwnd,256,[IntPtr]$key,[IntPtr]::Zero)}
  Start-Sleep -Milliseconds 100
  $current=Get-Content artifacts\interaction-current.json -Raw | ConvertFrom-Json
  if ($current.scroll -ne $oldScroll) {throw 'Removed keyboard scroll still active'}
  $rect=New-Object QlTest+RECT
  [void][QlTest]::GetClientRect($hwnd,[ref]$rect)
  $dpi=[QlTest]::GetDpiForWindow($hwnd)/96.0
  $x=$rect.r-[int](13*$dpi);$top=[int](64*$dpi);$track=$rect.b-[int](100*$dpi)
  $thumb=[Math]::Max([int](20*$dpi),[int]($track*$track/($track+$current.max_scroll)))
  $y=$top+[int](($track-$thumb)*$current.scroll/$current.max_scroll)+[int]($thumb/2)
  [QlTest]::MouseMessage($hwnd,513,$x,$y,1)
  [QlTest]::MouseMessage($hwnd,512,$x,($top+$track-1),1)
  [QlTest]::MouseMessage($hwnd,514,$x,($top+$track-1),0)
  Start-Sleep -Milliseconds 150
  $drag=Get-Content artifacts\interaction-current.json -Raw | ConvertFrom-Json
  if ($drag.scroll -lt $drag.max_scroll*0.9 -or $drag.layout_builds -ne $initial.layout_builds) {throw 'Scrollbar drag/cache failed'}
  [QlTest]::MouseMessage($hwnd,513,$x,($top+2),1)
  [QlTest]::MouseMessage($hwnd,514,$x,($top+2),0)
  Start-Sleep -Milliseconds 100
  $page=Get-Content artifacts\interaction-current.json -Raw | ConvertFrom-Json
  if ($page.scroll -ge $drag.scroll) {throw 'Scrollbar track click failed'}
  [void][QlTest]::SetWindowPos($hwnd,[IntPtr]::Zero,0,0,900,700,6)
  Start-Sleep -Milliseconds 250
  $resize=Get-Content artifacts\interaction-current.json -Raw | ConvertFrom-Json
  if ($resize.layout_builds -le $initial.layout_builds) {throw 'Width change did not rebuild layout'}
  & "$repo\scripts\capture-window.ps1" -Path "$repo\artifacts\large-cached.png" -WindowHandle $hwnd.ToInt32() | Out-Null
  [pscustomobject]@{initial=$initial;wheel_paint_ms=$paints;after_drag=$drag;after_page=$page;after_resize=$resize;keyboard_scroll_removed=$true} | ConvertTo-Json -Depth 5 | Set-Content artifacts\layout-results.json -Encoding UTF8
  [QlTest]::Key(27)
 }
 # Address editing must retain Space. Escape returns to the file list without navigation.
 Focus-Explorer ([IntPtr]$explorer.HWND)
 Start-Sleep -Milliseconds 100
 [QlTest]::keybd_event(17,0,0,[UIntPtr]::Zero);[QlTest]::Key(76);[QlTest]::keybd_event(17,0,2,[UIntPtr]::Zero)
 Start-Sleep -Milliseconds 100
 $editFocus=[QlTest]::FocusClass([IntPtr]$explorer.HWND)
 [QlTest]::Key(32)
 Start-Sleep -Milliseconds 100
 if ([QlTest]::IsWindowVisible($hwnd)) {throw "Address editing opened preview (focus: $editFocus)"}
 [QlTest]::Key(27)
 # Rename only the project fixture; Escape cancels and restores its original name.
 $explorer.Document.SelectItem($explorer.Document.Folder.ParseName('hello.py'),29)
 [QlTest]::Key(113)
 Start-Sleep -Milliseconds 150
 $renameFocus=[QlTest]::FocusClass([IntPtr]$explorer.HWND)
 [QlTest]::Key(32)
 Start-Sleep -Milliseconds 100
 if ([QlTest]::IsWindowVisible($hwnd)) {throw "Rename editing opened preview (focus: $renameFocus)"}
 [QlTest]::Key(27)
 if (-not (Test-Path samples\hello.py)) {throw 'Fixture name changed unexpectedly'}
 $report=[pscustomobject]@{feature_checks=[bool]$Features;navigation_checks=[bool]$Navigation;samples=$results;address_focus=$editFocus;rename_focus=$renameFocus;address_space_pass_through=$true;rename_space_pass_through=$true}
 $report | ConvertTo-Json -Depth 5 | Set-Content artifacts\interaction-results.json -Encoding UTF8
 $report | ConvertTo-Json -Depth 5
} finally {
 $hwnd=[QlTest]::FindWindow('NewQuickLook.Native.Window','new-quicklook')
 if ($hwnd -ne [IntPtr]::Zero) {[void][QlTest]::PostMessage($hwnd,16,[IntPtr]::Zero,[IntPtr]::Zero)}
 if (-not $process.WaitForExit(5000)) {$process.Kill()}
 if ($null -ne $explorer -and $before -notcontains $explorer.HWND) { $testExplorerHwnd=[IntPtr]$explorer.HWND; try {$explorer.Quit()} finally {[void][QlTest]::PostMessage($testExplorerHwnd,16,[IntPtr]::Zero,[IntPtr]::Zero)} }
}
