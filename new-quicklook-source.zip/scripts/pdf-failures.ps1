﻿# Fault executables are test-only; production workers remain native Rust binaries.
$ErrorActionPreference='Stop'
$repo=Split-Path $PSScriptRoot -Parent
Set-Location $repo
$env:TEMP="$repo\.cache\tmp";$env:TMP=$env:TEMP
$results=@()
foreach($kind in @('missing','timeout','malformed','wrong-spec','invalid-image')) {
 $root="$repo\artifacts\pdf-fault-$kind";New-Item -ItemType Directory -Force "$root\worker" | Out-Null
 Copy-Item "$repo\new-quicklook.exe" "$root\new-quicklook.exe" -Force
 $helper="$root\worker\pdf-worker.exe";if(Test-Path $helper){Remove-Item $helper}
 if($kind -ne 'missing') {
  $mode=$kind
  $code=@'
using System;using System.IO;using System.Threading;
public static class PdfFault {
 static byte[] Read(Stream s,int n){var b=new byte[n];int at=0;while(at<n){int count=s.Read(b,at,n-at);if(count==0)throw new EndOfStreamException();at+=count;}return b;}
 static byte[] Header(ushort type,ulong id,ulong gen,uint len){var b=new byte[28];Array.Copy(new byte[]{78,81,87,49},b,4);Array.Copy(BitConverter.GetBytes((ushort)1),0,b,4,2);Array.Copy(BitConverter.GetBytes(type),0,b,6,2);Array.Copy(BitConverter.GetBytes(id),0,b,8,8);Array.Copy(BitConverter.GetBytes(gen),0,b,16,8);Array.Copy(BitConverter.GetBytes(len),0,b,24,4);return b;}
 public static void Main(){var input=Console.OpenStandardInput();var output=Console.OpenStandardOutput();string mode="MODE";
 if(mode=="timeout"){Thread.Sleep(60000);return;}
 if(mode=="malformed"){var h=Header(2,0,0,uint.MaxValue);output.Write(h,0,h.Length);output.Flush();Thread.Sleep(60000);return;}
 var hello=Read(input,28);Read(input,2);var welcome=Header(2,0,0,2);output.Write(welcome,0,28);output.Write(BitConverter.GetBytes((ushort)(mode=="wrong-spec"?42:2)),0,2);output.Flush();
 if(mode=="wrong-spec"){Thread.Sleep(60000);return;}
 var request=Read(input,28);Read(input,(int)BitConverter.ToUInt32(request,24));
 var payload=new byte[32];Array.Copy(BitConverter.GetBytes((uint)1),0,payload,8,4);Array.Copy(BitConverter.GetBytes((uint)20),0,payload,12,4);Array.Copy(BitConverter.GetBytes((uint)20),0,payload,16,4);Array.Copy(BitConverter.GetBytes((uint)8),0,payload,20,4);Array.Copy(new byte[]{137,80,78,71,13,10,26,10},0,payload,24,8);
 var reply=Header(4,BitConverter.ToUInt64(request,8),BitConverter.ToUInt64(request,16),32);output.Write(reply,0,28);output.Write(payload,0,payload.Length);output.Flush();Thread.Sleep(60000);
 }
}
'@
  Add-Type -TypeDefinition $code.Replace('MODE',$mode) -OutputAssembly $helper -OutputType ConsoleApplication
 }
 $report="$root\result.json";Remove-Item $report -ErrorAction SilentlyContinue
 $watch=[Diagnostics.Stopwatch]::StartNew()
 $p=Start-Process "$root\new-quicklook.exe" -ArgumentList @('--smoke',('"'+$repo+'\samples\pdf\01-pages.pdf"'),('"'+$report+'"')) -PassThru
 try {
  if(-not $p.WaitForExit(15000)){throw "PDF fault hung: $kind"}
  if($p.ExitCode -ne 0){throw "PDF fault crashed parent: $kind"}
  $m=Get-Content $report -Raw|ConvertFrom-Json
  if(-not $m.error -or [string]::IsNullOrWhiteSpace($m.message) -or $null -eq $m.first_content_paint_ms){throw "PDF fault had no painted readable error: $kind"}
  if(@(Get-CimInstance Win32_Process -Filter "Name='pdf-worker.exe'"|Where-Object ExecutablePath -eq $helper).Count){throw "Fault worker survived: $kind"}
  $results+=[pscustomobject]@{kind=$kind;wall_ms=$watch.ElapsedMilliseconds;worker_cleaned=$true;metrics=$m}
  Write-Output "Passed PDF $kind with readable error and child cleanup"
 }finally{if(-not $p.HasExited){$p.Kill();$p.WaitForExit()}}
}
$results|ConvertTo-Json -Depth 7|Set-Content artifacts\pdf-failure-results.json -Encoding UTF8
