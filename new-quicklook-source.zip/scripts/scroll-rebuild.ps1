﻿param([switch]$Baseline,[string]$Label='scroll-after',[string]$Exe='')
$repo = Split-Path $PSScriptRoot -Parent
. "$PSScriptRoot\process-args.ps1"
if(-not $Exe){$Exe="$repo\new-quicklook.exe"}

$ErrorActionPreference='Stop'
Set-Location $repo
. "$PSScriptRoot\gui-test.ps1"
if((Get-PreviewHandle) -ne [IntPtr]::Zero){throw 'Exit resident before scroll verification'}
$report="$repo\artifacts\$Label-current.json";$fixture="$repo\artifacts\scroll-fixtures"
New-Item $fixture -ItemType Directory -Force | Out-Null
Set-Content "$fixture\scroll-intent.py" (@('value = call(Type.CONST, key=True) # note') * 6000) -Encoding UTF8
if((Get-Item "$fixture\scroll-intent.py").Length -gt 262144){throw 'Fixture exceeds input bound'}
$shell=New-Object -ComObject Shell.Application;$before=@($shell.Windows()|ForEach-Object {$_.HWND})
$explorer=$null;$process=$null;$success=$false;$failure=$null;$full=$env:QUICKLOOK_FULL_LAYOUT
function Drag-Mouse([int]$X,[int]$Y,[int]$EndX,[int]$EndY) {
 [void][PreviewGui]::SetCursorPos($X,$Y);Start-Sleep -Milliseconds 70
 [PreviewGui]::mouse_event(2,0,0,0,[UIntPtr]::Zero);Start-Sleep -Milliseconds 70
 [void][PreviewGui]::SetCursorPos($EndX,$EndY);Start-Sleep -Milliseconds 120
 [PreviewGui]::mouse_event(4,0,0,0,[UIntPtr]::Zero)
}
try {
 Remove-Item Env:\QUICKLOOK_FULL_LAYOUT -ErrorAction SilentlyContinue
 Remove-Item $report -ErrorAction SilentlyContinue
 $process=Start-Process $Exe -ArgumentList (Join-ProcessArguments @('--trace',$report)) -PassThru
 Start-Process explorer.exe -ArgumentList ('/n,"'+$fixture+'"') | Out-Null
 for($j=0;$j -lt 60;$j++){Start-Sleep -Milliseconds 100;$explorer=@($shell.Windows()|Where-Object {$before -notcontains $_.HWND -and $_.Document.Folder.Self.Path -eq $fixture})|Select-Object -First 1;$hwnd=Get-PreviewHandle;if($explorer -and $hwnd -ne [IntPtr]::Zero){break}}
 if(-not $explorer){throw 'Owned Explorer missing'};$eh=[IntPtr]$explorer.HWND
 [void][PreviewGui]::ShowWindow($eh,9);[void][PreviewGui]::SetWindowPos($eh,[IntPtr]::Zero,0,30,2100,1640,0x14)
 $explorer.Document.CurrentViewMode=4;Start-Sleep -Milliseconds 400
 Click-ExplorerFile $explorer 'scroll-intent.py';[PreviewGui]::Key(32)
 $opened=Read-PreviewReport $report {param($m) $m.file_name -eq 'scroll-intent.py' -and $m.layout_complete -and -not $m.error} 10000
 if($opened.truncated){throw 'Fixture unexpectedly truncated'}
 [void][PreviewGui]::SetWindowPos($hwnd,[IntPtr]::Zero,800,172,640,1360,0x14)
 $narrow=Read-PreviewReport $report {param($m) $m.layout_builds -gt $opened.layout_builds -and $m.layout_complete -and $m.scroll_frames[-1].width -eq 640} 10000
 $rect=Get-TestRect $hwnd;$bar=$narrow.scrollbar
 if(-not $bar){throw 'No scrollbar'}
 $x=$rect.x+$bar.left+[int]($bar.width/2);$y=$rect.y+$bar.top+$bar.thumb_pos+[int]($bar.thumb_len/2)
 $end=$y+[int](($bar.track_len-$bar.thumb_len)/2)
 Drag-Mouse $x $y $x $end
 $mid=Read-PreviewReport $report {param($m) $m.scroll -gt $narrow.max_scroll*0.4 -and $m.scroll -lt $narrow.max_scroll*0.6 -and $m.layout_complete} 10000
 & "$PSScriptRoot\capture-window.ps1" -WindowHandle $hwnd.ToInt32() -Path "artifacts\$Label-before-resize.png" | Out-Null
 $rect=Get-TestRect $hwnd;$edge=$rect.x+$rect.width-2;$cy=$rect.y+[int]($rect.height/2)
 Drag-Mouse $edge $cy ($edge+600) $cy
 $final=Read-PreviewReport $report {param($m) $m.layout_builds -gt $mid.layout_builds -and $m.layout_complete -and $m.scroll_frames[-1].width -ge 1200} 10000
 $after=Get-TestRect $hwnd
 if([Math]::Abs($after.width-($rect.width+600)) -gt 4){throw 'Real resize did not change width as expected'}
 $partial=@($final.scroll_frames|Where-Object {-not $_.complete})
 if($partial.Count -eq 0){throw 'No actual incomplete paint captured; fixture did not exercise rebuilding'}
 if(@($partial|Where-Object {$_.max_scroll -lt $mid.scroll}).Count -eq 0){throw 'Partial height never threatened the stored intent; insufficient regression fixture'}
 $expected=[Math]::Min($mid.scroll,$final.max_scroll)
 if($Baseline){
  if(@($partial|Where-Object {$_.scroll -ne $mid.scroll}).Count -eq 0 -or $final.scroll -eq $expected){throw 'Baseline did not reproduce the lost scroll intention'}
 } else {
  if(@($partial|Where-Object {$_.scroll -ne $mid.scroll -or $_.scroll -le 0}).Count -ne 0){throw 'Partial layout changed stored scroll intent'}
  if($final.scroll -ne $expected -or $final.scroll -le 0){throw 'Completed layout did not retain/clamp the user intent'}
  $bar=$final.scrollbar;$position=[int][Math]::Floor(($bar.track_len-$bar.thumb_len)*[double]$final.scroll/$final.max_scroll)
  if($bar.thumb_pos -ne $position){throw 'Scrollbar thumb does not match final scroll'}
 }
 & "$PSScriptRoot\capture-window.ps1" -WindowHandle $hwnd.ToInt32() -Path "artifacts\$Label-after-resize.png" | Out-Null
 Write-Output "baseline=$Baseline partial_frames=$($partial.Count) intent=$($mid.scroll) final=$($final.scroll) expected=$expected"
 $success=$true
} catch {$failure=$_.Exception.Message;throw} finally {
 if($process -and -not $process.HasExited){& $Exe --quit;if(-not $process.WaitForExit(3000)){$process.Kill()}}
 if($null -eq $full){Remove-Item Env:\QUICKLOOK_FULL_LAYOUT -ErrorAction SilentlyContinue}else{$env:QUICKLOOK_FULL_LAYOUT=$full}
 Close-TestExplorer $explorer $before
 [pscustomobject]@{success=$success;failure=$failure;baseline=[bool]$Baseline;exe=$Exe;exe_sha256=(Get-FileHash $Exe).Hash;shell_before=$before;shell_after=@($shell.Windows()|ForEach-Object {$_.HWND});fixture_bytes=(Get-Item "$fixture\scroll-intent.py").Length;before=$mid;before_geometry=$rect;after=$final;after_geometry=$after;expected_final_scroll=$expected;partial_frames=$partial}|ConvertTo-Json -Depth 12|Set-Content "artifacts\$Label-results.json" -Encoding UTF8
}
