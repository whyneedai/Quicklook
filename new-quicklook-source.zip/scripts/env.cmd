@echo off
rem Machine-independent build environment for this repository.
rem Cargo home, temp and target all stay inside the checkout; the MSVC environment
rem is discovered with vswhere instead of a hard-coded install path.
rem Override the compiler location with:  set QL_VCVARS=<full path to vcvars64.bat>

for %%I in ("%~dp0..") do set "QL_ROOT=%%~fI"
cd /d "%QL_ROOT%" || exit /b 1

rem Rust toolchain: per-user install first, then whatever is already on PATH.
if exist "%USERPROFILE%\.cargo\bin" set "PATH=%USERPROFILE%\.cargo\bin;%PATH%"

set "CARGO_HOME=%QL_ROOT%\.cache\cargo"
set "TEMP=%QL_ROOT%\.cache\tmp"
set "TMP=%TEMP%"
if not exist "%TEMP%" mkdir "%TEMP%" >nul 2>&1
if not exist "%CARGO_HOME%" mkdir "%CARGO_HOME%" >nul 2>&1

if not exist "%QL_ROOT%\artifacts" mkdir "%QL_ROOT%\artifacts" >nul 2>&1
if not exist "%QL_ROOT%\artifacts" exit /b 1

rem MSVC x64 environment (crates/app/build.rs invokes rc.exe).
if defined QL_VCVARS (
    if not exist "%QL_VCVARS%" (
        echo [env] QL_VCVARS is set but missing: %QL_VCVARS% 1>&2
        exit /b 1
    )
    call "%QL_VCVARS%" >nul
    if errorlevel 1 exit /b 1
    exit /b 0
)

set "PF86=%ProgramFiles(x86)%"
set "PF=%ProgramFiles%"
set "VSWHERE=%PF86%\Microsoft Visual Studio\Installer\vswhere.exe"
set "VS_PATH="
if exist "%VSWHERE%" (
    for /f "usebackq tokens=*" %%P in (`"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "VS_PATH=%%P"
)
if defined VS_PATH if exist "%VS_PATH%\VC\Auxiliary\Build\vcvars64.bat" (
    call "%VS_PATH%\VC\Auxiliary\Build\vcvars64.bat" >nul
    if errorlevel 1 exit /b 1
    exit /b 0
)

for %%E in (BuildTools Community Professional Enterprise) do (
    for %%Y in (2022 2019) do (
        if exist "%PF%\Microsoft Visual Studio\%%Y\%%E\VC\Auxiliary\Build\vcvars64.bat" (
            call "%PF%\Microsoft Visual Studio\%%Y\%%E\VC\Auxiliary\Build\vcvars64.bat" >nul
            if errorlevel 1 exit /b 1
            exit /b 0
        )
        if exist "%PF86%\Microsoft Visual Studio\%%Y\%%E\VC\Auxiliary\Build\vcvars64.bat" (
            call "%PF86%\Microsoft Visual Studio\%%Y\%%E\VC\Auxiliary\Build\vcvars64.bat" >nul
            if errorlevel 1 exit /b 1
            exit /b 0
        )
    )
)

echo [env] Visual Studio C++ build tools (x64) not found. 1>&2
echo [env] Install the "Desktop development with C++" workload, or set QL_VCVARS. 1>&2
exit /b 1
