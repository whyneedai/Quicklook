@echo off
chcp 65001 >nul
call "%~dp0env.cmd"
if errorlevel 1 exit /b 1
call cargo %*
exit /b %errorlevel%
