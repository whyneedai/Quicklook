﻿param([int]$Rounds=4,[string]$Label='before',[switch]$Plain,[switch]$IssueImages,[switch]$Mouse)
$repo = Split-Path $PSScriptRoot -Parent
. "$PSScriptRoot\process-args.ps1"
$repoUri = ([Uri]($repo+'\')).AbsoluteUri.TrimEnd('/')

$ErrorActionPreference='Stop'
Set-Location $repo
. "$PSScriptRoot\gui-test.ps1"
$env:TEMP="$repo\.cache\tmp"; $env:TMP=$env:TEMP
New-Item -ItemType Directory -Force $env:TEMP | Out-Null
Add-Type @'
using System;
using System.Runtime.InteropServices;
using System.Text;
public static class QlTest {
 [DllImport("user32.dll")] public static extern bool SetCursorPos(int x,int y);
 [DllImport("user32.dll")] public static extern void mouse_event(uint flags,uint dx,uint dy,uint data,UIntPtr extra);
 public static void Click(int x,int y) {SetCursorPos(x,y);mouse_event(2,0,0,0,UIntPtr.Zero);System.Threading.Thread.Sleep(30);mouse_event(4,0,0,0,UIntPtr.Zero);}

 [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
 [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint a,uint b,bool attach);
 [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
 [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h,int mode);
 public static bool Focus(IntPtr h) {
   uint current=GetCurrentThreadId(), foreground=GetWindowThreadProcessId(GetForegroundWindow(),IntPtr.Zero);
   bool attached=current!=foreground && AttachThreadInput(current,foreground,true);
   try {ShowWindow(h,9);return SetForegroundWindow(h);} finally {if(attached)AttachThreadInput(current,foreground,false);}
 }

 [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
 [DllImport("user32.dll")] public static extern IntPtr GetClipboardOwner();
 [DllImport("user32.dll")] public static extern uint GetDpiForWindow(IntPtr h);
 [DllImport("user32.dll")] public static extern IntPtr SetThreadDpiAwarenessContext(IntPtr context);
 [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h,IntPtr after,int x,int y,int w,int height,uint flags);
 public static void Ctrl(byte key){keybd_event(17,0,0,UIntPtr.Zero);Key(key);keybd_event(17,0,2,UIntPtr.Zero);}
 public static void MouseMessage(IntPtr h,uint message,int x,int y,int buttons){PostMessage(h,message,(IntPtr)buttons,(IntPtr)((y<<16)|(x&65535)));}

 [DllImport("user32.dll")] public static extern IntPtr FindWindow(string c,string n);
 [DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr h,out RECT r);
 [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
 [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr h,uint m,IntPtr w,IntPtr l);
 [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr h,int n);
 [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h,IntPtr p);
 [DllImport("user32.dll")] public static extern bool GetGUIThreadInfo(uint id,ref GUI info);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] public static extern int GetClassName(IntPtr h,StringBuilder text,int size);
 [DllImport("user32.dll")] public static extern void keybd_event(byte key,byte scan,uint flags,UIntPtr extra);
 [StructLayout(LayoutKind.Sequential)] public struct RECT {public int l,t,r,b;}
 [StructLayout(LayoutKind.Sequential)] public struct GUI {public int size,flags;public IntPtr active,focus,capture,menu,movesize,caret;public RECT rect;}
 public static string FocusClass(IntPtr h) {var g=new GUI();g.size=Marshal.SizeOf(g);GetGUIThreadInfo(GetWindowThreadProcessId(h,IntPtr.Zero),ref g);var s=new StringBuilder(128);GetClassName(g.focus,s,128);return s.ToString();}
 public static void Key(byte key) {keybd_event(key,0,0,UIntPtr.Zero);System.Threading.Thread.Sleep(25);keybd_event(key,0,2,UIntPtr.Zero);}
}
'@
[void][QlTest]::SetThreadDpiAwarenessContext([IntPtr](-4))
function Focus-Explorer([IntPtr]$handle) {
 if ([QlTest]::GetForegroundWindow() -ne $handle) {
  [void][QlTest]::Focus($handle)
  if ([QlTest]::GetForegroundWindow() -ne $handle) {
   [QlTest]::keybd_event(18,0,0,[UIntPtr]::Zero);[QlTest]::keybd_event(18,0,2,[UIntPtr]::Zero)
   [void][QlTest]::Focus($handle)
  }
 }
 for($focusRetry=0;$focusRetry -lt 20 -and [QlTest]::GetForegroundWindow() -ne $handle;$focusRetry++) {
  Start-Sleep -Milliseconds 50
  [QlTest]::keybd_event(18,0,0,[UIntPtr]::Zero);[QlTest]::keybd_event(18,0,2,[UIntPtr]::Zero)
  [void][QlTest]::Focus($handle)
 }
 if ([QlTest]::GetForegroundWindow() -ne $handle) {throw "Cannot obtain Explorer foreground wanted=$handle actual=$([QlTest]::GetForegroundWindow())"}
 # Close menus left by a foreground unlock; never send Alt when Explorer is already active.
 [QlTest]::Key(27)
}

if($Mouse){Add-Type -AssemblyName UIAutomationClient;Add-Type -AssemblyName UIAutomationTypes}
$shell=New-Object -ComObject Shell.Application
$before=@($shell.Windows()|ForEach-Object {$_.HWND})
$explorer=$null;$process=$null;$results=@()
try {
 . "$PSScriptRoot\image-fixtures.ps1"
 $folderPath=if($IssueImages){New-TestImageFixtures}else{Join-Path $repo 'samples'}
 Start-Process explorer.exe -ArgumentList ('/n,"'+$folderPath+'"')
 for($i=0;$i -lt 50;$i++) {
  Start-Sleep -Milliseconds 100
  $explorer=@($shell.Windows()|Where-Object {$before -notcontains $_.HWND})|Select-Object -First 1
  if($explorer -and $explorer.Document.Folder.Self.Path -eq $folderPath){break}
 }
 if(-not $explorer -or $explorer.Document.Folder.Self.Path -ne $folderPath){throw 'Explorer unavailable'}
 for($round=0;$round -lt $Rounds;$round++) {
  $report="$repo\artifacts\restart-$Label-current.json"
  if(Test-Path $report){Remove-Item $report}
  if($Plain){$process=Start-Process "$repo\new-quicklook.exe" -PassThru}else{$process=Start-Process "$repo\new-quicklook.exe" -ArgumentList (Join-ProcessArguments @('--trace',$report)) -PassThru}
  for($i=0;$i -lt 100;$i++) {
   $hwnd=[QlTest]::FindWindow('NewQuickLook.Native.Window','new-quicklook')
   if($hwnd -ne [IntPtr]::Zero){break};Start-Sleep -Milliseconds 20
  }
  Start-Sleep -Milliseconds 100
  $cases=if($IssueImages){@('1.png','2.png','3.png')}else{@('hello.py','gradient.png','welcome.md','NONE','MULTI','hello.rs')}
  foreach($name in $cases) {
   if([QlTest]::IsWindowVisible($hwnd)){[void][QlTest]::PostMessage($hwnd,256,[IntPtr]27,[IntPtr]0);Start-Sleep -Milliseconds 70}
   Focus-Explorer ([IntPtr]$explorer.HWND)
   $item=$explorer.Document.Folder.ParseName($(if($name -in @('NONE','MULTI')){'welcome.md'}else{$name}))
   $explorer.Document.SelectItem($item,29)
   if($name -eq 'NONE'){$explorer.Document.SelectItem($item,0)}
   if($name -eq 'MULTI'){$explorer.Document.SelectItem($explorer.Document.Folder.ParseName('hello.py'),1)}
   $expected=$explorer.Document.SelectedItems().Count
   Start-Sleep -Milliseconds 150
   Focus-Explorer ([IntPtr]$explorer.HWND)
   if($Mouse -and $name -notin @('NONE','MULTI')) {
    $root=[System.Windows.Automation.AutomationElement]::FromHandle([IntPtr]$explorer.HWND)
    $condition=[System.Windows.Automation.PropertyCondition]::new([System.Windows.Automation.AutomationElement]::NameProperty,$name)
    $element=$root.FindFirst([System.Windows.Automation.TreeScope]::Descendants,$condition)
    if(-not $element){throw "UIA file row missing: $name"}
    $r=$element.Current.BoundingRectangle
    if($r.IsEmpty -or $r.Width -le 0){throw "UIA file row offscreen: $name"}
    & "$repo\scripts\capture-window.ps1" -WindowHandle ([int]$explorer.HWND) -Path "$repo\artifacts\mouse-explorer.png"|Out-Null
    [void][QlTest]::SetThreadDpiAwarenessContext([IntPtr](-4))
    # Deselect via COM first: the real click must establish the selection anew.
    $explorer.Document.SelectItem($item,0)
    [QlTest]::Click([int]($r.Left+$r.Width/2),[int]($r.Top+$r.Height/2))
    Start-Sleep -Milliseconds 60
    if($explorer.Document.SelectedItems().Count -ne 1 -or $explorer.Document.SelectedItems().Item(0).Name -ne $name){throw "Real mouse selection mismatch expected=$name selected=$(@($explorer.Document.SelectedItems()|ForEach-Object {$_.Name}) -join ',') rect=$r foreground=$([QlTest]::GetForegroundWindow()) owner=$($explorer.HWND)"}
   }
   if(Test-Path $report){Remove-Item $report}
   [QlTest]::Key(32)
   # Poll for the trace report instead of a fixed 350ms: cold Shell scans can
   # legitimately exceed that on a busy desktop without being a product defect.
   $m=$null
   for($pw=0;$pw -lt 50 -and $null -eq $m;$pw++) {
    Start-Sleep -Milliseconds 50
    if(Test-Path $report){try{$m=Get-Content $report -Raw|ConvertFrom-Json}catch{continue}}
   }
   $visible=[QlTest]::IsWindowVisible($hwnd)
   if($visible -and ($Label -ne 'before' -or $round -eq 0 -or $m.error)) {
    & "$repo\scripts\capture-window.ps1" -WindowHandle $hwnd.ToInt32() -Path "$repo\artifacts\restart-$Label-$round-$name.png"|Out-Null
   }
   $results += [pscustomobject]@{round=$round;pid=$process.Id;file=$name;selected_count=$expected;focus=[QlTest]::FocusClass([IntPtr]$explorer.HWND);visible=$visible;metrics=$m}
   if($name -notin @('NONE','MULTI') -and (-not $visible -or (-not $Plain -and (-not $m -or $m.error -or $m.file_name -ne $name)))){throw "Wrong preview after restart round=$round file=$name"}
   if($Label -ne 'before' -and $name -in @('NONE','MULTI') -and $visible){throw 'Empty selection opened a bogus preview'}
  }
  [void][QlTest]::PostMessage($hwnd,16,[IntPtr]0,[IntPtr]0)
  if(-not $process.WaitForExit(5000)){throw 'Application did not exit'}
  if([QlTest]::FindWindow('NewQuickLook.Native.Window','new-quicklook') -ne [IntPtr]::Zero){throw 'Window survived process exit'}
  $process=$null
 }
 Write-Output "Passed $Rounds complete process restarts"
} finally {
 $results|ConvertTo-Json -Depth 7|Set-Content "artifacts\restart-$Label-results.json" -Encoding UTF8
 if($process -and -not $process.HasExited){$process.Kill();$process.WaitForExit()}
 Close-TestExplorer $explorer $before
}
