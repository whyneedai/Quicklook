﻿# Start-Process joins ArgumentList with spaces; quote Windows argv explicitly.
function Join-ProcessArguments {
 param([string[]]$Arguments)
 ($Arguments | ForEach-Object {
  '"' + (($_ -replace '(\\*)"', '$1$1\"') -replace '(\\+)$', '$1$1') + '"'
 }) -join ' '
}
