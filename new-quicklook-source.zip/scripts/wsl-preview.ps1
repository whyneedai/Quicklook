﻿param([string]$Distribution='',[switch]$SkipExplorer)
$repo = Split-Path $PSScriptRoot -Parent
. "$PSScriptRoot\process-args.ps1"

$ErrorActionPreference='Stop'
Set-Location $repo
. "$PSScriptRoot\gui-test.ps1"
. "$PSScriptRoot\explorer-navigation.ps1"
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$OutputEncoding=[Console]::OutputEncoding
if((Get-PreviewHandle) -ne [IntPtr]::Zero){throw 'Exit project resident before WSL validation'}
$encoded=[Convert]::ToBase64String([IO.File]::ReadAllBytes("$PSScriptRoot\wsl-fixtures.py"))
$program="import base64;exec(base64.b64decode('$encoded'))"
$wslArgs=@();if($Distribution){$wslArgs+=@('-d',$Distribution)}
$wslArgs+=@('--exec','python3','-c',$program)
$manifestText=& wsl.exe @wslArgs
if($LASTEXITCODE -ne 0){throw 'Linux fixture generation failed'}
# wsl.exe emits UTF-8 fixture names; run under a UTF-8 PowerShell console as below.
$manifest=$manifestText | ConvertFrom-Json
$Distribution=$manifest.distribution
$manifest | ConvertTo-Json -Depth 5 | Set-Content artifacts\wsl-fixtures.json -Encoding UTF8
$relative=$manifest.linux_root.Replace('/','\')
$results=[Collections.Generic.List[object]]::new();$success=$false;$failure=$null
$shell=New-Object -ComObject Shell.Application
$baseline=@($shell.Windows()|ForEach-Object {$_.HWND})
$explorer=$null;$process=$null;$gui=$null
function Smoke-Wsl([string]$Path,[string]$Label) {
 $report="$repo\artifacts\wsl-$Label.json"
 Remove-Item $report -ErrorAction SilentlyContinue
 $p=Start-Process "$repo\new-quicklook.exe" -ArgumentList @('--smoke',('"'+$Path+'"'),('"'+$report+'"')) -PassThru
 if(-not $p.WaitForExit(15000)){$p.Kill();throw "WSL preview timed out: $Path"}
 if($p.ExitCode -ne 0){throw "WSL preview crashed: $Path ($($p.ExitCode))"}
 Read-PreviewReport $report
}
try {
 foreach($hostName in @('wsl.localhost','wsl$')) {
  $hostLabel=$(if($hostName -eq 'wsl.localhost'){'localhost'}else{'legacy'})
  foreach($fixture in $manifest.files) {
   $unc='\\'+$hostName+'\'+$Distribution+$relative+'\'+$fixture.name
   $m=Smoke-Wsl $unc ($hostLabel+'-'+$fixture.name)
   $expectedHash=$(if($fixture.bytes -gt $manifest.text_limit -and $fixture.name -eq 'large.py'){$fixture.bounded_sha256sum}else{$fixture.sha256sum})
   if($m.error -or $m.file_name -cne $fixture.name -or $m.content_hash -ne $expectedHash -or $m.content_hash_algorithm -ne 'sha256'){throw "WSL name/hash/content mismatch: $unc"}
   if($fixture.name -eq '公式.md' -and ($m.math_ready -le 0 -or $m.math_pending -ne 0)){throw 'WSL Markdown formulas not ready'}
   if($fixture.name -eq 'image.png' -and ($m.image_width -ne 73 -or $m.image_height -ne 41)){throw 'WSL PNG size mismatch'}
   if($fixture.name -eq 'hello.py' -and ($m.format -ne 'python' -or -not $m.line_numbers)){throw 'WSL code source/highlighting missing'}
   if($fixture.name -eq 'large.py' -and (-not $m.truncated -or $m.content_hash_scope -ne 'bounded_input' -or $m.content_hash_bytes -ne 262144)){throw 'WSL large text bound/truncation incorrect'}
   if($fixture.name -ne 'large.py' -and $m.content_hash_scope -ne 'full_input'){throw 'Wrong full input hash scope'}
   $results.Add([pscustomobject]@{path=$unc;linux_sha256sum=$fixture.sha256sum;expected_input_sha256sum=$expectedHash;metrics=$m})
   Write-Output "Passed $hostLabel $($fixture.name) SHA-256/name/content"
  }
 }
 $extended='\\?\UNC\wsl.localhost\'+$Distribution+$relative+'\文本.txt'
 $m=Smoke-Wsl $extended 'extended-unc'
 $expected=@($manifest.files | Where-Object {$_.name -ceq '文本.txt'})[0].sha256sum
 if($m.error -or $m.file_name -cne '文本.txt' -or $m.content_hash -ne $expected){throw 'Extended WSL UNC preview mismatch'}
 $results.Add([pscustomobject]@{case='extended-unc';path=$extended;linux_sha256sum=$expected;metrics=$m})
 Write-Output 'Passed extended WSL UNC SHA-256/name/content'
 $base='\\wsl.localhost\'+$Distribution+$relative
 $errors=@(
  @{label='missing-file';path=($base+'\missing.txt');match='WSL file unavailable'},
  @{label='unavailable-distro';path='\\wsl.localhost\No-Quicklook-Test-Distribution\missing.txt';match='WSL file unavailable'},
  @{label='permission';path=($base+'\denied.txt');match='WSL permission denied'},
  @{label='ordinary-network-rejected';path='\\No-Quicklook-Test-Server\share\a.txt';match='network, device'},
  @{label='ads-rejected';path=($base+'\文本.txt:stream');match='alternate-stream'}
 )
 foreach($case in $errors) {
  $m=Smoke-Wsl $case.path $case.label
  if(-not $m.error -or [string]::IsNullOrWhiteSpace($m.message) -or $m.message -notmatch $case.match){throw "Unreadable/wrong error: $($case.label): $($m.message)"}
  $results.Add([pscustomobject]@{case=$case.label;path=$case.path;metrics=$m})
  Write-Output "Passed readable error $($case.label)"
 }
 if(-not $SkipExplorer) {
  Start-Process explorer.exe -ArgumentList '/n,\\wsl.localhost' | Out-Null
  for($i=0;$i -lt 60;$i++) {
   Start-Sleep -Milliseconds 100
   $explorer=@($shell.Windows()|Where-Object {$baseline -notcontains $_.HWND})|Select-Object -First 1
   if($explorer){break}
  }
  if(-not $explorer){throw 'WSL Explorer window missing'}
  [void][PreviewGui]::SetWindowPos([IntPtr]$explorer.HWND,[IntPtr]::Zero,80,50,2100,1450,0x14)
  Focus-TestWindow ([IntPtr]$explorer.HWND)
  Start-Sleep -Milliseconds 600
  $windowRect=Get-TestRect ([IntPtr]$explorer.HWND)
  $node=$null
  for($i=0;$i -lt 8;$i++) {
   $node=Get-ExplorerNavigationNode ([IntPtr]$explorer.HWND) 'Linux'
   if($node -and $node.y -ge $windowRect.y+300 -and $node.y+$node.height -lt $windowRect.y+$windowRect.height-50){break}
   [void][PreviewGui]::SetCursorPos(($windowRect.x+150),($windowRect.y+650))
   [PreviewGui]::mouse_event(0x800,0,0,4294966336,[UIntPtr]::Zero)
   Start-Sleep -Milliseconds 150
  }
  if(-not $node -or $node.y+$node.height -ge $windowRect.y+$windowRect.height-50){throw 'Explorer Linux navigation node is not visible'}
  [PreviewGui]::Click([int]($node.x+$node.width/2),[int]($node.y+$node.height/2))
  Start-Sleep -Milliseconds 500
  $linuxNodePath=$explorer.Document.Folder.Self.Path
  if($explorer.Document.Folder.Self.Name -ne 'Linux'){throw 'Real mouse click did not reach the Linux node'}
  & "$PSScriptRoot\capture-window.ps1" -WindowHandle ([int]$explorer.HWND) -Path artifacts\wsl-linux-node.png | Out-Null
  Click-ExplorerFile $explorer $Distribution
  [PreviewGui]::Key(13)
  Start-Sleep -Milliseconds 500
  $distroPath=$explorer.Document.Folder.Self.Path.TrimEnd([char]92)
  if($distroPath -notlike ('\\wsl*\'+$Distribution)){throw "Linux node did not open the distribution: $distroPath"}
  $explorer.Navigate2($base)
  for($i=0;$i -lt 50 -and $explorer.Document.Folder.Self.Path -ne $base;$i++){Start-Sleep -Milliseconds 100}
  if($explorer.Document.Folder.Self.Path -ne $base){throw 'WSL fixture folder did not load'}
  $trace="$repo\artifacts\wsl-explorer-current.json"
  Remove-Item $trace -ErrorAction SilentlyContinue
  $process=Start-Process "$repo\new-quicklook.exe" -ArgumentList (Join-ProcessArguments @('--trace',$trace)) -PassThru
  for($i=0;$i -lt 60 -and (Get-PreviewHandle) -eq [IntPtr]::Zero;$i++){Start-Sleep -Milliseconds 50}
  Click-ExplorerFile $explorer '公式.md'
  & "$PSScriptRoot\capture-window.ps1" -WindowHandle ([int]$explorer.HWND) -Path artifacts\wsl-explorer-selection.png | Out-Null
  [PreviewGui]::Key(32)
  $m=Read-PreviewReport $trace {param($m) $m.file_name -ceq '公式.md' -and -not $m.error -and $m.math_ready -gt 0 -and $null -ne $m.first_content_paint_ms}
  $expected=@($manifest.files | Where-Object {$_.name -ceq '公式.md'})[0].sha256sum
  if($m.content_hash -ne $expected -or [PreviewGui]::GetForegroundWindow() -ne [IntPtr]$explorer.HWND){throw 'Real Linux node Space preview wrong hash/focus'}
  & "$PSScriptRoot\capture-window.ps1" -WindowHandle (Get-PreviewHandle).ToInt32() -Path artifacts\wsl-explorer-preview.png | Out-Null
  $gui=[pscustomobject]@{linux_node_clicked=$true;linux_node_path=$linuxNodePath;distribution_entered_via_keyboard=$distroPath;folder=$base;metrics=$m}
  [PreviewGui]::Key(32);Start-Sleep -Milliseconds 150
  if([PreviewGui]::IsWindowVisible((Get-PreviewHandle))){throw 'WSL Explorer Space close failed'}
  Write-Output 'Passed real Linux node mouse selection + Space formula preview'
 }
 $success=$true
} catch {$failure=$_.Exception.Message;throw} finally {
 if($process -and -not $process.HasExited){& "$repo\new-quicklook.exe" --quit;if(-not $process.WaitForExit(3000)){$process.Kill()}}
 Close-TestExplorer $explorer $baseline
 [pscustomobject]@{success=$success;failure=$failure;distribution=$Distribution;linux_root=$manifest.linux_root;cases=$results.ToArray();explorer=$gui;shell_baseline=$baseline;shell_after=@($shell.Windows()|ForEach-Object {$_.HWND})} | ConvertTo-Json -Depth 9 | Set-Content artifacts\wsl-preview-results.json -Encoding UTF8
}
