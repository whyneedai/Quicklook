﻿$ErrorActionPreference='Stop'

$repo = Split-Path $PSScriptRoot -Parent
Set-Location $repo
. .\scripts\worker-inventory.ps1
$before=@(Get-ProjectProcesses)
if($before.Count){throw 'Unexpected project process remains before restart'}
$files=@('new-quicklook.exe')+@((Get-WorkerInventory).workers|ForEach-Object {"worker\$($_.exe)"})
$builds=@('target\x86_64-pc-windows-msvc\release\new-quicklook.exe')+@((Get-WorkerInventory).workers|ForEach-Object {"target\x86_64-pc-windows-msvc\release\$($_.exe)"})
$artifacts=@()
for($i=0;$i -lt $files.Count;$i++) {
 $hash=(Get-FileHash $files[$i] -Algorithm SHA256).Hash
 if($hash -ne (Get-FileHash $builds[$i] -Algorithm SHA256).Hash){throw 'Delivered binary differs from release build'}
 $artifacts += [pscustomobject]@{path=$files[$i];bytes=(Get-Item $files[$i]).Length;sha256=$hash}
}
$p=Start-Process "$repo\new-quicklook.exe" -PassThru
Start-Sleep -Seconds 2
$after=@(Get-ProjectProcesses)
if($after.Count -ne 1 -or $after[0].ProcessId -ne $p.Id -or $after[0].ExecutablePath -ne "$repo\new-quicklook.exe"){throw 'Resident process verification failed'}
[pscustomobject]@{old_project_processes=$before.Count;artifacts=$artifacts;resident_pid=$p.Id;resident_path=$after[0].ExecutablePath;idle_workers=0} | ConvertTo-Json -Depth 5 | Set-Content artifacts\delivery-final.json -Encoding UTF8
Write-Output "Verified release hashes; no old project process; resident PID $($p.Id); no idle worker"
