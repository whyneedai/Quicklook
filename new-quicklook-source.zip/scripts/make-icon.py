"""Build crates/app/assets/app.ico from the source artwork without changing it.

Source of truth is `icon.ico` (the designer's multi-size file): every frame is kept
byte-for-byte in pixels and only re-encoded as PNG, which is lossless and much smaller
than the uncompressed BMP frames an ICO often carries (117 KB -> ~30 KB).
`icon.png` (the 256x256 frame) is a convenience preview; it is only used as a fallback
when `icon.ico` is absent, in which case sizes are resampled from it.
"""
import io
import struct
import sys
from pathlib import Path
from PIL import Image

root = Path(__file__).resolve().parents[1]
target = root / "crates/app/assets/app.ico"
source_ico = root / "icon.ico"
source_png = root / "icon.png"
SIZES = (16, 24, 32, 48, 64, 128, 256)


def decode_bmp_frame(blob: bytes, w: int, h: int) -> Image.Image:
    (size, bw, bh, _planes, bpp, comp, *_rest) = struct.unpack_from("<IiiHHIIiiII", blob, 0)
    assert bw == w and bh == 2 * h and bpp == 32 and comp == 0, (bw, bh, bpp, comp)
    stride = w * 4
    pixels = bytearray(w * h * 4)
    for y in range(h):
        row = blob[size + (h - 1 - y) * stride : size + (h - y) * stride]
        for x in range(w):
            b, g, r, a = row[x * 4 : x * 4 + 4]
            o = (y * w + x) * 4
            pixels[o : o + 4] = bytes((r, g, b, a))
    return Image.frombytes("RGBA", (w, h), bytes(pixels))


def frames_from_ico(data: bytes):
    _, _, count = struct.unpack_from("<HHH", data, 0)
    frames = []
    for i in range(count):
        w, h, _c, _r, _p, _bpp, size, off = struct.unpack_from("<BBBBHHII", data, 6 + i * 16)
        w, h = w or 256, h or 256
        blob = data[off : off + size]
        if blob[:8] == b"\x89PNG\r\n\x1a\n":
            frames.append((w, h, blob))
        else:
            buf = io.BytesIO()
            decode_bmp_frame(blob, w, h).save(buf, format="PNG", optimize=True)
            frames.append((w, h, buf.getvalue()))
    return frames


if source_ico.exists():
    frames = frames_from_ico(source_ico.read_bytes())
    missing = [n for n in SIZES if n not in {w for w, _, _ in frames}]
    if missing:
        print(f"warning: icon.ico is missing sizes {missing}", file=sys.stderr)
else:
    with Image.open(source_png) as source:
        rgba = source.convert("RGBA")
        frames = []
        for n in SIZES:
            buf = io.BytesIO()
            rgba.resize((n, n), Image.LANCZOS).save(buf, format="PNG", optimize=True)
            frames.append((n, n, buf.getvalue()))

out = bytearray(struct.pack("<HHH", 0, 1, len(frames)))
offset = 6 + 16 * len(frames)
entries, blobs = bytearray(), bytearray()
for w, h, blob in frames:
    entries += struct.pack(
        "<BBBBHHII", 0 if w == 256 else w, 0 if h == 256 else h, 0, 0, 1, 32, len(blob), offset
    )
    blobs += blob
    offset += len(blob)
out += entries + blobs
target.write_bytes(bytes(out))
print(f"{target.relative_to(root)}: {len(out)} bytes, sizes {[w for w, _, _ in frames]}")
