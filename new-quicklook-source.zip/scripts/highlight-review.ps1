﻿param([ValidateSet('before','after')][string]$Phase,[int]$Runs=20)
$repo = Split-Path $PSScriptRoot -Parent
. "$PSScriptRoot\process-args.ps1"

$ErrorActionPreference='Stop'
Set-Location $repo
. "$PSScriptRoot\gui-test.ps1"
if((Get-PreviewHandle) -ne [IntPtr]::Zero){throw 'Exit project resident before highlight measurements'}
# Freeze README and sample inputs for comparable before/after measurements.
$inputs="$repo\artifacts\highlight-inputs"
if($Phase -eq 'before') {
 New-Item -ItemType Directory -Force $inputs | Out-Null
 $manifest=@()
 foreach($path in @('samples\hello.rs','samples\hello.py','samples\large.py','README.md')) {
  $name=Split-Path $path -Leaf
  Copy-Item -LiteralPath $path -Destination (Join-Path $inputs $name)
  $manifest+=[pscustomobject]@{original=$path;name=$name;sha256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash;bytes=(Get-Item -LiteralPath $path).Length}
 }
 $manifest | ConvertTo-Json | Set-Content artifacts\highlight-inputs.json -Encoding UTF8
 Copy-Item new-quicklook.exe artifacts\highlight-before.exe
} else {$manifest=Get-Content artifacts\highlight-inputs.json -Raw -Encoding UTF8 | ConvertFrom-Json}
$oldWindow=$env:QUICKLOOK_WINDOW;$oldLayout=$env:QUICKLOOK_FULL_LAYOUT
$env:QUICKLOOK_WINDOW='1024x768';Remove-Item Env:\QUICKLOOK_FULL_LAYOUT -ErrorAction SilentlyContinue
$captures=@();$timings=@();$p=$null
try {
 foreach($sample in $manifest) {
  $path=Join-Path $inputs $sample.name
  if((Get-FileHash $path).Hash -ne $sample.sha256){throw 'Frozen screenshot input changed'}
  $report="$repo\artifacts\highlight-$Phase-$($sample.name).json"
  Remove-Item $report -ErrorAction SilentlyContinue
  $p=Start-Process "$repo\new-quicklook.exe" -ArgumentList @('--smoke',('"'+$path+'"'),('"'+$report+'"')) -PassThru
  for($i=0;$i -lt 80 -and (Get-PreviewHandle) -eq [IntPtr]::Zero;$i++){Start-Sleep -Milliseconds 25}
  $m=Read-PreviewReport $report {param($m) -not $m.error -and $null -ne $m.first_content_paint_ms -and $m.layout_complete}
  if($m.content_hash.ToUpperInvariant() -ne $sample.sha256 -and $sample.name -ne 'large.py'){throw 'Screenshot preview input digest mismatch'}
  $hwnd=Get-PreviewHandle
  & "$PSScriptRoot\capture-window.ps1" -WindowHandle $hwnd.ToInt32() -Path "artifacts\highlight-$Phase-$($sample.name).png" | Out-Null
  $captures+=[pscustomobject]@{original=$sample.original;input_sha256=$sample.sha256;geometry=(Get-TestRect $hwnd);dpi=[PreviewGui]::GetDpiForWindow($hwnd);metrics=$m}
  & "$repo\new-quicklook.exe" --quit
  if(-not $p.WaitForExit(5000)){throw 'Capture application did not exit'};$p=$null
 }
 $large="$repo\samples\large.py"
 $expected=@($manifest|Where-Object {$_.name -eq 'large.py'})[0].sha256
 if((Get-FileHash $large).Hash -ne $expected){throw 'large.py changed between A/B phases'}
 # Each sample is a fresh process using --smoke, one excluded warmup then 20
 # filesystem-warm measurements. This is not a cold-cache benchmark or Space test.
 for($i=0;$i -le $Runs;$i++) {
  $report="$repo\artifacts\highlight-$Phase-perf-$i.json"
  Remove-Item $report -ErrorAction SilentlyContinue
  $p=Start-Process "$repo\new-quicklook.exe" -ArgumentList (Join-ProcessArguments @('--smoke',$large,$report)) -PassThru
  if(-not $p.WaitForExit(15000) -or $p.ExitCode -ne 0){throw 'Performance probe failed'};$p=$null
  $m=Read-PreviewReport $report
  if($m.error -or -not $m.truncated){throw 'large.py performance probe did not preview bounded content'}
  if($i -gt 0){$timings+=$m}
 }
 $result=[pscustomobject]@{phase=$Phase;method='fresh process --smoke; filesystem warm; one excluded warmup; fixed 1024x768 logical window; incremental exact GDI layout';executable_sha256=(Get-FileHash new-quicklook.exe).Hash;large_input_sha256=$expected;captures=$captures;timings=$timings}
 $result | ConvertTo-Json -Depth 7 | Set-Content "artifacts\highlight-$Phase-results.json" -Encoding UTF8
 Write-Output "Captured four $Phase windows and $Runs large.py timings"
} finally {
 if($p -and -not $p.HasExited){& "$repo\new-quicklook.exe" --quit;if(-not $p.WaitForExit(3000)){$p.Kill()}}
 if($null -eq $oldWindow){Remove-Item Env:\QUICKLOOK_WINDOW -ErrorAction SilentlyContinue}else{$env:QUICKLOOK_WINDOW=$oldWindow}
 if($null -eq $oldLayout){Remove-Item Env:\QUICKLOOK_FULL_LAYOUT -ErrorAction SilentlyContinue}else{$env:QUICKLOOK_FULL_LAYOUT=$oldLayout}
}
