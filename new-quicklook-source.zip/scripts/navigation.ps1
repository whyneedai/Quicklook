﻿param([string]$Label='navigation')
$repo = Split-Path $PSScriptRoot -Parent
. "$PSScriptRoot\process-args.ps1"
$repoUri = ([Uri]($repo+'\')).AbsoluteUri.TrimEnd('/')

$ErrorActionPreference='Stop'
Set-Location $repo
. "$PSScriptRoot\gui-test.ps1"
. "$PSScriptRoot\preview-windows.ps1"
if((Get-PreviewHandle) -ne [IntPtr]::Zero){throw 'Exit project resident before GUI tests'}
$fixture="$repo\artifacts\navigation-fixtures"
New-Item -ItemType Directory -Force $fixture | Out-Null
1..24 | ForEach-Object { [IO.File]::WriteAllText((Join-Path $fixture ('nav-{0:d2}.txt' -f $_)),("Navigation fixture $_`nDistinct content $_`n")) }
$report="$repo\artifacts\$Label-current.json"
$results=[Collections.Generic.List[object]]::new();$success=$false;$failure=$null
$shell=New-Object -ComObject Shell.Application
$baseline=@($shell.Windows() | ForEach-Object {$_.HWND})
$explorer=$null;$process=$null;$other=$null
function Selection-Name { @($explorer.Document.SelectedItems() | ForEach-Object {$_.Name}) -join ',' }
function Assert-Visible([bool]$Expected) {
 for($i=0;$i -lt 100 -and [PreviewGui]::IsWindowVisible($hwnd) -ne $Expected;$i++){Start-Sleep -Milliseconds 25}
 if([PreviewGui]::IsWindowVisible($hwnd) -ne $Expected){throw "Preview visibility expected=$Expected"}
}
function Save-Step([string]$Step,$Metrics) {
 $results.Add([pscustomobject]@{step=$Step;selection=(Selection-Name);foreground=[PreviewGui]::GetForegroundWindow().ToInt64();visible=[PreviewGui]::IsWindowVisible($hwnd);geometry=(Get-TestRect $hwnd);metrics=$Metrics;uncovered=[PreviewWindows]::Uncovered($hwnd);above=@([PreviewWindows]::Above($hwnd)|ForEach-Object {Get-WindowProbe $_})})
 Write-Output "$Step selection=$(Selection-Name) visible=$([PreviewGui]::IsWindowVisible($hwnd))"
}
function Arrow([byte]$Key,[string]$Expected,[string]$Step) {
 $old=Read-PreviewReport $report
 [PreviewGui]::Key($Key)
 $m=Read-PreviewReport $report {param($m) $m.file_name -eq $Expected -and $m.generation -gt $old.generation -and $null -ne $m.first_content_paint_ms}
 if($m.error -or (Selection-Name) -ne $Expected){throw "$Step selection/preview mismatch"}
 if((Get-TestRect $hwnd | ConvertTo-Json -Compress) -ne $geometry){throw "$Step changed window geometry"}
 if([PreviewGui]::GetForegroundWindow() -ne [IntPtr]$explorer.HWND){throw "$Step lost Explorer focus"}
 Save-Step $Step $m
}
function View-Mode([byte]$Digit) {
 Focus-TestWindow ([IntPtr]$explorer.HWND)
 $explorer.Document.CurrentViewMode=$(if($Digit -eq 0x36){4}else{1})
 Start-Sleep -Milliseconds 500
}
try {
 $process=Start-Process "$repo\new-quicklook.exe" -ArgumentList (Join-ProcessArguments @('--trace',$report)) -PassThru
 Start-Process explorer.exe -ArgumentList ('/n,"'+$fixture+'"') | Out-Null
 for($i=0;$i -lt 60;$i++) {
  Start-Sleep -Milliseconds 100
  $explorer=@($shell.Windows()|Where-Object {$baseline -notcontains $_.HWND -and $_.Document.Folder.Self.Path -eq $fixture})|Select-Object -First 1
  if($explorer -and (Get-PreviewHandle) -ne [IntPtr]::Zero){break}
 }
 if(-not $explorer){throw 'Test Explorer not found'}
 $hwnd=Get-PreviewHandle
 [void][PreviewGui]::ShowWindow([IntPtr]$explorer.HWND,9)
 [void][PreviewGui]::SetWindowPos([IntPtr]$explorer.HWND,[IntPtr]::Zero,80,80,1700,1300,0x14)
 View-Mode 0x36
 Click-ExplorerFile $explorer 'nav-02.txt'
 Remove-Item $report -ErrorAction SilentlyContinue
 [PreviewGui]::Key(32);Assert-Visible $true
 $m=Read-PreviewReport $report {param($m) $m.file_name -eq 'nav-02.txt' -and $null -ne $m.first_content_paint_ms}
 if($m.error -or [PreviewGui]::GetForegroundWindow() -ne [IntPtr]$explorer.HWND){throw 'Space opening failed or stole focus'}
 # A custom user-sized window must survive text/image navigation too.
 [void][PreviewGui]::SetWindowPos($hwnd,[IntPtr]::Zero,410,320,1050,730,0x14)
 $geometry=Get-TestRect $hwnd | ConvertTo-Json -Compress
 Save-Step 'details-open' $m
 Arrow 0x28 'nav-03.txt' 'details-down'
 Arrow 0x26 'nav-02.txt' 'details-up'
 [PreviewGui]::Key(32);Assert-Visible $false;Save-Step 'space-close-no-click' $null
 [PreviewGui]::Key(32);Assert-Visible $true
 $m=Read-PreviewReport $report {param($m) $m.file_name -eq 'nav-02.txt' -and $null -ne $m.first_content_paint_ms}
 Save-Step 'space-reopen-no-click' $m
 [PreviewGui]::Key(27);Assert-Visible $false;Save-Step 'escape-close-no-click' $null
 View-Mode 0x32
 $items=@(Get-ExplorerItems ([IntPtr]$explorer.HWND) | Where-Object {$_.name -like 'nav-*.txt'} | Sort-Object y,x)
 $rows=@($items | Group-Object y | Sort-Object {[double]$_.Name})
 Write-Output "Grid mode=$($explorer.Document.CurrentViewMode) items=$($items.Count) rowCounts=$($rows | ForEach-Object {$_.Count})"
 $items | ConvertTo-Json -Depth 5 | Set-Content "artifacts\$Label-grid-observed.json" -Encoding UTF8
 if($rows.Count -lt 2 -or $rows[0].Count -lt 2){throw 'Explorer did not produce a 2D grid'}
 $row0=@($rows[0].Group | Sort-Object x);$row1=@($rows[1].Group | Sort-Object x)
 $grid=[pscustomobject]@{rows=$rows.Count;columns=$row0.Count;items=$items}
 $grid | ConvertTo-Json -Depth 5 | Set-Content "artifacts\$Label-grid.json" -Encoding UTF8
 & "$PSScriptRoot\capture-window.ps1" -WindowHandle ([int]$explorer.HWND) -Path "artifacts\$Label-grid.png" | Out-Null
 Click-ExplorerFile $explorer $row0[0].name
 [PreviewGui]::Key(32);Assert-Visible $true
 $m=Read-PreviewReport $report {param($m) $m.file_name -eq $row0[0].name -and $null -ne $m.first_content_paint_ms}
 $geometry=Get-TestRect $hwnd | ConvertTo-Json -Compress
 Save-Step 'grid-open' $m
 Arrow 0x28 $row1[0].name 'grid-down'
 Arrow 0x26 $row0[0].name 'grid-up'
 for($i=1;$i -lt $row0.Count;$i++){Arrow 0x27 $row0[$i].name "grid-right-$i"}
 Arrow 0x27 $row1[0].name 'grid-right-wrap'
 Arrow 0x25 $row0[-1].name 'grid-left-wrap'
 Arrow 0x25 $row0[-2].name 'grid-left'
 # Click the preview for copy/select, then navigate without another click.
 $r=Get-TestRect $hwnd
 [PreviewGui]::Click(($r.x+120),($r.y+180));Start-Sleep -Milliseconds 100
 if([PreviewGui]::GetForegroundWindow() -ne $hwnd){throw 'Preview mouse activation failed'}
 Arrow 0x27 $row0[-1].name 'preview-focused-right'
 # P works without moving the focus; neither action changes the geometry.
 [PreviewGui]::Key(0x50);Start-Sleep -Milliseconds 150
 if(([PreviewGui]::GetWindowLongW($hwnd,-20) -band 8) -eq 0){throw 'P did not pin'}
 [PreviewGui]::Key(0x50);Start-Sleep -Milliseconds 150
 if(([PreviewGui]::GetWindowLongW($hwnd,-20) -band 8) -ne 0){throw 'P did not unpin'}
 Save-Step 'pin-toggle-no-click' (Read-PreviewReport $report)
 & "$PSScriptRoot\capture-window.ps1" -WindowHandle $hwnd.ToInt32() -Path "artifacts\$Label-preview.png" | Out-Null
 # Use an owned second Explorer window as the unrelated foreground application;
 # this also proves keys cannot switch a preview from another Explorer root.
 Start-Process explorer.exe -ArgumentList ('/n,"'+$repo+'\samples"') | Out-Null
 for($i=0;$i -lt 50;$i++) {
  Start-Sleep -Milliseconds 100
  $other=@($shell.Windows()|Where-Object {$baseline -notcontains $_.HWND -and $_.HWND -ne $explorer.HWND -and $_.LocationURL -eq "$repoUri/samples"})|Select-Object -First 1
  if($other){break}
 }
 if(-not $other){throw 'Other foreground window missing'}
 Focus-TestWindow ([IntPtr]$other.HWND)
 $other.Document.SelectItem($other.Document.Folder.ParseName('hello.py'),29)
 $old=Read-PreviewReport $report
 foreach($key in @(0x28,0x27,0x25,0x26,32,27,0x50,0x4d)){[PreviewGui]::Key($key);Start-Sleep -Milliseconds 80}
 $after=Read-PreviewReport $report
 if(-not [PreviewGui]::IsWindowVisible($hwnd) -or $after.generation -ne $old.generation -or $after.file_name -ne $old.file_name -or $after.content_hash -ne $old.content_hash -or (Get-TestRect $hwnd | ConvertTo-Json -Compress) -ne $geometry){throw 'Background preview reacted to unrelated foreground keys'}
 Save-Step 'background-keys-ignored' $after
 Close-TestExplorer $other $baseline;$other=$null
 # Returning to Explorer alone leaves the preview underneath it. It must still
 # ignore P/M/Esc/arrows; Space recall is tested in raise-preview.ps1.
 Focus-TestWindow ([IntPtr]$explorer.HWND)
 foreach($key in @(0x28,27,0x50,0x4d)){[PreviewGui]::Key($key);Start-Sleep -Milliseconds 100}
 $after=Read-PreviewReport $report
 if($after.generation -ne $old.generation -or -not [PreviewGui]::IsWindowVisible($hwnd)){throw 'Covered preview reacted to keys'}
 Save-Step 'covered-keys-ignored' $after
 Focus-TestWindow $hwnd
 [PreviewGui]::Key(27);Assert-Visible $false;Save-Step 'foreground-escape' $null
 $success=$true
 Write-Output 'Passed real Explorer 1D/2D navigation, both row wraps, geometry, Space/Esc and foreground isolation'
} catch {$failure=$_.Exception.Message;throw} finally {
 [pscustomobject]@{success=$success;failure=$failure;shell_baseline=$baseline;steps=$results.ToArray()} | ConvertTo-Json -Depth 9 | Set-Content "artifacts\$Label-results.json" -Encoding UTF8
 if($process -and -not $process.HasExited){& "$repo\new-quicklook.exe" --quit;if(-not $process.WaitForExit(3000)){$process.Kill()}}
 Close-TestExplorer $other $baseline
 Close-TestExplorer $explorer $baseline
}
