"""Create isolated Linux filesystem fixtures, retaining them for review."""
import json
import os
from pathlib import Path
import struct
import subprocess
import tempfile
import zlib

root = Path(tempfile.mkdtemp(prefix="new-quicklook-preview-"))
# No project/source files are written outside the repository root: this temporary Linux
# directory is the explicit exception needed to test the requested WSL filesystem.
(root / "文本.txt").write_text("WSL Unicode preview\n中文文件内容。\n", encoding="utf-8")
(root / "公式.md").write_text(
    "# WSL Markdown\n\n中文正文保持安静。\n\nInline $x^2 + y^2 = z^2$.\n\n$$\n\\frac{1}{2} + \\sqrt{x}\n$$\n", encoding="utf-8"
)
(root / "hello.py").write_text("class Preview:\n    def greet(self):\n        return 'WSL code'\n", encoding="utf-8")
(root / "large.py").write_text('print("WSL bounded preview") # large fixture\n' * 25000, encoding="utf-8")

def chunk(kind, data):
    return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data))

width, height = 73, 41
pixels = b"".join(b"\0" + bytes([50, 140, 180, 255]) * width for _ in range(height))
(root / "image.png").write_bytes(
    b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0))
    + chunk(b"IDAT", zlib.compress(pixels)) + chunk(b"IEND", b"")
)
files = []
for path in sorted(root.iterdir()):
    raw = path.read_bytes()
    full = subprocess.check_output(["sha256sum", "--", str(path)], text=True).split()[0]
    prefix = subprocess.check_output(["sha256sum"], input=raw[:262144]).decode().split()[0]
    files.append({"name": path.name, "bytes": len(raw), "sha256sum": full,
                  "bounded_sha256sum": prefix, "bounded_bytes": min(len(raw), 262144)})
(root / "denied.txt").write_text("Only the dedicated test fixture is chmod 000.\n", encoding="utf-8")
(root / "denied.txt").chmod(0)
print(json.dumps({"distribution": os.environ["WSL_DISTRO_NAME"], "linux_root": str(root), "files": files, "image_width": width,
                  "image_height": height, "text_limit": 262144}, ensure_ascii=False))
