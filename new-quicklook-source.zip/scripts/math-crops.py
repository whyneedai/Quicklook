"""Pixel-equality harness for the math worker: send expressions, hash the crops.

Usage:
  python3 scripts/math-crops.py before|after
Writes artifacts/math-crops-<label>.json and artifacts/math-crops-<label>/*.bmp.
The two runs must produce identical pixel hashes (no quality change).
"""
import hashlib, json, pathlib, struct, subprocess, sys

root = pathlib.Path(__file__).resolve().parents[1]
exe = root / 'target/x86_64-pc-windows-msvc/release/math-worker.exe'
label = sys.argv[1] if len(sys.argv) > 1 else 'run'
corpus = json.loads((root / 'samples/math-corpus.json').read_text())
extra = [
    r'\begin{bmatrix} a & b \\ c & d \end{bmatrix}',
    r'\begin{cases} x & x>0 \\ -x & x\le 0 \end{cases}',
    r'\begin{aligned} a &= b \\ c &= d \end{aligned}',
    r'\operatorname{sgn}(x)+\dfrac{1}{2}+\color{red} y',
    r'\sum_{i=1}^{n} \frac{1}{i^2}',
    r'\overbrace{a+b}^{n}',
    r'\int_0^1 \sqrt{\frac{x}{1+x}} dx',
    'x+' * 300 + 'x',
    r'\begin{matrix} ' + ' \\\\ '.join('a_{%d}' % i for i in range(40)) + r' \end{matrix}',
]
cases = corpus + extra
outdir = root / f'artifacts/math-crops-{label}'
outdir.mkdir(parents=True, exist_ok=True)
rows = []
p = subprocess.Popen([str(exe)], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
try:
    for i, tex in enumerate(cases):
        raw = tex.encode()
        p.stdin.write(b'NQM1' + struct.pack('<QQIII', i, 1, 96, 1, len(raw)) + raw)
        p.stdin.flush()
        header = p.stdout.read(52)
        if len(header) != 52:
            raise RuntimeError(f'worker stopped at {i}')
        magic, rid, gen, w, h, base, n, dpi, convert, draw, backend = struct.unpack(
            '<4sQQIIIIIIII', header)
        assert magic == b'NQR2' and n == w * h * 4
        pixels = p.stdout.read(n)
        digest = hashlib.sha256(pixels).hexdigest()
        rows.append(dict(index=i, tex=tex, w=w, h=h, baseline=base,
                         backend=backend, sha256=digest))
        bmp = struct.pack('<2sIHHI', b'BM', 54 + n, 0, 0, 54) + struct.pack(
            '<IiiHHIIiiII', 40, w, -h, 1, 32, 0, n, 0, 0, 0, 0) + pixels
        (outdir / f'{i:03d}.bmp').write_bytes(bmp)
finally:
    p.kill()
    p.wait()
(root / f'artifacts/math-crops-{label}.json').write_text(json.dumps(rows, indent=2))
print(f'{label}: {len(rows)} crops hashed -> artifacts/math-crops-{label}.json')
