﻿$ErrorActionPreference='Stop'
$repo=Split-Path $PSScriptRoot -Parent
Set-Location $repo
. "$PSScriptRoot\worker-inventory.ps1"
$files=@([pscustomobject]@{path='new-quicklook.exe';label='main'})
$files+=@((Get-WorkerInventory).workers|ForEach-Object {[pscustomobject]@{path="worker\$($_.exe)";label=$_.exe}})
foreach($file in $files) {
 foreach($section in @('dependents','headers')) {
  & dumpbin.exe "/$section" $file.path | Set-Content "artifacts\pe-$($file.label)-$section.txt" -Encoding UTF8
  if($LASTEXITCODE -ne 0){throw "PE audit failed for $($file.path)"}
 }
}
Write-Output "Audited $($files.Count) delivery executables"
