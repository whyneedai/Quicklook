@echo off
chcp 65001 >nul
call "%~dp0env.cmd"
if errorlevel 1 exit /b 1
call cargo fmt --all -- --check
if errorlevel 1 exit /b 1
call cargo test --workspace --locked --features worker-tests
if errorlevel 1 exit /b 1
powershell -NoProfile -ExecutionPolicy Bypass -File scripts\architecture.ps1
if errorlevel 1 exit /b 1
call cargo clippy --workspace --all-targets --locked --features worker-tests -- -D warnings
if errorlevel 1 exit /b 1
powershell -NoProfile -ExecutionPolicy Bypass -File scripts\stop-project.ps1
if errorlevel 1 exit /b 1
call cargo build --release --locked
if errorlevel 1 exit /b 1
powershell -NoProfile -ExecutionPolicy Bypass -File scripts\copy-delivery.ps1
exit /b %errorlevel%
