﻿param([string]$Label='placement-small')
$repo = Split-Path $PSScriptRoot -Parent
. "$PSScriptRoot\process-args.ps1"

$ErrorActionPreference='Stop'
Set-Location $repo
. "$PSScriptRoot\gui-test.ps1"
Add-Type @'
using System;using System.Runtime.InteropServices;using System.Text;
public static class Place {
 [StructLayout(LayoutKind.Sequential)] public struct RECT {public int left,top,right,bottom;}
 [StructLayout(LayoutKind.Sequential)] public struct MONITORINFO {public int cbSize;public RECT rcMonitor;public RECT rcWork;public uint dwFlags;}
 [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h,out RECT r);
 [DllImport("user32.dll")] public static extern IntPtr MonitorFromWindow(IntPtr h,uint f);
 [DllImport("user32.dll")] public static extern bool GetMonitorInfoW(IntPtr m,ref MONITORINFO i);
 [DllImport("user32.dll")] public static extern uint GetDpiForWindow(IntPtr h);
 public static RECT WorkArea(IntPtr hwnd){var m=MonitorFromWindow(hwnd,2);var i=new MONITORINFO();i.cbSize=Marshal.SizeOf(i);GetMonitorInfoW(m,ref i);return i.rcWork;}
 public static int[] Expected(int w,int h,int dpi,string kind,int srcW,int srcH,int baseW,int baseH){
   dpi=Math.Max(dpi,96);
   int maxw=Math.Max(w-40,320), maxh=Math.Max(h-40,240);
   int bw=Math.Max(Math.Min(baseW*dpi/96,maxw),320), bh=Math.Max(Math.Min(baseH*dpi/96,maxh),240);
   if(kind!="image"){ return new int[]{bw,bh}; }
   int chromeW=48*dpi/96, chromeH=132*dpi/96;
   int capW=Math.Min(Math.Max(maxw-chromeW,1),1600), capH=Math.Min(Math.Max(maxh-chromeH,1),1200);
   // quicklook_core::fit_size: never upscales, preserves aspect ratio
   int fw,fh; int bw2=Math.Min(capW,srcW), bh2=Math.Min(capH,srcH);
   if((long)srcW*bh2 > (long)srcH*bw2){ fw=bw2; fh=(int)Math.Max(1,(long)srcH*bw2/srcW); }
   else { fw=(int)Math.Max(1,(long)srcW*bh2/srcH); fh=bh2; }
   int ew=Math.Min(Math.Max(fw+chromeW,bw),maxw), eh=Math.Min(Math.Max(fh+chromeH,bh),maxh);
   return new int[]{ew,eh};
 }
}
'@
$exe="$repo\new-quicklook.exe";$report="$repo\artifacts\$Label-current.json"
if((Get-PreviewHandle) -ne [IntPtr]::Zero){throw 'Exit resident before placement validation'}
$shell=New-Object -ComObject Shell.Application;$before=@($shell.Windows()|ForEach-Object {$_.HWND})
$oldPreference=$env:QUICKLOOK_WINDOW;$explorer=$null;$process=$null;$success=$false;$failure=$null;$results=[Collections.Generic.List[object]]::new()
function Start-Resident {
 Remove-Item $report -ErrorAction SilentlyContinue
 $script:process=Start-Process $exe -ArgumentList (Join-ProcessArguments @('--trace',$report)) -PassThru
 for($j=0;$j -lt 80;$j++){Start-Sleep -Milliseconds 50;$script:hwnd=Get-PreviewHandle;if($hwnd -ne [IntPtr]::Zero){return}}
 throw 'Resident missing'
}
function Stop-Resident {
 & $exe --quit
 if($process -and -not $process.WaitForExit(3000)){throw 'Resident failed to exit'}
}
function Open-Sample([string]$Name) {
 if([PreviewGui]::IsWindowVisible($hwnd)){[PreviewGui]::Key(27);Start-Sleep -Milliseconds 150;if([PreviewGui]::IsWindowVisible($hwnd)){throw 'First Esc failed'}}
 Focus-TestWindow $eh
 [PreviewGui]::Key(0x24)
 for($j=0;$j -lt 80;$j++){
  Start-Sleep -Milliseconds 45;$selection=@($explorer.Document.SelectedItems())
  if($selection.Count -eq 1 -and $selection[0].Name -eq $Name){break}
  [PreviewGui]::Key(0x28)
 }
 if($selection.Count -ne 1 -or $selection[0].Name -ne $Name){throw "Keyboard selection failed: $Name"}
 $old=0;if(Test-Path $report){$old=(Get-Content $report -Raw|ConvertFrom-Json).generation}
 [PreviewGui]::Key(32)
 $m=Read-PreviewReport $report {param($m) $m.generation -gt $old -and $m.file_name -eq $Name -and $null -ne $m.first_content_paint_ms -and -not $m.error}
 if(-not [PreviewGui]::IsWindowVisible($hwnd)){throw "Preview missing: $Name"}
 Start-Sleep -Milliseconds 150
 return $m
}
function Measure-Placement([string]$Name,[string]$Kind,[int]$Iw,[int]$Ih,[int]$Bw=900,[int]$Bh=680) {
 $r=Get-TestRect $hwnd;$work=[Place]::WorkArea($hwnd);$dpi=[int][PreviewGui]::GetDpiForWindow($hwnd)
 $aw=$work.right-$work.left;$ah=$work.bottom-$work.top;$expect=[Place]::Expected($aw,$ah,$dpi,$Kind,$Iw,$Ih,$Bw,$Bh)
 $centered=[Math]::Abs($r.x-($work.left+[int][Math]::Floor(($aw-$r.width)/2))) -le 2 -and [Math]::Abs($r.y-($work.top+[int][Math]::Floor(($ah-$r.height)/2))) -le 2
 $sized=[Math]::Abs($r.width-$expect[0]) -le 2 -and [Math]::Abs($r.height-$expect[1]) -le 2
 $result=[pscustomobject]@{file=$Name;geometry=$r;dpi=$dpi;logical_width=($r.width*96/$dpi);logical_height=($r.height*96/$dpi);expected=$expect;centered=$centered;correct_size=$sized;metrics=(Get-Content $report -Raw|ConvertFrom-Json)}
 $results.Add($result);Write-Output "$Name $($r.width)x$($r.height)@$dpi centered=$centered correct_size=$sized"
 if(-not $centered -or -not $sized){throw 'Placement mismatch'}
 & "$PSScriptRoot\capture-window.ps1" -WindowHandle $hwnd.ToInt32() -Path "artifacts\$Label-$($results.Count).png" | Out-Null
}
try {
 Remove-Item Env:\QUICKLOOK_WINDOW -ErrorAction SilentlyContinue
 Start-Resident
 Start-Process explorer.exe -ArgumentList ('/n,"'+$repo+'\samples"') | Out-Null
 for($i=0;$i -lt 60;$i++){Start-Sleep -Milliseconds 100;$explorer=@($shell.Windows()|Where-Object {$before -notcontains $_.HWND -and $_.Document.Folder.Self.Path -eq "$repo\samples"})|Select-Object -First 1;if($explorer){break}}
 if(-not $explorer){throw 'Owned Explorer missing'};$eh=[IntPtr]$explorer.HWND
 [void][PreviewGui]::ShowWindow($eh,9);[void][PreviewGui]::SetWindowPos($eh,[IntPtr]::Zero,0,30,2100,1640,0x14)
 $explorer.Document.CurrentViewMode=4;Start-Sleep -Milliseconds 400
 Click-ExplorerFile $explorer 'hello.py'
 Open-Sample 'welcome.md' | Out-Null;Measure-Placement 'welcome.md' 'text' 0 0
 $r=Get-TestRect $hwnd;$x=$r.x+$r.width-2;$y=$r.y+[int]($r.height/2)
 [void][PreviewGui]::SetCursorPos($x,$y);[PreviewGui]::mouse_event(2,0,0,0,[UIntPtr]::Zero);Start-Sleep -Milliseconds 80
 [void][PreviewGui]::SetCursorPos(($x+100),$y);Start-Sleep -Milliseconds 100;[PreviewGui]::mouse_event(4,0,0,0,[UIntPtr]::Zero);Start-Sleep -Milliseconds 200
 $resized=Get-TestRect $hwnd
 if([Math]::Abs($resized.width-($r.width+100)) -gt 4 -or $resized.x -ne $r.x -or $resized.height -ne $r.height){throw 'Real mouse resize failed'}
 $resizeEvidence=[pscustomobject]@{before=$r;after=$resized;real_mouse=$true}
 Open-Sample 'welcome.md' | Out-Null;Measure-Placement 'reopen' 'text' 0 0
 Open-Sample 'small.png' | Out-Null;Measure-Placement 'small.png' 'image' 64 48
 Open-Sample 'big.png' | Out-Null;Measure-Placement 'big.png' 'image' 4096 3072
 Stop-Resident;$env:QUICKLOOK_WINDOW='700x500';Start-Resident
 Open-Sample 'big.png' | Out-Null;Measure-Placement 'big.png-override' 'image' 4096 3072 700 500
 if($results[4].metrics.image_fit -notlike '*grown*'){throw 'Override image did not grow'}
 $success=$true
} catch {$failure=$_.Exception.Message;throw} finally {
 if($process -and -not $process.HasExited){& $exe --quit;if(-not $process.WaitForExit(3000)){$process.Kill()}}
 if($null -eq $oldPreference){Remove-Item Env:\QUICKLOOK_WINDOW -ErrorAction SilentlyContinue}else{$env:QUICKLOOK_WINDOW=$oldPreference}
 Close-TestExplorer $explorer $before
 [pscustomobject]@{success=$success;failure=$failure;exe_sha256=(Get-FileHash $exe).Hash;shell_before=$before;shell_after=@($shell.Windows()|ForEach-Object {$_.HWND});resize=$resizeEvidence;cases=@($results)}|ConvertTo-Json -Depth 12|Set-Content "artifacts\$Label-results.json" -Encoding UTF8
}
