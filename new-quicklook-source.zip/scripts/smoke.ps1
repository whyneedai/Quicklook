﻿param([switch]$Capture)
$repo = Split-Path $PSScriptRoot -Parent
. "$PSScriptRoot\process-args.ps1"

$ErrorActionPreference = 'Stop'
Set-Location $repo
$env:TEMP = "$repo\.cache\tmp"
$env:TMP = $env:TEMP
$exe = "$repo\target\x86_64-pc-windows-msvc\release\new-quicklook.exe"
$results = @()
# Generated adversarial-size fixture stays in the project; it is never executed.
[System.IO.File]::WriteAllText("$repo\samples\large.py", ('print("bounded preview") # sample' + "`n") * 20000, [System.Text.UTF8Encoding]::new($false))
foreach ($name in @('welcome.md','hello.py','hello.rs','gradient.png','broken.png','large.py')) {
    $report = "$repo\artifacts\$name.json"
    $process = Start-Process $exe -ArgumentList (Join-ProcessArguments @('--smoke',"$repo\samples\$name",$report)) -PassThru
    if (-not $process.WaitForExit(15000)) { $process.Kill(); throw "Timed out: $name" }
    if ($process.ExitCode -ne 0) {throw "Crash: $name code $($process.ExitCode)"}
    $data = Get-Content $report -Raw | ConvertFrom-Json
    if ($name -ne 'broken.png' -and ($data.error -or $null -eq $data.first_content_paint_ms)) {throw "Preview failed: $name"}
    if ($name -eq 'broken.png' -and -not $data.error) {throw 'Malformed PNG was accepted'}
    if ($name -eq 'large.py' -and -not $data.truncated) {throw 'Large text was not marked truncated'}
    $results += [pscustomobject]@{file=$name;metrics=$data}
}
$process = Start-Process $exe -ArgumentList (Join-ProcessArguments @('--idle-probe',"$repo\artifacts\idle.json")) -PassThru
if (-not $process.WaitForExit(10000)) {$process.Kill();throw 'Idle probe timed out'}
$results += [pscustomobject]@{file='idle';metrics=(Get-Content artifacts\idle.json -Raw | ConvertFrom-Json)}
$results | ConvertTo-Json -Depth 5 | Set-Content artifacts\smoke-results.json -Encoding UTF8
$results | ConvertTo-Json -Depth 5
if ($Capture) {
    foreach ($name in @('welcome.md','hello.py','hello.rs','gradient.png')) {
        $process = Start-Process $exe -ArgumentList (Join-ProcessArguments @("$repo\samples\$name")) -PassThru
        try {
            Start-Sleep -Milliseconds 700
            $process.Refresh()
            if ($process.MainWindowHandle -eq 0) {throw "Missing window: $name"}
            & "$repo\scripts\capture-window.ps1" -Path "$repo\artifacts\$name.png" -WindowHandle $process.MainWindowHandle.ToInt32()
        } finally {
            if (-not $process.HasExited) { $null=$process.CloseMainWindow(); if (-not $process.WaitForExit(5000)) {$process.Kill()} }
        }
    }
}
