﻿param([string]$Label='pdf',[switch]$SkipExplorer)
$ErrorActionPreference='Stop'
$repo=Split-Path $PSScriptRoot -Parent
Set-Location $repo
. "$PSScriptRoot\gui-test.ps1"
. "$PSScriptRoot\worker-inventory.ps1"
if((Get-PreviewHandle) -ne [IntPtr]::Zero){throw 'Exit the project resident before PDF validation'}
$results=[Collections.Generic.List[object]]::new();$success=$false;$failure=$null
$shell=New-Object -ComObject Shell.Application
$baseline=@($shell.Windows()|ForEach-Object {$_.HWND});$before=@($shell.Windows()|ForEach-Object {[pscustomobject]@{hwnd=$_.HWND;url=$_.LocationURL}})
$process=$null;$explorer=$null;$report="$repo\artifacts\$Label-current.json"
function Save-Step([string]$Name,$Metrics) {
 $results.Add([pscustomobject]@{step=$Name;metrics=$Metrics;geometry=$(if($hwnd -and [PreviewGui]::IsWindowVisible($hwnd)){Get-TestRect $hwnd}else{$null});foreground=[PreviewGui]::GetForegroundWindow().ToInt64();workers=@(Get-ProjectProcesses|Where-Object Name -eq 'pdf-worker.exe'|ForEach-Object {$_.ProcessId})})
 Write-Output "Passed $Name"
}
function Read-Page([string]$Name,[int]$Index,[long]$After=0) {
 Read-PreviewReport $report {param($m) $m.file_name -eq $Name -and $m.page_ready -and $m.page_index -eq $Index -and $m.generation -gt $After -and -not $m.error -and $null -ne $m.first_content_paint_ms} 14000
}
function Wheel([int]$Delta,[switch]$Control) {
 $r=Get-TestRect $hwnd
 [void][PreviewGui]::SetCursorPos(($r.x+$r.width/2),($r.y+$r.height/2))
 Start-Sleep -Milliseconds 80
 if($Control){[PreviewGui]::keybd_event(17,0,0,[UIntPtr]::Zero)}
 try{[PreviewGui]::mouse_event(0x800,0,0,[BitConverter]::ToUInt32([BitConverter]::GetBytes([int32]$Delta),0),[UIntPtr]::Zero)}finally{if($Control){[PreviewGui]::keybd_event(17,0,2,[UIntPtr]::Zero)}}
}
function Assert-Geometry {
 if((Get-TestRect $hwnd|ConvertTo-Json -Compress) -ne $geometry){throw 'Page turn changed window geometry'}
}
try {
 $cases=@(
  @{name='01-pages.pdf';path="$repo\samples\pdf\01-pages.pdf";pages=3},
  @{name='02-other.pdf';path="$repo\samples\pdf\02-other.pdf";pages=2},
  @{name='broken.pdf';path="$repo\samples\pdf\broken.pdf";error='Windows PDF'},
  @{name='header.pdf';path="$repo\samples\pdf\header.pdf";error='Invalid PDF header'},
  @{name='password.pdf';path="$repo\samples\pdf\password.pdf";error='password'},
  @{name='pdf-too-large.pdf';path="$repo\artifacts\pdf-too-large.pdf";error='limit'},
  @{name='pdf-count-limit.pdf';path="$repo\artifacts\pdf-count-limit.pdf";error='page count'}
 )
 foreach($case in $cases) {
  $out="$repo\artifacts\$Label-smoke-$($case.name).json";Remove-Item $out -ErrorAction SilentlyContinue
  $p=Start-Process "$repo\new-quicklook.exe" -ArgumentList @('--smoke',('"'+$case.path+'"'),('"'+$out+'"')) -PassThru
  try {if(-not $p.WaitForExit(15000)){throw "PDF smoke timed out: $($case.name)"};if($p.ExitCode -ne 0){throw "PDF process crashed: $($case.name)"}}
  finally {if(-not $p.HasExited){$p.Kill();$p.WaitForExit()}}
  $m=Read-PreviewReport $out
  if($case.error){if(-not $m.error -or $m.message -notmatch $case.error){throw "Unreadable PDF error: $($case.name) $($m.message)"}}
  else{if($m.error -or -not $m.page_ready -or $m.page_count -ne $case.pages -or $m.content_hash -ne (Get-FileHash $case.path -Algorithm SHA256).Hash){throw "PDF content/hash/count mismatch: $($case.name)"}}
  if(@(Get-ProjectProcesses).Count){throw 'PDF child survived smoke parent exit'}
  Save-Step ("smoke-"+$case.name) $m
 }
 if(-not $SkipExplorer) {
  $fixture="$repo\artifacts\pdf-gui-fixtures";New-Item -ItemType Directory -Force $fixture | Out-Null
  Copy-Item "$repo\samples\pdf\01-pages.pdf","$repo\samples\pdf\02-other.pdf" $fixture -Force
  [IO.File]::WriteAllText("$fixture\03-final.txt",'LATEST TEXT MUST REMAIN')
  Remove-Item $report -ErrorAction SilentlyContinue
  $process=Start-Process "$repo\new-quicklook.exe" -ArgumentList @('--trace',('"'+$report+'"')) -PassThru
  Start-Process explorer.exe -ArgumentList ('/n,"'+$fixture+'"') | Out-Null
  for($i=0;$i -lt 80;$i++){Start-Sleep -Milliseconds 100;$explorer=@($shell.Windows()|Where-Object {$baseline -notcontains $_.HWND -and $_.Document.Folder.Self.Path -eq $fixture})|Select-Object -First 1;if($explorer -and (Get-PreviewHandle) -ne [IntPtr]::Zero){break}}
  if(-not $explorer){throw 'Owned PDF Explorer window not found'}
  $hwnd=Get-PreviewHandle
  [void][PreviewGui]::ShowWindow([IntPtr]$explorer.HWND,9)
  [void][PreviewGui]::SetWindowPos([IntPtr]$explorer.HWND,[IntPtr]::Zero,60,80,1500,1300,0x14)
  $explorer.Document.CurrentViewMode=4;Start-Sleep -Milliseconds 350
  Click-ExplorerFile $explorer '01-pages.pdf';[PreviewGui]::Key(32)
  $first=Read-Page '01-pages.pdf' 0
  if([PreviewGui]::GetForegroundWindow() -ne [IntPtr]$explorer.HWND){throw 'PDF opening stole Explorer focus'}
  $geometry=Get-TestRect $hwnd|ConvertTo-Json -Compress;$hash=$first.content_hash
  Save-Step 'explorer-space-first-page' $first
  & "$PSScriptRoot\capture-window.ps1" -WindowHandle $hwnd.ToInt32() -Path "$repo\artifacts\$Label-page-1.png" | Out-Null
  $workers=@(Get-ProjectProcesses|Where-Object ParentProcessId -eq $process.Id|Where-Object Name -eq 'pdf-worker.exe');if($workers.Count -ne 1){throw 'Expected one lazy PDF worker'};$workerPid=$workers[0].ProcessId
  Wheel -120;$second=Read-Page '01-pages.pdf' 1 $first.generation;Assert-Geometry
  if($second.content_hash -ne $hash -or $second.page_image_hash -eq $first.page_image_hash){throw 'Page turn changed file hash or reused the old page'}
  Save-Step 'wheel-second-page' $second
  & "$PSScriptRoot\capture-window.ps1" -WindowHandle $hwnd.ToInt32() -Path "$repo\artifacts\$Label-page-2.png" | Out-Null
  Wheel -120;$third=Read-Page '01-pages.pdf' 2 $second.generation;Assert-Geometry;Save-Step 'wheel-rotated-third-page' $third
  & "$PSScriptRoot\capture-window.ps1" -WindowHandle $hwnd.ToInt32() -Path "$repo\artifacts\$Label-page-3.png" | Out-Null
  Wheel -120;Start-Sleep -Milliseconds 200;$bound=Read-Page '01-pages.pdf' 2
  if($bound.generation -ne $third.generation){throw 'Last-page bound created a new request'};Save-Step 'last-page-clamp' $bound
  Wheel 120;$back=Read-Page '01-pages.pdf' 1 $third.generation
  if($back.page_image_hash -ne $second.page_image_hash){throw 'Backward page content differs'};Save-Step 'wheel-back-cache' $back
  Wheel 120 -Control;Start-Sleep -Milliseconds 150;$zoom=Read-Page '01-pages.pdf' 1
  if($zoom.zoom -le 1 -or $zoom.generation -ne $back.generation){throw 'Ctrl wheel did not zoom the existing page'};Save-Step 'ctrl-wheel-zoom' $zoom
  Focus-TestWindow ([IntPtr]$explorer.HWND);[PreviewGui]::Key(40)
  $other=Read-Page '02-other.pdf' 0 $back.generation;Assert-Geometry
  $reused=@(Get-ProjectProcesses|Where-Object ParentProcessId -eq $process.Id|Where-Object Name -eq 'pdf-worker.exe')
  if($reused.Count -ne 1 -or $reused[0].ProcessId -ne $workerPid){throw 'PDF worker was not reused across files'};Save-Step 'arrow-other-pdf-reuses-worker' $other
  Wheel -120;[PreviewGui]::Key(40)
  $text=Read-PreviewReport $report {param($m) $m.file_name -eq '03-final.txt' -and $m.kind -eq 'text' -and $m.generation -gt $other.generation -and -not $m.error -and $null -ne $m.first_content_paint_ms}
  Start-Sleep -Milliseconds 300;$still=Read-PreviewReport $report
  if($still.file_name -ne '03-final.txt' -or $still.content_hash -ne $text.content_hash -or @(Get-ProjectProcesses|Where-Object Name -eq 'pdf-worker.exe').Count){throw 'Late PDF result or worker survived switching to text'};Save-Step 'rapid-page-then-file-cancellation' $still
  [PreviewGui]::Key(38);$reopen=Read-Page '02-other.pdf' 0 $still.generation
  $live=@(Get-ProjectProcesses|Where-Object ParentProcessId -eq $process.Id|Where-Object Name -eq 'pdf-worker.exe');Stop-Process -Id $live[0].ProcessId -Force
  Wheel -120
  $crash=Read-PreviewReport $report {param($m) $m.error -and $m.generation -gt $reopen.generation} 14000
  if([string]::IsNullOrWhiteSpace($crash.message)){throw 'PDF worker crash had no readable error'};Save-Step 'worker-crash-readable-error' $crash
  [PreviewGui]::Key(38);$recovered=Read-Page '01-pages.pdf' 0 $crash.generation;Save-Step 'next-file-recovers' $recovered
  Start-Sleep -Seconds 32
  if(@(Get-ProjectProcesses|Where-Object ParentProcessId -eq $process.Id|Where-Object Name -eq 'pdf-worker.exe').Count){throw 'Idle PDF worker did not exit'};Save-Step 'idle-worker-exit' $recovered
  Wheel -120;$idle=Read-Page '01-pages.pdf' 1 $recovered.generation;Save-Step 'page-after-idle-reopens' $idle
  [PreviewGui]::Key(32)
  for($i=0;$i -lt 80 -and [PreviewGui]::IsWindowVisible($hwnd);$i++){Start-Sleep -Milliseconds 25}
  if([PreviewGui]::IsWindowVisible($hwnd)){throw 'First Space did not close PDF preview'}
  Start-Sleep -Milliseconds 200;if(@(Get-ProjectProcesses|Where-Object Name -eq 'pdf-worker.exe').Count){throw 'Close retained the PDF worker'};Save-Step 'space-close-releases-worker' $idle
  [PreviewGui]::Key(32);$last=Read-Page '01-pages.pdf' 0 $idle.generation
  $child=@(Get-ProjectProcesses|Where-Object ParentProcessId -eq $process.Id|Where-Object Name -eq 'pdf-worker.exe')[0].ProcessId
  Stop-Process -Id $process.Id -Force;$process.WaitForExit();Start-Sleep -Milliseconds 200
  if(Get-Process -Id $child -ErrorAction SilentlyContinue){throw 'PDF worker survived abrupt parent exit'};Save-Step 'job-kills-worker-on-parent-exit' $last
 }
 $success=$true
} catch {$failure=$_.Exception.Message;throw}
finally {
 if($process -and -not $process.HasExited){$null=$process.CloseMainWindow();if(-not $process.WaitForExit(5000)){$process.Kill()}}
 Close-TestExplorer $explorer $baseline
 $after=@($shell.Windows()|ForEach-Object {[pscustomobject]@{hwnd=$_.HWND;url=$_.LocationURL}})
 [pscustomobject]@{success=$success;failure=$failure;exe_sha256=(Get-FileHash "$repo\new-quicklook.exe" -Algorithm SHA256).Hash;before=$before;after=$after;steps=@($results.ToArray())}|ConvertTo-Json -Depth 10|Set-Content "artifacts\$Label-results.json" -Encoding UTF8
}
