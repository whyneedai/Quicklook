﻿param([int]$Rounds=4,[string]$Label='tabs',[string]$Executable='')
$repo = Split-Path $PSScriptRoot -Parent
. "$PSScriptRoot\process-args.ps1"
$repoUri = ([Uri]($repo+'\')).AbsoluteUri.TrimEnd('/')
if(-not $Executable){$Executable="$repo\new-quicklook.exe"}

$ErrorActionPreference='Stop'
Set-Location $repo
. "$PSScriptRoot\gui-test.ps1"
$env:TEMP="$repo\.cache\tmp"; $env:TMP=$env:TEMP
New-Item -ItemType Directory -Force $env:TEMP | Out-Null
Add-Type @'
using System;
using System.Runtime.InteropServices;
using System.Text;
public static class QlTest {
 [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
 [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint a,uint b,bool attach);
 [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
 [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h,int mode);
 public static bool Focus(IntPtr h) {
   uint current=GetCurrentThreadId(), foreground=GetWindowThreadProcessId(GetForegroundWindow(),IntPtr.Zero);
   bool attached=current!=foreground && AttachThreadInput(current,foreground,true);
   try {ShowWindow(h,9);return SetForegroundWindow(h);} finally {if(attached)AttachThreadInput(current,foreground,false);}
 }

 [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
 [DllImport("user32.dll")] public static extern IntPtr GetClipboardOwner();
 [DllImport("user32.dll")] public static extern uint GetDpiForWindow(IntPtr h);
 [DllImport("user32.dll")] public static extern IntPtr SetThreadDpiAwarenessContext(IntPtr context);
 [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h,IntPtr after,int x,int y,int w,int height,uint flags);
 public static void Ctrl(byte key){keybd_event(17,0,0,UIntPtr.Zero);Key(key);keybd_event(17,0,2,UIntPtr.Zero);}
 public static void MouseMessage(IntPtr h,uint message,int x,int y,int buttons){PostMessage(h,message,(IntPtr)buttons,(IntPtr)((y<<16)|(x&65535)));}

 [DllImport("user32.dll")] public static extern IntPtr FindWindow(string c,string n);
 [DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr h,out RECT r);
 [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
 [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr h,uint m,IntPtr w,IntPtr l);
 [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr h,int n);
 [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h,IntPtr p);
 [DllImport("user32.dll")] public static extern bool GetGUIThreadInfo(uint id,ref GUI info);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] public static extern int GetClassName(IntPtr h,StringBuilder text,int size);
 [DllImport("user32.dll")] public static extern void keybd_event(byte key,byte scan,uint flags,UIntPtr extra);
 [StructLayout(LayoutKind.Sequential)] public struct RECT {public int l,t,r,b;}
 [StructLayout(LayoutKind.Sequential)] public struct GUI {public int size,flags;public IntPtr active,focus,capture,menu,movesize,caret;public RECT rect;}
 public static string FocusClass(IntPtr h) {var g=new GUI();g.size=Marshal.SizeOf(g);GetGUIThreadInfo(GetWindowThreadProcessId(h,IntPtr.Zero),ref g);var s=new StringBuilder(128);GetClassName(g.focus,s,128);return s.ToString();}
 public static void Key(byte key) {keybd_event(key,0,0,UIntPtr.Zero);System.Threading.Thread.Sleep(25);keybd_event(key,0,2,UIntPtr.Zero);}
}
'@
[void][QlTest]::SetThreadDpiAwarenessContext([IntPtr](-4))
function Focus-Explorer([IntPtr]$handle) {
 if ([QlTest]::GetForegroundWindow() -ne $handle) {
  [void][QlTest]::Focus($handle)
  if ([QlTest]::GetForegroundWindow() -ne $handle) {
   [QlTest]::keybd_event(18,0,0,[UIntPtr]::Zero);[QlTest]::keybd_event(18,0,2,[UIntPtr]::Zero)
   [void][QlTest]::Focus($handle)
  }
 }
 for($focusRetry=0;$focusRetry -lt 20 -and [QlTest]::GetForegroundWindow() -ne $handle;$focusRetry++) {
  Start-Sleep -Milliseconds 50
  [QlTest]::keybd_event(18,0,0,[UIntPtr]::Zero);[QlTest]::keybd_event(18,0,2,[UIntPtr]::Zero)
  [void][QlTest]::Focus($handle)
 }
 if ([QlTest]::GetForegroundWindow() -ne $handle) {throw "Cannot obtain Explorer foreground wanted=$handle actual=$([QlTest]::GetForegroundWindow())"}
 # Close menus left by a foreground unlock; never send Alt when Explorer is already active.
 [QlTest]::Key(27)
}


Add-Type -AssemblyName System.Windows.Forms
$shell=New-Object -ComObject Shell.Application
$before=@($shell.Windows()|ForEach-Object {$_.HWND})
$explorer=$null;$process=$null;$results=@()
try {
 . "$PSScriptRoot\image-fixtures.ps1"
 $imageFolder=New-TestImageFixtures
 $imageUri=([Uri]($imageFolder+'\')).AbsoluteUri.TrimEnd('/')
 Start-Process explorer.exe -ArgumentList ('/n,"'+$repo+'\samples"')
 for($i=0;$i -lt 80;$i++) {
  Start-Sleep -Milliseconds 100
  $explorer=@($shell.Windows()|Where-Object {$_.LocationURL -eq "$repoUri/samples" -and $before -notcontains $_.HWND})|Select-Object -First 1
  if($explorer){break}
 }
 if(-not $explorer){throw 'New isolated Explorer window unavailable'}
 $owner=[IntPtr]$explorer.HWND
 Focus-Explorer $owner
 [QlTest]::Ctrl(84)
 for($i=0;$i -lt 80;$i++) {
  Start-Sleep -Milliseconds 100
  $tabs=@($shell.Windows()|Where-Object {$_.HWND -eq $owner.ToInt64()})
  if($tabs.Count -eq 2){break}
 }
 $newTab=$tabs|Where-Object {$_.LocationURL -ne "$repoUri/samples"}|Select-Object -First 1
 if(-not $newTab){throw 'New tab missing'}
 $newTab.Navigate2($imageFolder)
 for($i=0;$i -lt 80;$i++) {
  Start-Sleep -Milliseconds 100
  if($newTab.LocationURL -eq $imageUri){break}
 }
 if($newTab.LocationURL -ne $imageUri){throw 'Issue tab missing'}
 $tabs|ForEach-Object {Write-Output "tab $($_.LocationURL) HWND=$($_.HWND)"}
 # Leave a different selected image in the inactive tab, matching the stale-image report.
 $sampleTab=$tabs|Where-Object {$_.LocationURL -eq "$repoUri/samples"}|Select-Object -First 1
 $sampleTab.Document.SelectItem($sampleTab.Document.Folder.ParseName('gradient.png'),5)
 for($round=0;$round -lt $Rounds;$round++) {
  $report="$repo\artifacts\tabs-current.json"
  $process=Start-Process $Executable -ArgumentList (Join-ProcessArguments @('--trace',$report)) -PassThru
  Start-Sleep -Milliseconds 300
  $hwnd=[QlTest]::FindWindow('NewQuickLook.Native.Window','new-quicklook')
  for($step=0;$step -lt 6;$step++) {
   $tabFolder=if($step%2 -eq 0){$imageFolder}else{Join-Path $repo 'samples'}
   $name=if($step%2 -eq 0){'1.png'}else{'hello.py'}
   if($step -gt 0){Focus-Explorer $owner;[QlTest]::Ctrl(9);Start-Sleep -Milliseconds 150}
   $tab=@($shell.Windows()|Where-Object {$_.HWND -eq $owner.ToInt64() -and $_.Document.Folder.Self.Path -eq $tabFolder})|Select-Object -First 1
   if(-not $tab){throw "Missing $tabFolder tab"}
   $tab.Document.SelectItem($tab.Document.Folder.ParseName($name),29)
   Focus-Explorer $owner
   Start-Sleep -Milliseconds 100
   if(Test-Path $report){Remove-Item $report}
   [QlTest]::Key(32)
   for($pw=0;$pw -lt 50;$pw++) {
    Start-Sleep -Milliseconds 50
    if(Test-Path $report){break}
   }
   $m=Get-Content $report -Raw|ConvertFrom-Json
   $results+=[pscustomobject]@{round=$round;step=$step;expected=$name;metrics=$m}
   & "$repo\scripts\capture-window.ps1" -WindowHandle $hwnd.ToInt32() -Path "$repo\artifacts\$Label-$round-$step.png"|Out-Null
   if($m.file_name -ne $name -or $m.error){throw "Wrong tab content expected=$name actual=$($m.file_name): $($m.shell_resolution)"}
  }
  [void][QlTest]::PostMessage($hwnd,16,[IntPtr]0,[IntPtr]0)
  if(-not $process.WaitForExit(5000)){throw 'Exit timed out'};$process=$null
  # Last step was samples; restore issue as the first visible tab for the next restart.
  Focus-Explorer $owner;[QlTest]::Ctrl(9);Start-Sleep -Milliseconds 150
 }
 Write-Output "Passed $Rounds process restarts and $($Rounds*6) alternating live tab selections"
} finally {
 $results|ConvertTo-Json -Depth 7|Set-Content "artifacts\restart-$Label-results.json" -Encoding UTF8
 if($process -and -not $process.HasExited){$process.Kill();$process.WaitForExit()}
 Close-TestExplorer $explorer $before
}
