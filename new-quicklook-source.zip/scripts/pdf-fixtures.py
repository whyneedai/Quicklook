"""Deterministic PDF fixtures, including password protection; Python stdlib only."""
from pathlib import Path
import hashlib
import struct

ROOT = Path(__file__).resolve().parents[1]
SAMPLES = ROOT / "samples/pdf"
(ROOT / "artifacts").mkdir(exist_ok=True)
SAMPLES.mkdir(exist_ok=True)


def rc4(key, data):
    s = list(range(256))
    j = 0
    for i in range(256):
        j = (j + s[i] + key[i % len(key)]) % 256
        s[i], s[j] = s[j], s[i]
    i = j = 0
    result = bytearray()
    for byte in data:
        i = (i + 1) % 256
        j = (j + s[i]) % 256
        s[i], s[j] = s[j], s[i]
        result.append(byte ^ s[(s[i] + s[j]) % 256])
    return bytes(result)


def pdf(name, sizes, password=False):
    objects = [b"<< /Type /Catalog /Pages 2 0 R >>", b"", b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"]
    ids = []
    padding = bytes.fromhex("28bf4e5e4e758a4164004e56fffa01082e2e00b6d0683e802f0ca9fe6453697a")
    file_id = hashlib.md5(b"Quicklook deterministic PDF fixtures").digest()
    owner = rc4(hashlib.md5((b"owner" + padding)[:32]).digest()[:5], (b"sleep" + padding)[:32])
    key = hashlib.md5((b"sleep" + padding)[:32] + owner + struct.pack("<i", -4) + file_id).digest()[:5]
    for index, (width, height, rotation) in enumerate(sizes):
        page_id = len(objects) + 1
        ids.append(f"{page_id} 0 R")
        stream_id = page_id + 1
        objects.append(f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {width} {height}] /Rotate {rotation} /Resources << /Font << /F1 3 0 R >> >> /Contents {stream_id} 0 R >>".encode())
        color = [(0.12, 0.30, 0.55), (0.28, 0.46, 0.24), (0.48, 0.28, 0.24)][index % 3]
        content = f"{color[0]} {color[1]} {color[2]} rg 40 40 {width-80} {height-80} re f\n1 1 1 rg BT /F1 28 Tf 70 {height-100} Td (Quicklook PDF - page {index+1}) Tj 0 -50 Td /F1 16 Tf (System renderer, isolated worker, bounded page image.) Tj ET\n".encode()
        if password:
            object_key = hashlib.md5(key + stream_id.to_bytes(3, "little") + b"\0\0").digest()[:10]
            content = rc4(object_key, content)
        objects.append(f"<< /Length {len(content)} >>\nstream\n".encode() + content + b"\nendstream")
    objects[1] = f"<< /Type /Pages /Count {len(ids)} /Kids [{' '.join(ids)}] >>".encode()
    trailer_extra = b""
    if password:
        objects.append(f"<< /Filter /Standard /V 1 /R 2 /Length 40 /O <{owner.hex()}> /U <{rc4(key, padding).hex()}> /P -4 >>".encode())
        trailer_extra = f" /Encrypt {len(objects)} 0 R /ID [<{file_id.hex()}><{file_id.hex()}>]".encode()
    result = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
    offsets = [0]
    for index, obj in enumerate(objects, 1):
        offsets.append(len(result))
        result.extend(f"{index} 0 obj\n".encode() + obj + b"\nendobj\n")
    start = len(result)
    result.extend(f"xref\n0 {len(offsets)}\n0000000000 65535 f \n".encode())
    for offset in offsets[1:]:
        result.extend(f"{offset:010d} 00000 n \n".encode())
    result.extend(f"trailer\n<< /Size {len(offsets)} /Root 1 0 R".encode() + trailer_extra + f" >>\nstartxref\n{start}\n%%EOF\n".encode())
    (SAMPLES / name).write_bytes(result)


pdf("01-pages.pdf", [(600, 800, 0), (800, 600, 0), (600, 800, 90)])
pdf("02-other.pdf", [(500, 500, 0), (600, 800, 0)])
pdf("password.pdf", [(600, 800, 0)], password=True)
(SAMPLES / "broken.pdf").write_bytes(b"%PDF-1.4\nThis is not a PDF object tree.\n")
(SAMPLES / "header.pdf").write_bytes(b"not a PDF")
# Large/count-limit fixtures remain in artifacts rather than inflating samples.
pdf("count-limit.pdf", [(10, 10, 0)] * 10001)
(SAMPLES / "count-limit.pdf").replace(ROOT / "artifacts/pdf-count-limit.pdf")
with (ROOT / "artifacts/pdf-too-large.pdf").open("wb") as stream:
    stream.write(b"%PDF-1.4\n")
    stream.truncate(64 * 1024 * 1024 + 1)
print("Generated bounded local PDF fixtures and adversarial inputs")
