# Markdown 公式实现与验收

交付结构为 `new-quicklook.exe` + `worker/math-worker.exe`。Worker 是 app package 的独立 Rust bin，Windows 自带 Msftedit.dll 只从 System32 加载；不复制系统 DLL，不依赖浏览器、Office 或 .NET。测试中的 PowerShell/C# 故障替身不属于交付物。

## 数据与线程

render/text/md.rs 开启 pulldown-cmark ENABLE_MATH；Span.text 保留原始 LaTeX，Span.math 保存 display 和 Pending/Ready/Fallback。**主进程只做结构性校验**（长度/编码/括号平衡与深度，`core::math::structurally_valid`）：命令兼容性不再由前端预判，是否可排版由 worker 内部路由决定（RichEdit 优先，预处理，未来自研子集），避免“白名单比系统能力更窄”造成的无谓回退（见 MATH-BOUNDARY.md）。代码围栏、行内代码、显式源码模式不触发数学解析。app/native/loader.rs 先发布普通 Markdown 模型，收到 UI 完成 EndPaint 的代次确认后才调用 math_worker::Service。公式晚到时必须再次检查 generation；关闭或切文件会取消等待并丢弃旧结果。

后台线程复用独立 Worker，通过匿名 stdin/stdout 管道以公共 NQW1 版本帧/规格握手包装 NQM1/NQR2 二进制载荷（独立旧探针入口仍兼容），通用进程管理见 WORKERS.md。请求携带 id/generation、显示类型、DPI 和有界 UTF-8；响应携带相同身份、尺寸、基线、DPI、转换/绘制微秒数、**backend（rich/self/fallback 诊断字段）** 和 BGRA。worker 内部用 TOM `GetPoint(TA_TOP/TA_BASELINE/TA_BOTTOM)` 的几何驱动**带状墨迹扫描**（触边/空带自动回退全画布，见 MATH-BOUNDARY.md），并按 `1.0/0.85/0.7/0.55/0.4` 多档字号重试（超高/超宽时自动缩小，全部失败才回退原文），并先用 `core::math::normalize` 预处理 RichEdit 会原样打印的构造（`\dfrac`/`\tfrac`→`\frac`、`\operatorname`→`\mathrm`、`\color` 去色、`bmatrix`/`Bmatrix`/`vmatrix`/`pmatrix`/`cases`→`\left…\begin{matrix}…\end{matrix}\right…`、`aligned`/`array`/`gathered`→`matrix` 近似）。双方在分配像素前验证长度与维度。Worker 不接收文件路径、Shell 命令或网络地址。

Worker 的同一 STA 拥有隐藏 RICHEDIT50W 控件、类型化 ITextDocument2/ITextRange2 和 GDI 离屏表面。SetText2(tomConvertTeX) 构建二维数学；EM_FORMATRANGE 绘制后立即释放格式缓存，GdiFlush 后裁剪背景边界。返回值只用来检查字符是否全部容纳，不能当作像素尺寸。基线来自 TOM GetPoint(TA_BASELINE)，不是简单拿位图底部猜测。触及位图边缘或无法取得尺寸/基线时保留原文。

display/layout.rs 让行内公式与字体实际基线对齐；**Pending 公式不绘制原文**（首帧只显示正文，公式位留空，避免“源码闪现”），只有 Fallback 才显示 LaTeX 原文；独立公式单独居中，窄窗口按比例缩小。Ready 更新使布局失效但保留滚动和文字选择。公式按完整原子区域选择，复制仍得到原 LaTeX。96/144/192 DPI Worker 输出已测，窗口实际截图为宿主 200% DPI；跨屏动态 DPI 组合仍需补验。

## 限额与兼容

- 单条输入 2 KiB、结构深度 16、一页最多排版 64 条；Markdown 仍限制 256 KiB。
- 单位图最多 2048×512，页内最终位图 8 MiB，LRU 另限 8 MiB；二者通过 Arc 共享命中的像素。固定字体/颜色/后端版本隐含于当前进程，缓存键包含 LaTeX、display、DPI。
- Job Object 限单进程、128 MiB，KILL_ON_JOB_CLOSE 保证父进程关闭时回收；不使用受限令牌或 AppContainer，**不是完整安全沙箱**。
- 单次响应等待 1 秒；取消、超时或畸形协议会终止该 Worker 并回收管道线程。本页遇到 Worker 故障后不逐条重试，剩余公式直接回退；下一次文档请求可重启。
- 首次遇公式才启动；连续预览复用；空闲 30 秒结束进程并清缓存。关闭当前文档立即释放文档模型，8 MiB LRU 可保留至空闲回收。
- 路由后覆盖率：分式/根式/上下标/积分/求和、矩阵（pmatrix/matrix）、字母样式（mathbb/mathcal/mathfrak）、binom/cfrac/sqrt[n]/over-underbrace/substack/stackrel/limits/displaystyle/boldsymbol、重音族、白名单外希腊字母、大量符号与 `\text` 内中文均实测可排版；`bmatrix`/`cases`/`aligned`/`array`/`operatorname`/`color`/`dfrac`/`tfrac` 经预处理后也可排版（应用级样例 6/6 rich、fallback=0）。**未知命令仍会原样排版为文字**，超宽表达式（>2048px）仍会被画布裁切——这两类留给自研子集/排版策略。RichEdit 并非完整 TeX，实现不把 S_OK 当成语义正确性的证明。

## 对照 mathworker.md 第八节

| 顺序 | 交付与验证 |
|---|---|
| 1 独立 EXE | app/src/bin/math-worker.rs；惰性启动与退出由 math-lifecycle.ps1 验证 |
| 2 RichEdit | 类型化 TOM2；40 条基础语料分别在三个 DPI 渲染 |
| 3 离屏位图 | 真实窗口 math-window.png 与 math-probe.png；分式/根式/积分/求和目视复核 |
| 4 有界 IPC | core/math.rs 单测/属性测试；math-failures.ps1 畸形响应回归 |
| 5 Markdown 扩展 | engine 集成测试验证 Inline/Display、代码排除与 Source 排除 |
| 6 Document | 行内基线、独立居中、选择保留、原 LaTeX 复制；实际窗口验证 |
| 7 尺寸与 DPI | 120 次尺寸/基线检查，边界裁切拒绝；多屏组合不冒充已验证 |
| 8 限额/缓存 | 14 组拒绝输入、24 次复用的内存/GDI 观测、页数/深度/位图限额 |
| 9 生命周期 | 惰性/复用/异常回退与重启/30 秒空闲/父进程退出；专项脚本 |
| 10 Release | check.cmd + Explorer 首帧；普通内容与完整公式更新时间分别记录 |

指导文档提到的旧 40 条/14 组原始语料文件没有出现在项目中。本轮将实际使用的 40 条语料固定在 samples/math-corpus.json，14 组拒绝输入固定在 scripts/math-corpus.py；不把本轮结果冒充旧 PowerShell 探针的原样复测。

## 复验与解释

- `scripts/check.cmd`：Windows Rust 单元/集成/属性测试、Clippy、构建与两个工件复制。
- WSL `python3 scripts/math-corpus.py`：直接启动真正 Windows math-worker.exe，120 次渲染与 14 组拒绝输入；WSL 只负责传输和汇总。
- Windows `scripts/math-window.ps1`：仅捕获项目预览窗口。
- Windows `scripts/math-lifecycle.ps1`：进程复用、资源、异常重启与退出。
- Windows `scripts/math-failures.ps1`：缺失 Worker、卡住 Worker、畸形响应、原文回退及子进程回收。测试替身仅在 artifacts/math-fault-*。
- Windows `scripts/stale-math.ps1`：公式 Pending 时切文件，核对新正文哈希保持正确。

`first_content_paint_ms` 是普通内容到 GDI EndPaint；`math_paint_ms` 是本次预览起点到全部公式就绪/回退后的首次 EndPaint。协议的 convert_us/draw_us 仅为子进程内部 API 时间。Python round-trip 包含协议、排版、扫描裁剪、传输和调度；减去 API 时间也不能称作纯 IPC 时间。冷请求单独报告，不与热样本混算。

参考：[Microsoft TOM2](https://learn.microsoft.com/en-us/windows/win32/controls/about-text-object-model)、[GetPoint 基线标志](https://learn.microsoft.com/en-us/windows/win32/api/tom/nf-tom-itextrange-getpoint)、[EM_FORMATRANGE 缓存释放](https://learn.microsoft.com/en-us/windows/win32/controls/em-formatrange)、[RichEdit 文本格式转换](https://devblogs.microsoft.com/math-in-office/setting-and-getting-text-in-various-formats/)。
