# PDF 预览

在 Explorer 选中 PDF 后按 Space。PDF 默认显示第一页；在预览内滚动鼠标滚轮翻页，Ctrl+滚轮缩放当前页，放大后左键拖动平移、双击复位。页码和翻页提示常显于页脚。方向键仍切换 Explorer 文件；Space/Esc 无需点击即可关闭。暂不提供文字选择、复制或搜索，也不执行脚本、打开附件或访问外部链接。

PDF 是 pages/pdf.rs 注册的独立 FormatPreview，魔数 `%PDF-` 优先、`.pdf` 扩展名备用，只提供 Rendered。组件返回公共 Pages 能力和 worker 规格；app 的通用 page_worker 处理该能力，display 通过公共 Image 画布绘制，前端不按文件后缀分派。五 crate 与零依赖 core 边界保持不变。

解析与栅格化只在 `worker/pdf-worker.exe` 中调用 Windows 系统 [Windows.Data.Pdf](https://learn.microsoft.com/en-us/uwp/api/windows.data.pdf.pdfdocument)。输入为主程序已打开、有界读取的文件字节，不向 worker 发送路径或命令。worker 用内存流加载文件、按请求获取一页，使用系统 PNG 编码器输出，并检查实际像素尺寸；系统按 DIP 放大时在 worker 内再经 WIC 缩到请求尺寸；主程序经 engine 的既有图片组件和 WIC 解码，再以 GDI 显示。没有 pdfium.dll、新第三方依赖、浏览器内核或运行时下载。

资源限制：输入 64 MiB，页数 10000，协议页图最大边 2048/最多 400 万像素/编码后 16 MiB；当前 UI 请求与解码画布至多 1600×1200，当前文档的页图 LRU 为 16 MiB。每次打开或渲染请求 5s，空闲 30s 后退出，Job 限 256 MiB/单子进程，父进程退出结束 worker。主程序在解码之前校验实际 PNG IHDR 与响应尺寸一致，防止错误元数据扩大 WIC 源分配。通用握手和故障规则见 [WORKERS](WORKERS.md)。这些是资源和失败隔离，不是 AppContainer 或权限沙箱。系统 PDF 内部临时栅格不冒称受最终画布限额约束；WIC 变换前另拒绝超过 1600 万像素的系统位图，整个进程仍受 Job 内存/请求时限约束。系统字体/版本可能影响页面外观。

只保留当前文档的页缓存；文件切换替换文档，切到非分页内容/关闭释放缓存并结束 PDF worker。空闲结束后下一次翻页重新有界读取当前文件并打开请求页。取消、超时、协议错误、密码保护、损坏或超限输入均显示错误；下一文件可重新启动。第一页和翻页的诊断首帧只在实际页图绘出后记录，不把 Loading 当作 PDF 内容。`--smoke` 等待后台最多 12s，以覆盖启动握手与请求时限，仍未就绪则报错。

复验：先 `scripts\check.cmd`，再 `python scripts/pdf-fixtures.py`、`powershell -NoProfile -ExecutionPolicy Bypass -File scripts\pdf-preview.ps1`（默认含真实 Explorer/键鼠）和 `scripts\pdf-failures.ps1`。测试文件由 Python 标准库生成；密码夹具仅用于错误验收。证据位于本地 artifacts/pdf-*，不随公开源码提交。新获取源码可直接运行 check，系统 PDF 进程测试使用入库的小夹具；不需要 Python 或第三方 PDF 引擎完成构建。

WSL 复验可运行 `scripts\pdf-wsl-preview.ps1`，默认使用当前 WSL 发行版，可传 `-Distribution`。脚本只在 Linux /tmp/new-quicklook-preview-pdf-* 下生成隔离夹具，再对两种 UNC 的输入摘要与 Linux sha256sum 对拍；不修改发行版设置。

当前实测性能边界：同机已有缓存的三页样例，真实 Explorer Space→实际页图 EndPaint 首次 393ms，未缓存翻页 209–215ms，页图缓存命中 28ms。PDF 首次打开未达到常用格式 p95 <100ms 的质量目标；这是单次样例而非 p95 认证，不外推复杂 PDF 或冷启动。
