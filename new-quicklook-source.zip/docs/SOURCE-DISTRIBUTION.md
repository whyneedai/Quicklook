# 源码分发准备

公开源码只需要根 Cargo.toml/Cargo.lock、.cargo/config.toml、crates、scripts、samples、图标资源、worker/manifest.json 与用户文档。构建不读取内部 AGENTS/NEXT/交接记录，也不依赖预先复制的 exe。满足 README 中 Windows MSVC、Rust 和 SDK 前置条件后，在任意目录运行 scripts\check.cmd；支持含空格的目录。首次构建下载 Cargo.lock 固定的已有依赖，所有项目缓存和输出均在当前 checkout 内。

构建脚本根据自身位置获取仓库根，通过 USERPROFILE/PATH 找 Rust，通过 vswhere 找 MSVC；QL_VCVARS 可覆盖特殊安装。图标资源通过 CARGO_MANIFEST_DIR/OUT_DIR 定位。运行时 worker 相对主程序查找；测试夹具相对脚本定位。WSL 验证默认使用当前发行版，从实际 checkout 读取脚本，不绑定磁盘、用户目录或发行版名。协议、资源上限和模拟路径测试中的常量不属于机器配置。

旧提交可能包含已删除的日志、截图、个人路径或作者元数据，仅删除当前工作树文件不能从 Git 历史中移除它们。为保留原工作仓库又不携带旧历史，可在提交并验证代码后运行：

```powershell
python scripts/prepare-github.py
```

脚本只导出 HEAD 入库文件，在本地 artifacts/GitHub Ready 下准备源码 ZIP 和新的 Git 仓库；新仓库只有一个中性身份初始提交，无 remote，不执行上传，不修改原历史或全局 Git 配置。输出目录已存在时拒绝覆盖，可用 --output 选择新目录。上传时使用这个新仓库或 ZIP，不把原仓库的 .git、artifacts、缓存、构建输出或内部记录一并上传。

公开前检查源码、样例元数据和依赖清单；在新目录完整运行 check.cmd、smoke 与真实 Explorer 回归。自动扫描只能发现指定模式，不替代人工复核；许可证由所有者另行决定，脚本不会替所有者选许可证或创建 GitHub 仓库。
