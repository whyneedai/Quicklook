# Worker 进程契约

公共帧位于 core/worker.rs，客户端位于 app/native/worker.rs。生产规格来自 app/worker_specs.rs；`new-quicklook.exe --worker-specs <json>` 导出同一份清单供交付脚本使用。清单不是动态插件配置，不加载未知可执行文件。

NQW1 头长 28 字节：magic(4)、version(u16)、message(u16)、id(u64)、generation(u64)、payload_bytes(u32)，小端序。Hello/Welcome 的载荷为规格 id(u16)，握手必须完全匹配。未知版本/消息类型、超长/截断载荷、错误 id/代次均失败；先验证长度再分配。Request/Response 的格式载荷由各服务继续校验。主程序不发送文件路径或命令。

客户端在后台线程按需拉起、串行复用。Job 在任何请求（包括 Hello）之前绑定，限制进程数 1、规格内存上限，并在父进程退出时结束子进程。读写各有一条有界通道和线程；请求超时同时覆盖管道写入和响应等待。取消、超时、管道/协议故障均杀进程、wait、回收两条线程；下一请求重新握手。空闲退出由服务调用 expire，缓存预算归服务维护。Job 不是受限令牌或 AppContainer，不能称为完整权限沙箱。

公式规格不变：128 MiB Job / 单请求 1000ms / 空闲 30s / 8 MiB LRU。RichEdit 后端、正文首帧握手、64 公式上限和回退行为不变。math-worker 支持新的 NQW1 包装与旧 NQM1/NQR2 探针入口；新应用只用前者，旧语料脚本无需改协议。

`check.cmd` 的 worker-tests 特性只在测试/Clippy 开启；worker-probe 是第二规格（id 42）的故障测试程序，不进入交付清单或 release 默认构建。worker-runtime 测试证明复用、不同限额、空闲回收、崩溃恢复、错误握手/响应、超时/取消，以及接收方停止读管道时大请求仍可回收。公式端到端回归继续用 math-corpus.py、math-probe.py、math-failures.ps1、math-lifecycle.ps1 和 stale-math.ps1。

交付按清单复制、核对所有 worker；停止脚本只操作项目完整路径内的清单成员及主程序。新格式仍按五 crate 的公共模型/组件能力接入，不允许前端按扩展名 dispatch。
