# 支持格式与边界

文本组件累计 **58**（md/py/rs + 55 个独立扩展名组件）、图片组件 **10**，另有 PDF 分页组件 1 个，共 **69** 个注册组件。PNG 自本轮起改为 WIC 优先 + 大图扫描行混合（见下）。

新增扩展名：

`txt, log, ini, cfg, conf, properties, json, xml, csv, tsv, toml, yaml, yml, js, ts, jsx, tsx, go, java, c, h, cpp, hpp, sh, bash, css, html, php, lua, sql, kt, swift, r, ps1, psm1, psd1, cmd, bat, rb, cs, mjs, cjs, scss, less, zsh, htm, svg, proto, tf, diff, srt, vtt, tex, sty, bib`

| 家族 | 扩展名 | 当前预览 |
|---|---|---|
| 普通文本与日志 | txt, log | 原始文本+行号；日志级别关键词着色 |
| 配置 | ini, cfg, conf, properties, toml, yaml, yml | 源码+行号；基本键名、值、注释着色 |
| 结构化文本 | json, xml, svg | 原始源码+行号；基础着色；无格式化或树布局（SVG 只当 XML 源码看，不栅格化） |
| 分隔数据 | csv, tsv | 默认列对齐；M 切换源码；支持引号转义/字段内换行 |
| Web | js, ts, mjs, cjs, jsx, tsx, css, scss, less, html, htm, php | 源码+行号+基本词法高亮；不运行脚本或渲染网页 |
| PowerShell | ps1, psm1, psd1 | 源码+行号；大小写不敏感关键字、`#` 行注释、`<# #>` 块注释、引号/数字着色 |
| 批处理 | cmd, bat | 源码+行号；命令关键字、`::` 注释、双引号/数字着色 |
| 其他代码 | go, java, c, h, cpp, hpp, sh, bash, zsh, lua, sql, kt, swift, r, rb, cs, proto, tf | 源码+行号+基本关键词/注释/字符串/数字高亮 |
| 补丁与字幕 | diff, srt, vtt | 源码+行号；字幕时间轴/序号用数字色，diff 保持原文（不做 +/- 着色） |
| LaTeX | tex, sty, bib | **只做源码预览，绝不编译/渲染 PDF**；`%` 注释、`\命令` 与 `$` 数学定界符着色、行号；BibTeX 条目类型着色 |

`crates/render/src/text/<扩展名>.rs` 各自定义 FormatPreview、唯一 id、单个扩展名及本地 RULES。即使 yaml/yml、sh/bash、c/h 等相似，也分别保留文件与注册入口。`text/common.rs` 仅提供共享工具；以后再按真实规则相似度评估合并。

CSV/TSV 默认 Rendered，支持切换 Source；其他新增组件只提供 Source 模式。最多读取 256 KiB，最多 6000 行、每行 2000 字符；截断在窗口提示。支持 UTF-8/BOM，无效 UTF-8 替换显示；不自动检测 GBK/UTF-16（含 NUL 的探测输入会拒绝）。扩展名大小写无关，魔数优先规则不变。

高亮是轻量词法规则，不是完整语言解析器：不保证 JSX 嵌套语法、模板插值、正则字面量、heredoc、所有 raw/triple string、YAML 块字符串、Lua 等号长括号、嵌套注释、PHP/HTML 混合语法的精确着色；源文本本身保留。不会解析外部实体、加载网络资源或执行任何文件。CSV/TSV 表格最多 1000 行/32 列/每格 256 字符；短行保留空缺，超限明确提示，畸形引号显示源码与解释。配置语法存在多种方言，注释规则按组件声明的简单常用形式。

新增组件的回归测试见 engine/tests/contracts.rs、render/src/text/common.rs；engine 现有属性测试会遍历所有注册组件。Windows 端执行 `scripts/source-formats.ps1` 可逐个打开 `samples/formats/example.<ext>` 并验证实际首帧、格式 id、所声明的默认模式与行号策略。

## 图片组件

`crates/render/src/image/` 中 png.rs、jpeg.rs（jpg/jpeg/jfif）、gif.rs、webp.rs、bmp.rs、ico.rs、tiff.rs（tif/tiff）、dds.rs、cur.rs、heic.rs（heic/heif/avif）独立注册；**common.rs 同时承载共享限额/画布工具与 WIC codec**（原 wic.rs 已并入，`#[cfg(windows)]` 边界保留）。PNG/JPEG/BMP/ICO/TIFF/DDS/CUR/HEIF 默认走显式系统 WIC codec（PNG 非交错且 >200 万像素时改用有界扫描行，WIC 失败时回退扫描行）（不枚举第三方 codec），其中 CUR 复用 WIC ICO 解码器；DDS 实测只接受 DXT/BC 压缩系（自造的未压缩 legacy/DX10 头被 WIC 拒绝）；HEIC/HEIF/AVIF 依赖系统 HEIF/AV1 扩展，缺失时给出明确错误。系统内部临时缓冲不可视作应用硬限额。PNG 由 WIC 支持 Adam7 交错与调色板/灰度/16bit；扫描行实现仅服务大图并保留为回退；APNG 仅首帧。GIF 按扫描行缩放并处理透明、偏移、交错和帧处置；WebP 支持 alpha 与动画，使用 image-webp，依用户批准限制为 400 万源像素、64 MiB 解码预算，缩小后释放原图。WebP 通过扩展名注册，避免泛 RIFF 魔数误判 AVI/WAV。

图片输入最多 32 MiB，最终静态画布最多 1600×1200，GIF 最多 800×600；动画最多 300 帧、64 MiB 最终帧缓存、累计 100M 源像素，超过时明确报错。WebP 解码库 scratch 限额不是进程硬限制。JPEG EXIF 旋转、ICC 管理和动画暂停/逐帧控制尚未实现。所有图片支持窗口适配、滚轮缩放、拖拽平移、双击复位；放大只使用预览像素。

Windows 回归：`scripts/image-formats.ps1`；实现见 crates/render/src/image；运行脚本在本地 artifacts 生成证据。

CSV/TSV 字段内换行显示为字面 `\n`，避免系统等宽字体缺失换行符号；M 源码模式可查看原始换行与引号。

## PDF 分页组件

PDF 默认显示/滚轮翻页、Ctrl+滚轮缩放。系统 Windows.Data.Pdf 仅在独立 worker 调用，不引入 pdfium.dll；64 MiB 输入、10000 页、有界页图与单文档缓存，密码/损坏/超限有可读错误。暂不提供文字选择/搜索；见 [PDF.md](PDF.md)。
