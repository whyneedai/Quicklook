# 源码配色与词法层次

延续现有深色主题，正文背景 `#161921`、代码块背景 `#1D212B`。以灰蓝为基底，用少量淡紫、青灰、暖米色与鼠尾草绿区分角色；提高注释明度，避免暗字难辨。代码不增加加粗、斜体或背景强调，字体、字号、行距、精确 GDI 测量与缓存策略保持原样。

| 公共 Style 角色 | 前景色 | 用途 | 代码背景对比度 |
|---|---|---|---:|
| Keyword | `#B7A8D9` | 控制与声明关键字 | 7.37:1 |
| String | `#A8C59B` | 字符串、字符、跨行字符串 | 8.53:1 |
| Comment | `#8E9AAB` | 注释，弱于可执行内容但仍清晰 | 5.64:1 |
| Number / Constant | `#D2B795` | 数字、布尔/null、常量声明与全大写标识符 | 8.39:1 |
| Type / Tag | `#9DC9C6` | 类型声明、内建类型、大写类型线索、标签 | 8.89:1 |
| Function | `#AFC7E4` | 函数声明、调用、Rust 宏调用 | 9.28:1 |
| Property / Attribute / Key | `#BCC9D8` | 点访问属性、装饰器/属性、配置与 JSON 键 | 9.57:1 |
| Added | `#AAC7A7` | diff 增加行 | 8.77:1 |
| Removed | `#D6AAA9` | diff 删除行 | 7.80:1 |
| Meta | `#A1AFBF` | diff 文件头、index 与 hunk 头 | 7.20:1 |

按 sRGB 相对亮度计算，所有源码角色在两种背景上至少 5.64:1；display::palette 单测约束下限 4.5:1。普通正文仍为 `#D5DEEB`，标题、引用、链接和行内代码沿用原色。Markdown 正文不会把 Reader、read() 或 MAX_SIZE 染成源码角色；带语言标识的围栏通过原注册表复用组件高亮。

core::Style 定义角色，render/text/common.rs 生成，各扩展名薄组件的本地 RULES 决定适用范围；display/palette.rs 只映射角色颜色。Rust/Python/TypeScript 配置自己的内建类型列表；配置、SQL、CSS 关闭通用类型/函数猜测。XML/HTML/SVG 区分标签与属性，JSON 区分引号键和值，diff 文件头优先于增删行。注释、引号及原跨行状态先于角色分析，保留 Unicode、字符串和 Rust 生命周期边界。

这是有界词法线索，不解析 AST、作用域或符号表。大写标识符可能是变量，括号前名称可能是构造器；未知围栏仍为普通文本。不执行代码、不放宽输入/行数/行长限额、不增加第三方依赖。

## 同文件截图

`scripts/highlight-review.ps1 -Phase before|after` 调用实际主程序及 capture-window.ps1，冻结 samples/hello.rs、hello.py、large.py 与 README.md 四份输入。before/after 应分别运行对应版本的程序；输入、截图、摘要、DPI/几何和测量 JSON 全部保存在本地 artifacts/highlight-*，不随公开源码发布。

历史配色验收使用三个相同 samples 和本地 Markdown 契约快照，观察到函数/类型/属性等层次改善，Markdown 正文与布局不变。原截图仍保留在开发工作区；公开脚本使用 README.md，取得源码即可复验，不依赖内部记录。

## 性能口径

同一 Windows 主机、192 DPI、1024×768 DIP（2048×1536 实际像素）、相同 660000-byte samples/large.py，每阶段排除一次热身后取 20 次。每次新进程 --smoke，文件系统热态、默认增量排版、精确 GDI；没有清空工作集或系统缓存。

| 指标（ms） | 改动前中位数 / p95 | 改动后中位数 / p95 |
|---|---:|---:|
| first_content_paint_ms | 20.83 / 22.57 | 22.10 / 24.20 |
| layout_ms | 9.82 / 10.51 | 11.18 / 12.59 |

首帧中位数增加 1.27ms（6.1%），累计布局增加 1.36ms（13.9%）。新增扫描和颜色片段有小幅成本，未出现明显的绝对延迟回退，首帧 p95 仍为 24.20ms；结论只代表本机该样本，没有宣称零开销或所有文件同速。

本方法的 first_content_paint_ms 从启动预览请求计到内容 EndPaint，包含后台读取/解析，不是真实 Space 输入延迟；layout_ms 是到报告时累计布局耗时。原始时序/几何保存在本地 artifacts/highlight-before-results.json、highlight-after-results.json 与 highlight-comparison.json；公开源码不附机器证据。
