use proptest::prelude::*;
use quicklook_core::*;
use quicklook_engine::Engine;
use std::path::Path;
fn input(bytes: &[u8], mode: PreviewMode) -> Input<'_> {
    Input {
        bytes,
        mode,
        viewport: (320, 240),
        truncated: false,
    }
}
#[test]
fn default_registry_is_valid_and_self_describing() {
    let engine = Engine::default();
    let metadata: Vec<_> = engine.formats().collect();
    assert_eq!(metadata.len(), 69);
    assert_eq!(
        engine.detect(Path::new("FILE.PY"), b"def f():").unwrap().id,
        "python"
    );
    assert_eq!(
        engine
            .detect(Path::new("main.rs"), b"fn main() {}")
            .unwrap()
            .id,
        "rust"
    );
    assert_eq!(
        engine
            .detect(Path::new("renamed.py"), b"\x89PNG\r\n\x1a\n")
            .unwrap()
            .id,
        "png"
    );
    assert!(engine.detect(Path::new("binary.md"), b"\0test").is_err());
}
#[test]
fn markdown_is_rendered_without_line_numbers_and_source_is_explicit() {
    let engine = Engine::default();
    let preview = engine
        .preview(
            "markdown",
            input(b"# Hello\n\n**bold**", PreviewMode::Rendered),
        )
        .unwrap();
    let Output::Text(doc) = preview.output else {
        panic!("text expected")
    };
    assert!(!doc.line_numbers);
    assert_eq!(doc.lines[0].heading, 1);
    assert_eq!(doc.lines[0].spans[0].text, "Hello");
    let preview = engine
        .preview("markdown", input(b"# Hello", PreviewMode::Source))
        .unwrap();
    let Output::Text(doc) = preview.output else {
        panic!("text expected")
    };
    assert!(doc.line_numbers);
    assert_eq!(doc.lines[0].spans[0].text, "# Hello");
}
#[test]
fn unsupported_modes_never_execute_and_limits_are_enforced() {
    let engine = Engine::default();
    assert!(matches!(
        engine.preview("python", input(b"print(42)", PreviewMode::Effect)),
        Err(PreviewError::UnsupportedMode)
    ));
    assert!(matches!(
        engine.preview("png", input(&[], PreviewMode::Source)),
        Err(PreviewError::UnsupportedMode)
    ));
    let large = vec![b'x'; TEXT_LIMIT + 1];
    assert!(matches!(
        engine.preview("python", input(&large, PreviewMode::Source)),
        Err(PreviewError::LimitExceeded(_))
    ));
}
#[test]
fn python_pipeline_preserves_lines() {
    let p = Engine::default()
        .preview(
            "python",
            input(b"# hi\ndef f():\n    return 42", PreviewMode::Source),
        )
        .unwrap();
    let Output::Text(d) = p.output else {
        panic!("text")
    };
    assert_eq!(d.lines[2].source, 3);
    assert!(d.line_numbers);
}

fn source_document(id: &str, source: &str) -> Document {
    let Output::Text(doc) = Engine::default()
        .preview(id, input(source.as_bytes(), PreviewMode::Source))
        .unwrap()
        .output
    else {
        panic!("source text expected")
    };
    let actual = doc
        .lines
        .iter()
        .map(|line| {
            line.spans
                .iter()
                .map(|span| span.text.as_str())
                .collect::<String>()
        })
        .collect::<Vec<_>>()
        .join("\n");
    assert_eq!(actual, source);
    doc
}

fn assert_role(line: &Line, token: &str, expected: Style) {
    let text: String = line.spans.iter().map(|span| span.text.as_str()).collect();
    let offset = text.find(token).expect("test token missing");
    let mut end = 0;
    let actual = line
        .spans
        .iter()
        .find(|span| {
            end += span.text.len();
            end > offset
        })
        .unwrap()
        .style;
    assert_eq!(actual, expected, "{token:?} in {text:?}");
}

#[test]
fn rust_roles_preserve_lifetimes_attributes_and_comment_boundaries() {
    let doc = source_document(
        "rust",
        "#[derive(Debug)]\npub struct 数据 { value: u32 }\nstatic mut LIMIT: usize = 4;\nfn read<'a>(item: &'a 数据) { item.value; println!(\"fn LIMIT\"); }\n/* fn read */ // 数据",
    );
    for (line, token, style) in [
        (0, "derive", Style::Attribute),
        (0, "Debug", Style::Attribute),
        (1, "struct", Style::Keyword),
        (1, "数据", Style::Type),
        (1, "u32", Style::Type),
        (2, "LIMIT", Style::Constant),
        (2, "usize", Style::Type),
        (3, "read", Style::Function),
        (3, "value", Style::Property),
        (3, "println", Style::Function),
        (3, "\"fn LIMIT\"", Style::String),
        (4, "fn read", Style::Comment),
    ] {
        assert_role(&doc.lines[line], token, style);
    }
    assert!(
        !doc.lines[3]
            .spans
            .iter()
            .any(|span| span.style == Style::Attribute)
    );
}

#[test]
fn python_roles_keep_strings_and_decorators_separate_from_code() {
    let doc = source_document(
        "python",
        "@cache\nclass Reader:\n    def read(self, count: int):\n        return self.value + MAX_SIZE\ntext = \"def Reader MAX_SIZE\" # read()\nvalue = '''class Reader\nread()'''\n结果 = read(value)",
    );
    for (line, token, style) in [
        (0, "cache", Style::Attribute),
        (1, "Reader", Style::Type),
        (2, "read", Style::Function),
        (2, "int", Style::Type),
        (3, "return", Style::Keyword),
        (3, "value", Style::Property),
        (3, "MAX_SIZE", Style::Constant),
        (4, "def Reader", Style::String),
        (4, "read()", Style::Comment),
        (5, "class Reader", Style::String),
        (6, "read()", Style::String),
        (7, "read", Style::Function),
    ] {
        assert_role(&doc.lines[line], token, style);
    }
}

#[test]
fn keys_tags_and_attributes_follow_each_component_profile() {
    let json = source_document(
        "json",
        "{\"name\": \"中文\", \"enabled\": true, \"count\": 42}",
    );
    for (token, style) in [
        ("\"name\"", Style::Key),
        ("\"中文\"", Style::String),
        ("true", Style::Constant),
        ("42", Style::Number),
    ] {
        assert_role(&json.lines[0], token, style);
    }
    let xml = source_document(
        "xml",
        "<ns:entry data-id=\"中文\">text</ns:entry> <!-- <fake> -->",
    );
    for (token, style) in [
        ("ns:entry", Style::Tag),
        ("data-id", Style::Attribute),
        ("\"中文\"", Style::String),
        ("text", Style::Normal),
        ("fake", Style::Comment),
    ] {
        assert_role(&xml.lines[0], token, style);
    }
    let config = source_document("yaml", "server-name: QUIET\nurl: \"read()\"");
    assert_role(&config.lines[0], "server-name", Style::Key);
    assert_role(&config.lines[0], "QUIET", Style::Normal);
    assert_role(&config.lines[1], "read()", Style::String);
}

#[test]
fn diff_metadata_and_changed_lines_have_distinct_roles() {
    let doc = source_document(
        "diff",
        "diff --git a/x b/x\n--- a/x\n+++ b/x\n@@ -1 +1 @@\n-old 中文\n+new 中文\n unchanged\n\\ No newline at end of file",
    );
    for (line, style) in [
        (0, Style::Meta),
        (1, Style::Meta),
        (2, Style::Meta),
        (3, Style::Meta),
        (4, Style::Removed),
        (5, Style::Added),
        (6, Style::Normal),
        (7, Style::Comment),
    ] {
        assert!(doc.lines[line].spans.iter().all(|span| span.style == style));
    }
}

#[test]
fn markdown_narrative_stays_quiet_and_fences_share_source_roles() {
    let Output::Text(doc) = Engine::default().preview("markdown", input(b"Reader read() MAX_SIZE\n\n```python\ndef read(count: int):\n    return MAX_SIZE\n```", PreviewMode::Rendered)).unwrap().output else { panic!("text expected") };
    assert!(
        doc.lines
            .iter()
            .filter(|line| !line.code)
            .flat_map(|line| &line.spans)
            .all(|span| span.style == Style::Normal)
    );
    let code: Vec<_> = doc.lines.iter().filter(|line| line.code).collect();
    assert_role(code[0], "read", Style::Function);
    assert_role(code[0], "int", Style::Type);
    assert_role(code[1], "MAX_SIZE", Style::Constant);
}
#[test]
fn png_pipeline_preserves_bounded_canvas() {
    let bytes = include_bytes!("../../../samples/gradient.png");
    let e = Engine::default();
    let f = e.detect(Path::new("a.bin"), &bytes[..8]).unwrap();
    let p = e
        .preview(f.id, input(bytes, PreviewMode::Rendered))
        .unwrap();
    let Output::Image(i) = p.output else {
        panic!("image")
    };
    assert_eq!((i.width, i.height), (320, 180));
    assert_eq!(i.bgra.len(), 320 * 180 * 4);
}
struct Extra;
impl FormatPreview for Extra {
    fn info(&self) -> FormatInfo {
        FormatInfo {
            id: "extra",
            display_name: "Extra",
            kind: Kind::Text,
            extensions: &["custom"],
            magic: &[b"EXTRA"],
            modes: &[PreviewMode::Source],
            limits: Limits {
                max_input_bytes: 10,
                allow_truncation: false,
            },
        }
    }
    fn preview(&self, _: &Input<'_>) -> Result<Output, PreviewError> {
        Ok(Output::Text(Document::default()))
    }
}
#[test]
fn adding_a_component_requires_no_core_or_frontend_dispatch_edit() {
    let formats: [&dyn FormatPreview; 1] = [&Extra];
    let engine = Engine::new(&formats).unwrap();
    assert_eq!(
        engine
            .detect(Path::new("anything.custom"), b"hello")
            .unwrap()
            .id,
        "extra"
    );
    assert_eq!(
        engine
            .detect(Path::new("anything.bin"), b"EXTRA")
            .unwrap()
            .id,
        "extra"
    );
    assert!(
        engine
            .preview("extra", input(b"ok", PreviewMode::Source))
            .is_ok()
    );
}
#[test]
fn duplicate_registration_is_rejected() {
    let formats: [&dyn FormatPreview; 2] = [&Extra, &Extra];
    assert!(Engine::new(&formats).is_err());
}
proptest! {
 #![proptest_config(ProptestConfig::with_cases(128))]
 #[test]fn malformed_inputs_never_panic(bytes in proptest::collection::vec(any::<u8>(),0..8192),name in ".{0,80}"){
  let engine=Engine::default();let _=engine.detect(Path::new(&name),&bytes);
  for info in engine.formats(){for mode in info.modes{let _=engine.preview(info.id,input(&bytes,*mode));}}
 }
}

#[test]
fn every_added_extension_has_its_own_source_component() {
    let engine = Engine::default();
    for ext in EXTENSIONS {
        let path = format!("file.{}", ext.to_uppercase());
        let info = engine.detect(Path::new(&path), b"hello").unwrap();
        assert_eq!(info.id, *ext);
        assert_eq!(info.extensions, &[*ext]);
        let preview = engine
            .preview(
                info.id,
                input("hello 中文\nsecond line".as_bytes(), PreviewMode::Source),
            )
            .unwrap();
        let Output::Text(doc) = preview.output else {
            panic!("text expected")
        };
        assert!(doc.line_numbers);
        assert_eq!(doc.lines[1].source, 2);
        assert_eq!(
            doc.lines[0]
                .spans
                .iter()
                .map(|s| s.text.as_str())
                .collect::<String>(),
            "hello 中文"
        );
        assert!(
            engine
                .preview(info.id, input(b"x", PreviewMode::Effect))
                .is_err()
        );
        assert!(engine.detect(Path::new(&path), b"\0binary").is_err());
    }
}
const EXTENSIONS: &[&str] = &[
    "txt",
    "log",
    "ini",
    "cfg",
    "conf",
    "properties",
    "json",
    "xml",
    "csv",
    "tsv",
    "toml",
    "yaml",
    "yml",
    "js",
    "ts",
    "jsx",
    "tsx",
    "go",
    "java",
    "c",
    "h",
    "cpp",
    "hpp",
    "sh",
    "bash",
    "css",
    "html",
    "php",
    "lua",
    "sql",
    "kt",
    "swift",
    "r",
    "ps1",
    "psm1",
    "psd1",
    "cmd",
    "bat",
    "rb",
    "cs",
    "mjs",
    "cjs",
    "scss",
    "less",
    "zsh",
    "htm",
    "svg",
    "proto",
    "tf",
    "diff",
    "srt",
    "vtt",
    "tex",
    "sty",
    "bib",
];
#[test]
fn new_sources_enforce_line_and_byte_limits_and_keep_markup_inert() {
    let engine = Engine::default();
    for ext in EXTENSIONS {
        for data in ["x\n".repeat(MAX_LINES + 1), "界".repeat(MAX_LINE_CHARS + 1)] {
            let p = engine
                .preview(ext, input(data.as_bytes(), PreviewMode::Source))
                .unwrap();
            let Output::Text(doc) = p.output else {
                panic!("text expected")
            };
            assert!(doc.truncated);
            assert!(doc.lines.len() <= MAX_LINES);
            assert!(doc.lines.iter().all(|l| {
                l.spans
                    .iter()
                    .map(|s| s.text.chars().count())
                    .sum::<usize>()
                    <= MAX_LINE_CHARS
            }));
        }
        let p = engine
            .preview(ext, input("\u{feff}中文".as_bytes(), PreviewMode::Source))
            .unwrap();
        let Output::Text(doc) = p.output else {
            panic!("text expected")
        };
        assert_eq!(
            doc.lines[0]
                .spans
                .iter()
                .map(|s| s.text.as_str())
                .collect::<String>(),
            "中文"
        );
        assert!(
            engine
                .preview(ext, input(&vec![b'x'; TEXT_LIMIT + 1], PreviewMode::Source))
                .is_err()
        );
    }
    let html = b"<script>alert('source only')</script>";
    let p = engine
        .preview("html", input(html, PreviewMode::Source))
        .unwrap();
    let Output::Text(doc) = p.output else {
        panic!("text expected")
    };
    assert_eq!(
        doc.lines[0]
            .spans
            .iter()
            .map(|s| s.text.as_str())
            .collect::<String>()
            .as_bytes(),
        html
    );
}
#[test]
fn lexical_profiles_have_distinct_rules() {
    let engine = Engine::default();
    for (ext, text, token, style) in [
        (
            "txt",
            "return 42 # plain",
            "return 42 # plain",
            Style::Normal,
        ),
        ("log", "ERROR connection failed", "ERROR", Style::Keyword),
        ("json", "{\"x\": true}", "true", Style::Constant),
        (
            "sql",
            "SELECT id FROM users -- hi",
            "SELECT",
            Style::Keyword,
        ),
        ("ini", "; comment", "; comment", Style::Comment),
        ("properties", "! comment", "! comment", Style::Comment),
        (
            "lua",
            "--[[ long comment ]]",
            "--[[ long comment ]]",
            Style::Comment,
        ),
        ("sh", "# comment", "# comment", Style::Comment),
        ("css", "/* comment */", "/* comment */", Style::Comment),
        ("js", "const s = `hi`;", "const", Style::Keyword),
        (
            "ps1",
            "Function Get-Thing { # note",
            "Function",
            Style::Keyword,
        ),
        ("psm1", "<# block #>", "<# block #>", Style::Comment),
        ("cmd", "if exist a.txt echo ok", "if", Style::Keyword),
        ("bat", ":: comment", ":: comment", Style::Comment),
        ("rb", "def f # note", "def", Style::Keyword),
        ("cs", "public class A {}", "public", Style::Keyword),
        ("mjs", "const x = 1;", "const", Style::Keyword),
        ("scss", "$x: 1; // note", "// note", Style::Comment),
        ("zsh", "autoload -Uz compinit", "autoload", Style::Keyword),
        ("htm", "<p>hi</p>", "<", Style::Keyword),
        ("svg", "<!-- c -->", "<!-- c -->", Style::Comment),
        ("proto", "syntax = \"proto3\";", "syntax", Style::Keyword),
        ("tf", "resource \"x\" \"y\" {}", "resource", Style::Keyword),
        ("vtt", "WEBVTT", "WEBVTT", Style::Keyword),
        ("tex", "% comment", "% comment", Style::Comment),
        ("tex", "\\begin{document}", "begin", Style::Keyword),
        (
            "sty",
            "\\ProvidesPackage{sample}",
            "ProvidesPackage",
            Style::Keyword,
        ),
        ("bib", "@article{key,", "article", Style::Keyword),
    ] {
        let p = engine
            .preview(ext, input(text.as_bytes(), PreviewMode::Source))
            .unwrap();
        let Output::Text(doc) = p.output else {
            panic!("text expected")
        };
        assert!(
            doc.lines[0]
                .spans
                .iter()
                .any(|s| s.style == style && s.text == token),
            "{ext}"
        );
    }
}
#[test]
fn image_components_decode_bounded_and_gif_animates() {
    let engine = Engine::default();
    let fixtures: [(&str, &[u8]); 8] = [
        (
            "jpeg",
            include_bytes!("../../../samples/images/example.jpeg"),
        ),
        ("bmp", include_bytes!("../../../samples/images/example.bmp")),
        ("ico", include_bytes!("../../../samples/images/example.ico")),
        (
            "webp",
            include_bytes!("../../../samples/images/example.webp"),
        ),
        ("gif", include_bytes!("../../../samples/images/example.gif")),
        (
            "tiff",
            include_bytes!("../../../samples/images/example.tiff"),
        ),
        ("dds", include_bytes!("../../../samples/images/example.dds")),
        ("cur", include_bytes!("../../../samples/images/example.cur")),
    ];
    for (id, bytes) in fixtures {
        let info = engine
            .detect(Path::new(&format!("sample.{id}")), bytes)
            .unwrap();
        assert_eq!(info.kind, Kind::Image);
        let preview = engine
            .preview(
                id,
                Input {
                    viewport: (40, 30),
                    ..input(bytes, PreviewMode::Rendered)
                },
            )
            .unwrap();
        let Output::Image(image) = preview.output else {
            panic!("image")
        };
        assert!(image.width <= 40 && image.height <= 30);
        assert_eq!(
            image.bgra.len(),
            image.width as usize * image.height as usize * 4
        );
        if id == "gif" {
            let a = image.animation.as_ref().unwrap();
            assert_eq!(a.frames.len(), 2);
            assert_eq!(a.delays_ms, vec![100, 200, 300]);
            assert_eq!(a.plays, 0);
            assert_eq!(image.frame_index(0), 0);
            assert_eq!(image.frame_index(100), 1);
            assert_eq!(image.frame_index(300), 2);
            assert_eq!(image.frame_index(600), 0);
            assert_eq!(&image.bgra[..4], &[0, 0, 255, 255]);
            assert_eq!(&a.frames[0][..4], &[0, 255, 0, 255]);
        }
        assert!(
            engine
                .preview(id, input(b"bad image", PreviewMode::Rendered))
                .is_err()
        );
        assert!(
            engine
                .preview(
                    id,
                    Input {
                        viewport: (0, 30),
                        ..input(bytes, PreviewMode::Rendered)
                    }
                )
                .is_err()
        );
        assert!(
            engine
                .preview(id, input(bytes, PreviewMode::Source))
                .is_err()
        );
    }
    assert_eq!(
        engine
            .detect(
                Path::new("sample.JPG"),
                include_bytes!("../../../samples/images/example.jpg")
            )
            .unwrap()
            .id,
        "jpeg"
    );
    assert_eq!(
        engine
            .detect(
                Path::new("sample.JFIF"),
                include_bytes!("../../../samples/images/example.jfif")
            )
            .unwrap()
            .id,
        "jpeg"
    );
    assert_eq!(
        engine
            .detect(Path::new("photo.heic"), b"\0\0\0\x18ftypheic")
            .unwrap()
            .id,
        "heif"
    );
    assert!(
        engine
            .preview(
                "heif",
                input(
                    include_bytes!("../../../samples/images/broken.heic"),
                    PreviewMode::Rendered
                )
            )
            .is_err()
    );
}
#[test]
fn markdown_fences_choose_shared_language_rules() {
    let engine = Engine::default();
    for (lang, code, keyword) in [
        ("python", "def f():", "def"),
        ("rust", "pub fn f() {}", "pub"),
        ("js", "const x = 1;", "const"),
        ("sql", "SELECT 1", "SELECT"),
    ] {
        let text = format!("```{lang}\n{code}\n```\n");
        let p = engine
            .preview("markdown", input(text.as_bytes(), PreviewMode::Rendered))
            .unwrap();
        let Output::Text(d) = p.output else {
            panic!("text")
        };
        assert!(
            d.lines
                .iter()
                .flat_map(|l| &l.spans)
                .any(|s| s.style == Style::Keyword && s.text == keyword),
            "{lang}"
        );
    }
}

#[test]
fn webp_alpha_animation_and_source_pixel_limit() {
    let e = Engine::default();
    for bytes in [
        include_bytes!("../../../samples/images/alpha.webp").as_slice(),
        include_bytes!("../../../samples/images/animated.webp").as_slice(),
    ] {
        let p = e
            .preview("webp", input(bytes, PreviewMode::Rendered))
            .unwrap();
        let Output::Image(i) = p.output else {
            panic!("image")
        };
        assert!(i.bgra.as_chunks::<4>().0.iter().all(|p| p[3] == 255));
    }
    let p = e
        .preview(
            "webp",
            input(
                include_bytes!("../../../samples/images/animated.webp"),
                PreviewMode::Rendered,
            ),
        )
        .unwrap();
    let Output::Image(i) = p.output else {
        panic!("image")
    };
    assert_eq!(i.animation.as_ref().unwrap().frames.len(), 2);
    assert_eq!(i.frame_index(300), 2);
    let error = e
        .preview(
            "webp",
            input(
                include_bytes!("../../../samples/images/oversized.webp"),
                PreviewMode::Rendered,
            ),
        )
        .unwrap_err();
    assert!(error.to_string().contains("4 million"));
}

#[test]
fn markdown_math_is_pending_bounded_and_never_in_code_or_source_mode() {
    use quicklook_core::math::State;
    let engine = Engine::default();
    // 17 nested braces: balanced (so the parser accepts it) but over the depth budget,
    // which keeps the Fallback path covered now that command whitelisting is gone.
    let deep = format!("${}x{}$", "{".repeat(17), "}".repeat(17));
    let bytes = format!(
        "Inline $x^2$ text.\n\n$$\n\\frac{{1}}{{2}}\n$$\n\n`$notmath$`\n\n```py\n$notmath$\n```\n\n{deep}\n\n$\\begin{{cases}}x\\end{{cases}}$\n"
    );
    let bytes = bytes.as_bytes();
    let Output::Text(doc) = engine
        .preview("markdown", input(bytes, PreviewMode::Rendered))
        .unwrap()
        .output
    else {
        panic!()
    };
    let formulas: Vec<_> = doc
        .lines
        .iter()
        .flat_map(|l| &l.spans)
        .filter_map(|s| s.math.as_ref())
        .collect();
    assert_eq!(formulas.len(), 4);
    assert!(matches!(formulas[0].state, State::Pending));
    assert!(formulas[1].display);
    assert!(matches!(formulas[1].state, State::Pending));
    // Structurally invalid input stays a raw-LaTeX fallback.
    assert!(matches!(formulas[2].state, State::Fallback));
    // RichEdit typesets cases once normalized, so this one is Pending now.
    assert!(matches!(formulas[3].state, State::Pending));
    let Output::Text(doc) = engine
        .preview("markdown", input(bytes, PreviewMode::Source))
        .unwrap()
        .output
    else {
        panic!()
    };
    assert!(
        doc.lines
            .iter()
            .flat_map(|l| &l.spans)
            .all(|s| s.math.is_none())
    );
    let repeated = "$x$\n\n".repeat(100);
    let Output::Text(doc) = engine
        .preview(
            "markdown",
            input(repeated.as_bytes(), PreviewMode::Rendered),
        )
        .unwrap()
        .output
    else {
        panic!()
    };
    assert_eq!(
        doc.lines
            .iter()
            .flat_map(|l| &l.spans)
            .filter(|s| matches!(s.math.as_ref().map(|m| &m.state), Some(State::Pending)))
            .count(),
        64
    );
}

#[test]
fn csv_tsv_tables_keep_source_mode_and_mark_limits() {
    let engine = Engine::default();
    for (id, data) in [
        ("csv", "name,note\n中文,\"a,b\"\n"),
        ("tsv", "name\tnote\n中文\ta,b\n"),
    ] {
        let Output::Text(doc) = engine
            .preview(id, input(data.as_bytes(), PreviewMode::Rendered))
            .unwrap()
            .output
        else {
            panic!()
        };
        assert!(!doc.line_numbers);
        assert!(doc.lines.iter().all(|l| l.table));
        assert_eq!(doc.lines[1].spans[0].text, "中文\t");
        assert_eq!(doc.lines[1].spans[1].text, "a,b");
        let Output::Text(source) = engine
            .preview(id, input(data.as_bytes(), PreviewMode::Source))
            .unwrap()
            .output
        else {
            panic!()
        };
        assert!(source.line_numbers);
        assert!(source.lines.iter().all(|l| !l.table));
    }
    let Output::Text(doc) = engine
        .preview("csv", input(b"\"broken", PreviewMode::Rendered))
        .unwrap()
        .output
    else {
        panic!()
    };
    assert!(!doc.lines[0].table);
    assert!(doc.lines[0].spans[0].text.contains("Showing source"));
    let text = "x,".repeat(40);
    let Output::Text(doc) = engine
        .preview("csv", input(text.as_bytes(), PreviewMode::Rendered))
        .unwrap()
        .output
    else {
        panic!()
    };
    assert!(doc.truncated);
    assert_eq!(doc.lines[0].spans.len(), 32);
}

#[test]
fn paginated_component_advertises_worker_and_keeps_input_limits() {
    let engine = Engine::default();
    let info = engine
        .detect(std::path::Path::new("renamed.bin"), b"%PDF-1.4")
        .unwrap();
    assert_eq!(info.kind, Kind::Paged);
    assert!(!info.limits.allow_truncation);
    assert!(matches!(
        engine.preview(info.id, input(b"broken", PreviewMode::Rendered)),
        Err(PreviewError::InvalidData(_))
    ));
    assert!(matches!(
        engine.preview(info.id, input(b"%PDF-1.4", PreviewMode::Source)),
        Err(PreviewError::UnsupportedMode)
    ));
    let Output::Pages(p) = engine
        .preview(info.id, input(b"%PDF-1.4", PreviewMode::Rendered))
        .unwrap()
        .output
    else {
        panic!("paged capability")
    };
    assert_eq!(p.worker.id, quicklook_core::pages::PDF_WORKER.id);
    assert_eq!(p.source.unwrap(), b"%PDF-1.4");
    assert!(p.image.is_none());
}
