//! Pure registry and rendering orchestration. No filesystem, COM, GDI or application state.
use quicklook_core::*;
use std::path::Path;
pub struct Engine<'a> {
    formats: &'a [&'a dyn FormatPreview],
}
impl Default for Engine<'static> {
    fn default() -> Self {
        Self {
            formats: quicklook_render::components(),
        }
    }
}
impl<'a> Engine<'a> {
    pub fn new(formats: &'a [&'a dyn FormatPreview]) -> Result<Self, PreviewError> {
        for (i, format) in formats.iter().enumerate() {
            let info = format.info();
            if info.id.is_empty()
                || info.modes.is_empty()
                || info.limits.max_input_bytes == 0
                || info.extensions.iter().any(|e| e.is_empty())
                || info.magic.iter().any(|m| m.is_empty())
            {
                return Err(PreviewError::InvalidRegistry(
                    "Empty component contract".into(),
                ));
            }
            for previous in &formats[..i] {
                let other = previous.info();
                if other.id == info.id
                    || other
                        .extensions
                        .iter()
                        .any(|a| info.extensions.iter().any(|b| a.eq_ignore_ascii_case(b)))
                    || other.magic.iter().any(|a| info.magic.contains(a))
                {
                    return Err(PreviewError::InvalidRegistry(format!(
                        "Conflicting component: {}",
                        info.id
                    )));
                }
            }
        }
        Ok(Self { formats })
    }
    pub fn formats(&self) -> impl Iterator<Item = FormatInfo> + '_ {
        self.formats.iter().map(|f| f.info())
    }
    pub fn detect(&self, path: &Path, prefix: &[u8]) -> Result<FormatInfo, PreviewError> {
        sniff(path, prefix, self.formats)
            .map(|f| f.info())
            .ok_or(PreviewError::UnsupportedFormat)
    }
    pub fn preview(&self, id: &str, input: Input<'_>) -> Result<Preview, PreviewError> {
        let component = self
            .formats
            .iter()
            .find(|format| format.id() == id)
            .ok_or(PreviewError::UnsupportedFormat)?;
        let info = component.info();
        if !info.modes.contains(&input.mode) {
            return Err(PreviewError::UnsupportedMode);
        }
        if input.bytes.len() > info.limits.max_input_bytes
            || (input.truncated && !info.limits.allow_truncation)
        {
            return Err(PreviewError::LimitExceeded("component input"));
        }
        let output = component.preview(&input)?;
        Ok(Preview {
            format: info,
            mode: input.mode,
            output,
        })
    }
}
