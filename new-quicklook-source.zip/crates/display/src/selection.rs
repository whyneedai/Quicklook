use std::ops::Range;
/// Byte positions are always clamped to UTF-8 boundaries, including backwards drags.
#[derive(Debug, Default, Clone)]
pub struct Selection {
    anchor: usize,
    caret: usize,
}
fn boundary(text: &str, index: usize) -> usize {
    let mut n = index.min(text.len());
    while !text.is_char_boundary(n) {
        n -= 1;
    }
    n
}
/// Word characters for double-click selection: letters, digits and underscore.
fn is_word_char(c: char) -> bool {
    c.is_alphanumeric() || c == '_'
}
/// CJK/kana/full-width ranges. These scripts have no spaces, so a "word" is the run
/// of such characters (no dictionary segmentation is available here).
fn is_cjk(c: char) -> bool {
    matches!(
        c as u32,
        0x2E80..=0x303F
            | 0x3040..=0x30FF
            | 0x3400..=0x4DBF
            | 0x4E00..=0x9FFF
            | 0xF900..=0xFAFF
            | 0xFE30..=0xFE4F
            | 0xFF00..=0xFFEF
    )
}
/// Byte range of the word around `index`, for double-click selection. Clicking on
/// whitespace just after a word selects that word; punctuation selects the run of
/// that punctuation character; CJK selects the run of CJK characters.
pub fn simple_word_range(text: &str, index: usize) -> Range<usize> {
    let index = boundary(text, index);
    let after = text[index..].chars().next();
    let before = text[..index].chars().next_back();
    let ch = match after {
        Some(c) if is_word_char(c) || is_cjk(c) => c,
        Some(c) if c.is_whitespace() => before
            .filter(|b| is_word_char(*b) || is_cjk(*b))
            .unwrap_or(c),
        Some(c) => c,
        None => match before {
            Some(c) => c,
            None => return 0..0,
        },
    };
    let matches = |c: char| {
        if is_cjk(ch) {
            is_cjk(c)
        } else if is_word_char(ch) {
            is_word_char(c)
        } else {
            c == ch
        }
    };
    let mut start = index;
    while start > 0 {
        let prev = text[..start].chars().next_back().unwrap();
        if matches(prev) {
            start -= prev.len_utf8();
        } else {
            break;
        }
    }
    let mut end = index;
    while end < text.len() {
        let next = text[end..].chars().next().unwrap();
        if matches(next) {
            end += next.len_utf8();
        } else {
            break;
        }
    }
    start..end
}

impl Selection {
    pub fn begin(&mut self, text: &str, index: usize) {
        self.anchor = boundary(text, index);
        self.caret = self.anchor;
    }
    pub fn extend(&mut self, text: &str, index: usize) {
        self.caret = boundary(text, index);
    }
    /// Double-click: select the whole word around `index`.
    pub fn begin_word(&mut self, text: &str, index: usize) {
        let range = crate::word::word_range(text, index);
        self.anchor = range.start;
        self.caret = range.end;
    }
    pub fn all(&mut self, text: &str) {
        self.anchor = 0;
        self.caret = text.len();
    }
    pub fn range(&self) -> Range<usize> {
        self.anchor.min(self.caret)..self.anchor.max(self.caret)
    }
    pub fn text<'a>(&self, text: &'a str) -> &'a str {
        let range = self.range();
        &text[boundary(text, range.start)..boundary(text, range.end)]
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    use proptest::prelude::*;
    #[test]
    fn reverse_unicode_drag() {
        let t = "ab你好🙂z";
        let mut s = Selection::default();
        s.begin(t, t.len() - 1);
        s.extend(t, 2);
        assert_eq!(s.text(t), "你好🙂");
    }
    #[test]
    fn word_range_covers_words_and_scripts() {
        let t = "let value_1 = foo(bar); 你好世界 test";
        let at = |needle: &str, delta: usize| t.find(needle).unwrap() + delta;
        assert_eq!(&t[simple_word_range(t, at("value_1", 2))], "value_1");
        assert_eq!(&t[simple_word_range(t, at("foo", 1))], "foo");
        assert_eq!(&t[simple_word_range(t, at("bar", 0))], "bar");
        // clicking on whitespace just after a word selects that word
        assert_eq!(&t[simple_word_range(t, at("let", 3))], "let");
        assert_eq!(&t[simple_word_range(t, at("test", 4))], "test");
        // exactly on the boundary before punctuation selects the punctuation run
        assert_eq!(&t[simple_word_range(t, at("foo", 3))], "(");
        // punctuation selects the single character
        assert_eq!(&t[simple_word_range(t, at("(", 0))], "(");
        // CJK runs are selected as a run (no dictionary segmentation available)
        assert_eq!(&t[simple_word_range(t, at("你好世界", 2))], "你好世界");
        assert_eq!(&t[simple_word_range(t, at("test", 1))], "test");
        assert_eq!(simple_word_range("", 0), 0..0);
        // an emoji is not a word character: it selects on its own
        assert_eq!(&"🙂ab"[simple_word_range("🙂ab", 0)], "🙂");
        assert_eq!(&"🙂ab"[simple_word_range("🙂ab", 5)], "ab");
    }

    proptest! {#[test]fn arbitrary_offsets_never_split_utf8(text in ".{0,256}",a in any::<usize>(),b in any::<usize>()){let mut s=Selection::default();s.begin(&text,a);s.extend(&text,b);let selected=s.text(&text);prop_assert!(text.contains(selected));}}
}
