//! Scrollbar geometry, hit-testing and drag math.
//!
//! Platform-neutral so it can be unit-tested headlessly. The Windows surface
//! (`windows.rs`) and the input layer (`app`) share this single math source,
//! guaranteeing that painting and mouse interaction never drift apart.

/// Where a click on the scrollbar lands.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Hit {
    Thumb,
    PageUp,
    PageDown,
}

/// The track frame in client coordinates.
#[derive(Debug, Clone, Copy)]
pub struct Frame {
    pub left: i32,
    pub width: i32,
    pub top: i32,
    pub track_len: i32,
}

/// Proportional thumb placement inside the track.
#[derive(Debug, Clone, Copy)]
pub struct Metrics {
    pub track_len: i32,
    pub thumb_len: i32,
    pub thumb_pos: i32,
}

/// Proportional thumb metrics. Returns `None` when there is nothing to scroll.
pub fn metrics(scroll: i32, max_scroll: i32, track_len: i32, min_thumb: i32) -> Option<Metrics> {
    if max_scroll <= 0 || track_len <= 0 || min_thumb <= 0 {
        return None;
    }
    let track = i64::from(track_len);
    let extent = track + i64::from(max_scroll);
    let mut thumb = (track * track / extent) as i32;
    thumb = thumb.clamp(min_thumb.min(track_len), track_len);
    let scroll = scroll.clamp(0, max_scroll);
    let pos = ((track - i64::from(thumb)) * i64::from(scroll)) / i64::from(max_scroll);
    Some(Metrics {
        track_len,
        thumb_len: thumb,
        thumb_pos: pos as i32,
    })
}

/// Hit-test a client point against the scrollbar track.
///
/// `frame` delimits the vertical bar in client coordinates (see [`Frame`]).
/// Inside the bar: above the thumb = page up, below = page down, on the
/// thumb = thumb.
pub fn hit(
    scroll: i32,
    max_scroll: i32,
    min_thumb: i32,
    frame: Frame,
    x: i32,
    y: i32,
) -> Option<Hit> {
    if x < frame.left
        || x >= frame.left + frame.width
        || y < frame.top
        || y >= frame.top + frame.track_len
    {
        return None;
    }
    let metrics = metrics(scroll, max_scroll, frame.track_len, min_thumb)?;
    let y = y - frame.top;
    if y < metrics.thumb_pos {
        Some(Hit::PageUp)
    } else if y >= metrics.thumb_pos + metrics.thumb_len {
        Some(Hit::PageDown)
    } else {
        Some(Hit::Thumb)
    }
}

/// Map a drag to an absolute scroll position, clamped to `[0, max_scroll]`.
///
/// Uses the scroll captured at grab time (`start_scroll`, `grab_y`) so the thumb
/// tracks the pointer proportionally without accumulating rounding drift.
pub fn drag_scroll(
    start_scroll: i32,
    max_scroll: i32,
    track_len: i32,
    min_thumb: i32,
    grab_y: i32,
    current_y: i32,
) -> i32 {
    let Some(metrics) = metrics(start_scroll, max_scroll, track_len, min_thumb) else {
        return 0;
    };
    let range = i64::from(track_len - metrics.thumb_len).max(1);
    let delta = i64::from(current_y) - i64::from(grab_y);
    let next = i64::from(start_scroll) + (delta * i64::from(max_scroll)) / range;
    next.clamp(0, i64::from(max_scroll)) as i32
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn no_metrics_without_overflow() {
        assert!(metrics(0, 0, 100, 20).is_none());
        assert!(metrics(0, 50, 0, 20).is_none());
        assert!(metrics(0, 50, 100, 0).is_none());
    }

    #[test]
    fn thumb_is_proportional_and_keeps_minimum() {
        // 100 track, 900 overflow: proportional thumb would be 10, clamped to 20.
        let m = metrics(0, 900, 100, 20).unwrap();
        assert_eq!(m.thumb_len, 20);
        assert_eq!(m.thumb_pos, 0);
        // Fully scrolled -> thumb at the bottom.
        let m = metrics(900, 900, 100, 20).unwrap();
        assert_eq!(m.thumb_pos, 80);
    }

    #[test]
    fn overscroll_is_clamped() {
        // Track 100, max 100 -> thumb = 100*100/200 = 50.
        assert_eq!(metrics(-5, 100, 100, 20).unwrap().thumb_pos, 0);
        assert_eq!(metrics(150, 100, 100, 20).unwrap().thumb_pos, 50);
    }

    #[test]
    fn hit_kinds_and_out_of_bar() {
        let frame = Frame {
            left: 100,
            width: 3,
            top: 0,
            track_len: 100,
        };
        // Scrolled halfway: track 100, max 500, min 20 -> thumb 20 at pos 40.
        let (s, max, min) = (250, 500, 20);
        assert_eq!(hit(s, max, min, frame, 101, 10), Some(Hit::PageUp));
        assert_eq!(hit(s, max, min, frame, 101, 50), Some(Hit::Thumb));
        assert_eq!(hit(s, max, min, frame, 101, 85), Some(Hit::PageDown));
        // Outside x.
        assert_eq!(hit(s, max, min, frame, 99, 50), None);
        assert_eq!(hit(s, max, min, frame, 104, 50), None);
        // Outside y (above/below the track).
        assert_eq!(hit(s, max, min, frame, 101, -1), None);
        assert_eq!(hit(s, max, min, frame, 101, 100), None);
    }

    #[test]
    fn hit_respects_track_top_offset() {
        let frame = Frame {
            left: 100,
            width: 3,
            top: 64,
            track_len: 100,
        };
        // Same geometry as above but the bar starts at y=64.
        let (s, max, min) = (250, 500, 20);
        assert_eq!(hit(s, max, min, frame, 101, 64 + 10), Some(Hit::PageUp));
        assert_eq!(hit(s, max, min, frame, 101, 64 + 50), Some(Hit::Thumb));
        assert_eq!(hit(s, max, min, frame, 101, 64 + 85), Some(Hit::PageDown));
        // Just above the track top.
        assert_eq!(hit(s, max, min, frame, 101, 63), None);
        // Just below the track bottom.
        assert_eq!(hit(s, max, min, frame, 101, 64 + 100), None);
    }

    #[test]
    fn drag_scrolls_proportionally_and_clamps() {
        // 100 track, 900 overflow, min 20 -> thumb 20, free range 80.
        let max = 900;
        let tl = 100;
        let min = 20;
        let m = metrics(0, max, tl, min).unwrap();
        // Grab the thumb at its top, drag down by 10 -> proportional scroll up.
        let scrolled = drag_scroll(0, max, tl, min, m.thumb_pos, m.thumb_pos + 10);
        assert_eq!(scrolled, 10 * max / (tl - m.thumb_len));
        // Clamp at both ends.
        assert_eq!(drag_scroll(100, max, tl, min, 0, -10000), 0);
        assert_eq!(drag_scroll(100, max, tl, min, 0, 10000), max);
        // No wrap/negative.
        assert!(drag_scroll(100, max, tl, min, 100, 400) >= 0);
    }

    #[test]
    fn drag_never_exceeds_range() {
        for start in [0, 1, 5, 10, 100, 900] {
            for delta in -1000..=1000 {
                let v = drag_scroll(start, 900, 100, 20, 8, 8 + delta);
                assert!((0..=900).contains(&v), "start={start} delta={delta} -> {v}");
            }
        }
    }
}
