//! Format-independent, mouse-anchored zoom/pan geometry.
#[derive(Debug, Clone, Copy)]
pub struct Canvas {
    pub zoom: f64,
    pub offset: (f64, f64),
}
impl Default for Canvas {
    fn default() -> Self {
        Self {
            zoom: 1.0,
            offset: (0.0, 0.0),
        }
    }
}
impl Canvas {
    pub fn zoom_at(&mut self, delta: i32, anchor: (f64, f64), center: (f64, f64)) {
        let next = (self.zoom * 1.2f64.powf(f64::from(delta) / 120.0)).clamp(1.0, 16.0);
        let ratio = next / self.zoom;
        self.offset = (
            anchor.0 - center.0 - (anchor.0 - center.0 - self.offset.0) * ratio,
            anchor.1 - center.1 - (anchor.1 - center.1 - self.offset.1) * ratio,
        );
        self.zoom = next;
        if next == 1.0 {
            self.offset = (0.0, 0.0);
        }
    }
    pub fn pan(&mut self, delta: (f64, f64)) {
        if self.zoom > 1.0 {
            self.offset.0 += delta.0;
            self.offset.1 += delta.1;
        }
    }
    pub fn clamp(&mut self, image: (f64, f64), viewport: (f64, f64)) {
        let x = ((image.0 * self.zoom - viewport.0) / 2.0).max(0.0);
        let y = ((image.1 * self.zoom - viewport.1) / 2.0).max(0.0);
        self.offset.0 = self.offset.0.clamp(-x, x);
        self.offset.1 = self.offset.1.clamp(-y, y);
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn anchor_preserved_until_clamp() {
        let mut c = Canvas::default();
        c.zoom_at(120, (70.0, 40.0), (50.0, 50.0));
        assert!((c.offset.0 + 4.0).abs() < 1e-8);
        assert!((c.offset.1 - 2.0).abs() < 1e-8);
        c.zoom_at(-120, (70.0, 40.0), (50.0, 50.0));
        assert_eq!(c.offset, (0.0, 0.0));
    }
    #[test]
    fn pan_is_bounded_and_reset() {
        let mut c = Canvas::default();
        c.pan((30.0, 30.0));
        assert_eq!(c.offset, (0.0, 0.0));
        c.zoom = 2.0;
        c.pan((1000.0, -1000.0));
        c.clamp((100.0, 100.0), (100.0, 100.0));
        assert_eq!(c.offset, (50.0, -50.0));
    }
}
