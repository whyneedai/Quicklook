//! Viewport indexing for sorted document-space runs.
use std::ops::Range;
pub fn visible_range(tops: &[i32], max_height: i32, top: i32, bottom: i32) -> Range<usize> {
    let start = tops.partition_point(|y| *y <= top.saturating_sub(max_height));
    let end = tops.partition_point(|y| *y < bottom).max(start);
    start..end
}
#[cfg(windows)]
mod native {
    use crate::{
        drawing::{measure, rgb},
        fonts::Fonts,
        view::Hit,
    };
    use quicklook_core::{Document, Style};
    use windows::Win32::{Foundation::*, Graphics::Gdi::*};
    // Immutable document-space layout. Invalidated only by content, width or DPI.
    // No GDI handles are owned here; fonts live in ViewState and cache is cleared
    // before replacing them.
    pub(crate) struct Run {
        pub(crate) clip_right: Option<i32>,
        pub(crate) math: Option<std::sync::Arc<quicklook_core::math::Bitmap>>,
        pub(crate) value: String,
        pub(crate) hit: Hit,
        pub(crate) color: COLORREF,
        pub(crate) decoration: bool,
    }
    pub(crate) struct Layout {
        pub(crate) measure_ms: f64,
        pub(crate) width: i32,
        /// Content height laid out so far; a lower bound until `complete`.
        pub(crate) height: i32,
        pub(crate) max_height: i32,
        pub(crate) tops: Vec<i32>,
        pub(crate) runs: Vec<Run>,
        /// False while lines are still waiting to be laid out by `extend`.
        pub(crate) complete: bool,
        pub(crate) extensions: u64,
        next_line: usize,
        y: i32,
        offset: usize,
        left: i32,
        right: i32,
        columns: Vec<i32>,
    }

    /// How much of the document `lay` should consume in one call.
    enum Stop {
        /// Lay out until the content reaches this height (`None` = everything).
        Until(Option<i32>),
        /// Lay out at most this many milliseconds / lines, whichever comes first.
        Budget { max_ms: f64, max_lines: usize },
    }
    thread_local! {
        /// Nanoseconds spent inside GDI text measurement during the current build.
        static MEASURE_NS: std::cell::Cell<u64> = const { std::cell::Cell::new(0) };
    }
    fn measure_timed(dc: HDC, s: &str, font: HFONT) -> i32 {
        let t = std::time::Instant::now();
        let width = measure(dc, s, font);
        MEASURE_NS.with(|ns| ns.set(ns.get() + t.elapsed().as_nanos() as u64));
        width
    }
    pub(crate) fn take_measure_ms() -> f64 {
        MEASURE_NS.with(|ns| {
            let ms = ns.get() as f64 / 1e6;
            ns.set(0);
            ms
        })
    }

    thread_local! {
        /// Word/line widths survive across layout builds (scrolling, resize, reopening
        /// the same file) and are keyed by (font handle, text). Exact GDI widths only.
        static WIDTH_CACHE: std::cell::RefCell<std::collections::HashMap<(usize, String), i32>> =
            std::cell::RefCell::new(std::collections::HashMap::new());
    }
    fn cached_width(dc: HDC, value: &str, font: HFONT) -> i32 {
        let key = (font.0 as usize, value.to_owned());
        WIDTH_CACHE.with(|cache| {
            let mut cache = cache.borrow_mut();
            if let Some(width) = cache.get(&key) {
                return *width;
            }
            let width = measure_timed(dc, value, font);
            if cache.len() >= 16_384 {
                cache.clear();
            }
            cache.insert(key, width);
            width
        })
    }

    impl Layout {
        /// Lay out at least `budget_y` pixels of content (or the whole document when
        /// `None`). Remaining lines are produced by `extend` in the background, so the
        /// first frame costs one screen instead of the whole file, for every language.
        pub(crate) fn build(
            dc: HDC,
            doc: &Document,
            fonts: &Fonts,
            dpi: u32,
            width: i32,
            budget_y: Option<i32>,
        ) -> Self {
            let mut layout = Self::empty(dc, doc, fonts, dpi, width);
            layout.lay(dc, doc, fonts, dpi, Stop::Until(budget_y));
            layout.finish();
            layout
        }

        fn empty(dc: HDC, doc: &Document, fonts: &Fonts, dpi: u32, width: i32) -> Self {
            let scale = |v: i32| v * dpi as i32 / 96;
            let left = scale(if doc.line_numbers { 76 } else { 24 });
            let right = (width - scale(24)).max(left + 1);
            let mut columns = Vec::<i32>::new();
            for line in doc.lines.iter().filter(|l| l.table) {
                for (i, span) in line.spans.iter().enumerate() {
                    if columns.len() <= i {
                        columns.resize(i + 1, 0);
                    }
                    columns[i] = columns[i].max(cached_width(
                        dc,
                        &span.text.replace('\t', "    "),
                        fonts.mono,
                    ));
                }
            }
            let total = columns.iter().sum::<i32>().max(1);
            if total > right - left {
                for width in &mut columns {
                    *width =
                        ((*width as i64 * (right - left) as i64) / i64::from(total)).max(1) as i32;
                }
            }
            Self {
                measure_ms: 0.0,
                width,
                height: 0,
                max_height: 0,
                tops: Vec::new(),
                runs: Vec::new(),
                complete: false,
                extensions: 0,
                next_line: 0,
                y: 0,
                offset: 0,
                left,
                right,
                columns,
            }
        }

        /// First-frame build: lay out at most `max_ms` milliseconds / `max_lines` lines.
        /// The rest is produced by `extend`, so the first frame never pays for the whole
        /// document, whatever the language or file size.
        pub(crate) fn build_within(
            dc: HDC,
            doc: &Document,
            fonts: &Fonts,
            dpi: u32,
            width: i32,
            max_ms: f64,
            max_lines: usize,
        ) -> Self {
            let mut layout = Self::empty(dc, doc, fonts, dpi, width);
            layout.lay(dc, doc, fonts, dpi, Stop::Budget { max_ms, max_lines });
            layout.finish();
            layout
        }

        /// Continue the layout, bounded by time and lines so it can run from a timer
        /// without blocking input. Returns true once the whole document is laid out.
        pub(crate) fn extend(
            &mut self,
            dc: HDC,
            doc: &Document,
            fonts: &Fonts,
            dpi: u32,
            max_ms: f64,
            max_lines: usize,
        ) -> bool {
            if self.complete {
                return true;
            }
            self.extensions += 1;
            self.lay(dc, doc, fonts, dpi, Stop::Budget { max_ms, max_lines });
            self.finish();
            self.complete
        }

        fn finish(&mut self) {
            self.measure_ms += take_measure_ms();
            self.runs.sort_by_key(|run| run.hit.rect.top);
            self.tops = self.runs.iter().map(|r| r.hit.rect.top).collect();
            self.max_height = self
                .runs
                .iter()
                .map(|r| r.hit.rect.bottom - r.hit.rect.top)
                .max()
                .unwrap_or(0);
            self.height = self.y;
        }

        fn lay(&mut self, dc: HDC, doc: &Document, fonts: &Fonts, dpi: u32, stop: Stop) {
            let scale = |v: i32| v * dpi as i32 / 96;
            let left = self.left;
            let right = self.right;
            let columns = std::mem::take(&mut self.columns);
            let mut runs = std::mem::take(&mut self.runs);
            let mut y = self.y;
            let mut offset = self.offset;
            let mut index = self.next_line;
            let started = std::time::Instant::now();
            let mut lines_done = 0usize;
            while index < doc.lines.len() {
                if lines_done > 0 {
                    match stop {
                        Stop::Until(Some(limit)) if y >= limit => break,
                        Stop::Budget { max_ms, max_lines }
                            if lines_done >= max_lines
                                || started.elapsed().as_secs_f64() * 1000.0 >= max_ms =>
                        {
                            break;
                        }
                        _ => {}
                    }
                }
                let line = &doc.lines[index];
                let heading = line.heading;
                let height = scale(match heading {
                    0 => 25,
                    1 => 44,
                    2 => 37,
                    _ => 32,
                });
                let mut has_math = false;
                let mut ascent = scale(19);
                let mut descent = (height - ascent).max(0);
                for span in &line.spans {
                    if let Some(quicklook_core::math::Formula {
                        state: quicklook_core::math::State::Ready(b),
                        ..
                    }) = &span.math
                    {
                        has_math = true;
                        let ratio = (f64::from(right - left) / f64::from(b.width))
                            .min(f64::from(dpi) / f64::from(b.dpi));
                        let base = (f64::from(b.baseline) * ratio).ceil() as i32;
                        let h = (f64::from(b.height) * ratio).ceil() as i32;
                        ascent = ascent.max(base);
                        descent = descent.max(h - base);
                    }
                }
                let height = height.max(ascent + descent);
                if heading > 0 {
                    y += scale(10);
                }
                let start_y = y;
                if doc.line_numbers {
                    runs.push(Run {
                        clip_right: None,
                        math: None,
                        value: line.source.to_string(),
                        hit: Hit {
                            atomic: false,
                            rect: RECT {
                                left: scale(20),
                                top: y,
                                right: left,
                                bottom: y + height,
                            },
                            range: 0..0,
                            font: fonts.mono,
                        },
                        color: rgb(91, 107, 133),
                        decoration: false,
                    });
                }
                let mut x = left;
                let mut row_bottom = y + height;
                for (column, span) in line.spans.iter().enumerate() {
                    let cell_left = if line.table {
                        left + columns[..column].iter().sum::<i32>()
                    } else {
                        left
                    };
                    let cell_right = if line.table {
                        cell_left + columns[column]
                    } else {
                        right
                    };
                    if line.table {
                        x = cell_left;
                        y = start_y;
                    }
                    let left = cell_left;
                    let right = cell_right;
                    let font = if heading > 0 {
                        fonts.headings[usize::from(heading.saturating_sub(1).min(2))]
                    } else if line.code || span.style == Style::Code {
                        fonts.mono
                    } else if span.style == Style::Bold {
                        fonts.bold
                    } else if span.style == Style::Emphasis {
                        fonts.italic
                    } else {
                        fonts.ui
                    };
                    let color = match crate::palette::color(span.style) {
                        Some((r, g, b)) => rgb(r, g, b),
                        None if heading > 0 => rgb(238, 242, 250),
                        None if line.quote => rgb(151, 177, 205),
                        None => rgb(213, 222, 235),
                    };
                    if let Some(quicklook_core::math::Formula {
                        state: quicklook_core::math::State::Pending,
                        ..
                    }) = &span.math
                    {
                        // Pending formulas are never drawn as raw LaTeX: leave the slot
                        // empty until the worker returns the bitmap (no source flash).
                        offset += span.text.len();
                        continue;
                    }
                    if let Some(quicklook_core::math::Formula {
                        state: quicklook_core::math::State::Ready(b),
                        display,
                    }) = &span.math
                    {
                        let ratio = (f64::from(right - left) / f64::from(b.width))
                            .min(f64::from(dpi) / f64::from(b.dpi));
                        let bw = (f64::from(b.width) * ratio).ceil() as i32;
                        let bh = (f64::from(b.height) * ratio).ceil() as i32;
                        let base = (f64::from(b.baseline) * ratio).ceil() as i32;
                        if x > left && x + bw > right {
                            x = left;
                            y += height;
                        }
                        if *display {
                            x = left + (right - left - bw) / 2;
                        }
                        runs.push(Run {
                            clip_right: None,
                            math: Some(b.clone()),
                            value: span.text.clone(),
                            hit: Hit {
                                atomic: true,
                                rect: RECT {
                                    left: x,
                                    top: y + ascent - base,
                                    right: x + bw,
                                    bottom: y + ascent - base + bh,
                                },
                                range: offset..offset + span.text.len(),
                                font,
                            },
                            color,
                            decoration: false,
                        });
                        offset += span.text.len();
                        x += bw;
                        continue;
                    }
                    let text_shift = if has_math {
                        unsafe {
                            let old = SelectObject(dc, font.into());
                            let mut metrics = TEXTMETRICW::default();
                            let _ = GetTextMetricsW(dc, &mut metrics);
                            SelectObject(dc, old);
                            ascent - metrics.tmAscent
                        }
                    } else {
                        0
                    };
                    let normalized = span.text.replace('\t', "    ").replace('\0', "�");
                    for word in normalized.split_inclusive(' ') {
                        let word_width = cached_width(dc, word, font);
                        if x > left && x + word_width > right {
                            x = left;
                            y += height;
                        }
                        let pieces: Vec<&str> = if word_width > right - left {
                            word.char_indices()
                                .map(|(i, c)| &word[i..i + c.len_utf8()])
                                .collect()
                        } else {
                            vec![word]
                        };
                        for value in pieces {
                            let advance = if word_width > right - left {
                                cached_width(dc, value, font)
                            } else {
                                word_width
                            };
                            if x > left && x + advance > right {
                                x = left;
                                y += height;
                            }
                            runs.push(Run {
                                clip_right: if line.table { Some(right) } else { None },
                                math: None,
                                value: value.to_owned(),
                                hit: Hit {
                                    atomic: false,
                                    rect: RECT {
                                        left: x,
                                        top: y + text_shift,
                                        right: x + advance,
                                        bottom: y + height,
                                    },
                                    range: offset..offset + value.len(),
                                    font,
                                },
                                color,
                                decoration: false,
                            });
                            x += advance;
                            offset += value.len();
                        }
                    }
                    row_bottom = row_bottom.max(y + height);
                }
                if line.table {
                    y = row_bottom - height;
                }
                if line.quote {
                    // Segment quote bars by visual row to keep viewport indexing bounded.
                    for row_y in (start_y..y + height).step_by(height as usize) {
                        runs.push(Run {
                            clip_right: None,
                            math: None,
                            value: String::new(),
                            hit: Hit {
                                atomic: false,
                                rect: RECT {
                                    left: left - scale(12),
                                    top: row_y,
                                    right: left - scale(9),
                                    bottom: row_y + height,
                                },
                                range: 0..0,
                                font: fonts.ui,
                            },
                            color: rgb(75, 145, 224),
                            decoration: true,
                        });
                    }
                }
                y += height + if line.code { 0 } else { scale(5) };
                offset += 1;
                index += 1;
                lines_done += 1;
            }
            self.runs = runs;
            self.y = y;
            self.offset = offset;
            self.next_line = index;
            self.columns = columns;
            self.complete = index >= doc.lines.len();
        }
    }
}
#[cfg(windows)]
pub(crate) use native::Layout;

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn clips_rows_and_retains_partial_rows() {
        assert_eq!(visible_range(&[0, 25, 50, 75], 25, 26, 74), 1..3);
        assert_eq!(visible_range(&[0, 25, 50, 75], 25, 25, 50), 1..2);
        assert_eq!(visible_range(&[], 25, 0, 20), 0..0);
    }
    #[cfg(windows)]
    #[test]
    fn incremental_layout_matches_full_layout() {
        use quicklook_core::{Document, Line, Span, Style};
        let lines: Vec<Line> = (0..300)
            .map(|i| Line {
                spans: vec![Span {
                    text: format!(
                        "line {i} 中文内容 with several words that wrap around the viewport width"
                    ),
                    style: Style::Normal,
                    math: None,
                }],
                ..Default::default()
            })
            .collect();
        let doc = Document {
            lines,
            ..Default::default()
        };
        unsafe {
            let dc = windows::Win32::Graphics::Gdi::CreateCompatibleDC(None);
            let fonts = crate::fonts::Fonts::new(96);
            let full = super::native::Layout::build(dc, &doc, &fonts, 96, 800, None);
            assert!(full.complete);
            let mut partial = super::native::Layout::build(dc, &doc, &fonts, 96, 800, Some(120));
            assert!(
                !partial.complete,
                "first screen should not lay out everything"
            );
            let mut guard = 0;
            while !partial.extend(dc, &doc, &fonts, 96, 5.0, 32) {
                guard += 1;
                assert!(guard < 500, "extend never finished");
            }
            assert_eq!(partial.runs.len(), full.runs.len());
            assert_eq!(partial.height, full.height);
            assert_eq!(partial.tops.len(), full.tops.len());
            assert!(partial.extensions > 0);
            let _ = windows::Win32::Graphics::Gdi::DeleteDC(dc);
        }
    }

    #[cfg(windows)]
    #[test]
    fn pending_formulas_are_not_drawn_as_source() {
        use quicklook_core::{
            Document, Line, Span, Style,
            math::{Formula, State},
        };
        let doc = Document {
            lines: vec![Line {
                spans: vec![
                    Span {
                        text: "before ".into(),
                        style: Style::Normal,
                        math: None,
                    },
                    Span {
                        text: "\\frac{1}{2}".into(),
                        style: Style::Code,
                        math: Some(Formula {
                            display: false,
                            state: State::Pending,
                        }),
                    },
                    Span {
                        text: " after".into(),
                        style: Style::Normal,
                        math: None,
                    },
                ],
                ..Default::default()
            }],
            ..Default::default()
        };
        unsafe {
            let dc = windows::Win32::Graphics::Gdi::CreateCompatibleDC(None);
            let fonts = crate::fonts::Fonts::new(96);
            let layout = super::native::Layout::build(dc, &doc, &fonts, 96, 800, None);
            let drawn: String = layout.runs.iter().map(|r| r.value.clone()).collect();
            assert!(!drawn.contains("frac"), "raw LaTeX was drawn: {drawn}");
            assert!(drawn.contains("before") && drawn.contains("after"));
            let _ = windows::Win32::Graphics::Gdi::DeleteDC(dc);
        }
    }
    proptest::proptest! {
        #[test]
        fn never_omits_intersecting_runs(mut tops in proptest::collection::vec(-10000i32..10000,0..200), top in -10000i32..10000, h in 1i32..1000, height in 1i32..100) {
            tops.sort();
            let range=visible_range(&tops,height,top,top+h);
            for (i,y) in tops.iter().enumerate() {
                if *y+height > top && *y < top+h { proptest::prop_assert!(range.contains(&i)); }
            }
        }
    }
}
