use crate::{Selection, drawing::measure, fonts::Fonts, layout::Layout};
use quicklook_core::{Output as Content, PreviewMode};
use std::ops::Range;
use windows::Win32::{Foundation::*, Graphics::Gdi::*};
/// Bounded paint history for --trace/--smoke; never populated in ordinary release use.
#[derive(Clone, Copy, Debug)]
pub struct ScrollFrame {
    pub width: i32,
    pub complete: bool,
    pub scroll: i32,
    pub draw_scroll: i32,
    pub max_scroll: i32,
}
pub struct ViewState {
    pub(crate) back_buffer: Option<crate::drawing::BackBuffer>,
    pub canvas: crate::Canvas,
    pub wheel_remainder: i32,
    pub panning: Option<(i32, i32)>,
    pub animation_started: std::time::Instant,
    pub content: Option<Content>,
    pub(crate) layout: Option<Layout>,
    pub load_ms: f64,
    pub image_fit: String,
    pub nav_direction: String,
    pub nav_diag: String,
    pub nav_from: String,
    pub nav_to: String,
    pub nav_from_pos: String,
    pub nav_to_pos: String,
    pub prep_ms: f64,
    pub show_ms: f64,
    pub rdw_ms: f64,
    pub activate_ms: f64,
    pub activate_show_ms: f64,
    pub activate_top_ms: f64,
    pub activate_fg_ms: f64,
    pub activate_fallback_ms: f64,
    pub activate_rest_ms: f64,
    pub ready_ms: f64,
    pub paint_start_ms: f64,
    pub layout_builds: u64,
    pub layout_complete: bool,
    pub layout_extensions: u64,
    pub paint_ms: f64,
    pub layout_ms: f64,
    pub layout_measure_ms: f64,
    pub draw_ms: f64,
    pub visible_runs: usize,
    pub(crate) selection: Selection,
    pub(crate) text: String,
    pub(crate) hits: Vec<Hit>,
    pub selecting: bool,
    pub title: String,
    pub type_label: String,
    pub mode: PreviewMode,
    pub modes: &'static [PreviewMode],
    pub scroll: i32,
    pub max_scroll: i32,
    pub scroll_frames: Vec<ScrollFrame>,
    pub pinned: bool,
    pub dpi: u32,
    pub(crate) fonts: Fonts,
    pub math_paint_ms: Option<f64>,
    pub first_paint_ms: Option<f64>,
    pub show_status: bool,
    pub scrollbar_hover: bool,
    pub scrollbar_drag: bool,
    pub(crate) scrollbar_grab_y: i32,
    pub(crate) scrollbar_grab_scroll: i32,
}
impl ViewState {
    pub fn new(dpi: u32) -> Self {
        Self {
            back_buffer: None,
            canvas: crate::Canvas::default(),
            wheel_remainder: 0,
            panning: None,
            animation_started: std::time::Instant::now(),
            content: None,
            layout: None,
            load_ms: 0.0,
            image_fit: String::new(),
            nav_direction: String::new(),
            nav_diag: String::new(),
            nav_from: String::new(),
            nav_to: String::new(),
            nav_from_pos: String::new(),
            nav_to_pos: String::new(),
            prep_ms: 0.0,
            show_ms: 0.0,
            rdw_ms: 0.0,
            activate_ms: 0.0,
            activate_show_ms: 0.0,
            activate_top_ms: 0.0,
            activate_fg_ms: 0.0,
            activate_fallback_ms: 0.0,
            activate_rest_ms: 0.0,
            ready_ms: 0.0,
            paint_start_ms: 0.0,
            layout_builds: 0,
            layout_complete: true,
            layout_extensions: 0,
            paint_ms: 0.0,
            layout_ms: 0.0,
            layout_measure_ms: 0.0,
            draw_ms: 0.0,
            visible_runs: 0,
            selection: Selection::default(),
            text: String::new(),
            hits: Vec::new(),
            selecting: false,
            title: "new-quicklook".into(),
            type_label: String::new(),
            mode: PreviewMode::Rendered,
            modes: &[],
            scroll: 0,
            max_scroll: 0,
            scroll_frames: Vec::new(),
            pinned: false,
            dpi,
            fonts: Fonts::new(dpi),
            math_paint_ms: None,
            first_paint_ms: None,
            show_status: cfg!(debug_assertions),
            scrollbar_hover: false,
            scrollbar_drag: false,
            scrollbar_grab_y: 0,
            scrollbar_grab_scroll: 0,
        }
    }
    pub fn set_dpi(&mut self, dpi: u32) {
        self.layout = None;
        self.hits.clear();
        self.dpi = dpi;
        self.fonts = Fonts::new(dpi);
        self.scrollbar_hover = false;
        self.scrollbar_drag = false;
    }
    fn scale(&self, v: i32) -> i32 {
        v * self.dpi as i32 / 96
    }
    fn bar_h(&self) -> i32 {
        self.scale(64)
    }
    fn foot_h(&self) -> i32 {
        self.scale(36)
    }
    /// Scrollbar track frame in client coordinates, or `None` when there is
    /// nothing to scroll.
    pub fn scrollbar_frame(&self, w: i32, h: i32) -> Option<crate::scrollbar::Frame> {
        if self.max_scroll <= 0 {
            return None;
        }
        let track_len = (h - self.bar_h() - self.foot_h()).max(1);
        if track_len <= 0 {
            return None;
        }
        Some(crate::scrollbar::Frame {
            // Keep the bar clear of the right-edge resize grip (WM_NCHITTEST
            // reserves the outermost 7 DIP for HTRIGHT), and make it wide
            // enough to grab comfortably.
            left: w - self.scale(18),
            width: self.scale(10),
            top: self.bar_h(),
            track_len,
        })
    }
    /// Current thumb metrics, matching what `paint` draws.
    pub fn scrollbar_metrics(&self, w: i32, h: i32) -> Option<crate::scrollbar::Metrics> {
        let frame = self.scrollbar_frame(w, h)?;
        crate::scrollbar::metrics(
            self.scroll,
            self.max_scroll,
            frame.track_len,
            self.scale(20),
        )
    }
    /// Hit-test a client point against the scrollbar.
    pub fn scrollbar_hit(&self, w: i32, h: i32, x: i32, y: i32) -> Option<crate::scrollbar::Hit> {
        let frame = self.scrollbar_frame(w, h)?;
        crate::scrollbar::hit(self.scroll, self.max_scroll, self.scale(20), frame, x, y)
    }
    pub fn begin_scroll_drag(&mut self, y: i32) {
        self.scrollbar_drag = true;
        self.scrollbar_grab_y = y - self.bar_h();
        self.scrollbar_grab_scroll = self.scroll;
    }
    pub fn scroll_drag_to(&mut self, w: i32, h: i32, y: i32) {
        if !self.scrollbar_drag {
            return;
        }
        let Some(frame) = self.scrollbar_frame(w, h) else {
            self.scrollbar_drag = false;
            return;
        };
        let track_y = y - self.bar_h();
        self.scroll = crate::scrollbar::drag_scroll(
            self.scrollbar_grab_scroll,
            self.max_scroll,
            frame.track_len,
            self.scale(20),
            self.scrollbar_grab_y,
            track_y,
        )
        .clamp(0, self.max_scroll);
    }
    pub fn end_scroll_drag(&mut self) {
        self.scrollbar_drag = false;
    }
}

#[derive(Clone)]
pub(crate) struct Hit {
    pub(crate) atomic: bool,
    pub(crate) rect: RECT,
    pub(crate) range: Range<usize>,
    pub(crate) font: HFONT,
}
impl ViewState {
    pub fn update_content(&mut self, content: Content) {
        // Formula replacements preserve source text and the user's scroll/selection.
        self.content = Some(content);
        self.layout = None;
        self.hits.clear();
    }
    pub fn replace_content(&mut self, content: Option<Content>) {
        if content.is_none() {
            self.back_buffer = None;
        }
        self.text = match &content {
            Some(Content::Text(doc)) => doc
                .lines
                .iter()
                .map(|line| {
                    line.spans
                        .iter()
                        .map(|s| s.text.replace('\t', "    ").replace('\0', "�"))
                        .collect::<String>()
                })
                .collect::<Vec<_>>()
                .join("\n"),
            _ => String::new(),
        };
        self.math_paint_ms = None;
        self.layout = None;
        self.scroll_frames.clear();
        self.scroll = 0;
        self.max_scroll = 0;
        self.visible_runs = 0;
        self.animation_started = std::time::Instant::now();
        self.canvas = crate::Canvas::default();
        self.wheel_remainder = 0;
        self.panning = None;
        self.content = content;
        self.selection = Selection::default();
        self.hits.clear();
        self.selecting = false;
        self.scrollbar_hover = false;
        self.scrollbar_drag = false;
    }
    pub fn select_all(&mut self) {
        self.selection.all(&self.text);
    }
    pub fn selected_text(&self) -> Option<String> {
        let s = self.selection.text(&self.text);
        if s.is_empty() {
            None
        } else {
            Some(s.replace('\n', "\r\n"))
        }
    }
    pub fn begin_selection(&mut self, hwnd: HWND, point: POINT) -> bool {
        if !matches!(self.content, Some(Content::Text(_))) || point.y < 64 * self.dpi as i32 / 96 {
            return false;
        }
        if let Some(index) = self.hit_test(hwnd, point) {
            self.selection.begin(&self.text, index);
            self.selecting = true;
            true
        } else {
            false
        }
    }
    pub fn extend_selection(&mut self, hwnd: HWND, point: POINT) {
        if let Some(index) = self.hit_test(hwnd, point) {
            self.selection.extend(&self.text, index);
        }
    }
    /// Double-click in text: select the word under the cursor (drag extends by word).
    pub fn select_word(&mut self, hwnd: HWND, point: POINT) -> bool {
        if !matches!(self.content, Some(Content::Text(_))) || point.y < self.scale(64) {
            return false;
        }
        let Some(index) = self.hit_test(hwnd, point) else {
            return false;
        };
        // Double-click selects exactly one word; dragging afterwards stays character
        // level, matching single-click drag semantics.
        self.selection.begin_word(&self.text, index);
        self.selecting = true;
        true
    }
    fn hit_test(&self, hwnd: HWND, point: POINT) -> Option<usize> {
        let hit = self.hits.iter().min_by_key(|hit| {
            let dy = if point.y < hit.rect.top {
                hit.rect.top - point.y
            } else if point.y >= hit.rect.bottom {
                point.y - hit.rect.bottom + 1
            } else {
                0
            };
            let dx = if point.x < hit.rect.left {
                hit.rect.left - point.x
            } else if point.x > hit.rect.right {
                point.x - hit.rect.right
            } else {
                0
            };
            (dy, dx)
        })?;
        if hit.atomic {
            return Some(if point.x < (hit.rect.left + hit.rect.right) / 2 {
                hit.range.start
            } else {
                hit.range.end
            });
        }
        let value = self.text.get(hit.range.clone())?;
        if point.x <= hit.rect.left {
            return Some(hit.range.start);
        }
        if point.x >= hit.rect.right {
            return Some(hit.range.end);
        }
        unsafe {
            let dc = GetDC(Some(hwnd));
            let mut previous = 0;
            let mut index = hit.range.end;
            for (offset, c) in value.char_indices() {
                let end = offset + c.len_utf8();
                let width = measure(dc, &value[..end], hit.font);
                if point.x - hit.rect.left < (previous + width) / 2 {
                    index = hit.range.start + offset;
                    break;
                }
                previous = width;
            }
            ReleaseDC(Some(hwnd), dc);
            Some(index)
        }
    }
}

impl ViewState {
    pub fn zoom_image(&mut self, delta: i32, point: POINT, w: i32, h: i32) -> bool {
        if self.content.as_ref().and_then(Content::image).is_none() {
            return false;
        }
        let top = self.scale(84);
        let bottom = h - self.scale(36);
        self.canvas.zoom_at(
            delta,
            (f64::from(point.x), f64::from(point.y)),
            (f64::from(w) / 2.0, f64::from(top + bottom) / 2.0),
        );
        true
    }
    pub fn begin_pan(&mut self, point: POINT) -> bool {
        if self.content.as_ref().and_then(Content::image).is_some()
            && self.canvas.zoom > 1.0
            && point.y >= self.scale(64)
        {
            self.panning = Some((point.x, point.y));
            true
        } else {
            false
        }
    }
    pub fn pan_to(&mut self, point: POINT) {
        if let Some((x, y)) = self.panning {
            self.canvas
                .pan((f64::from(point.x - x), f64::from(point.y - y)));
            self.panning = Some((point.x, point.y));
        }
    }
    pub fn reset_canvas(&mut self) {
        self.canvas = crate::Canvas::default();
        self.panning = None;
    }
}
