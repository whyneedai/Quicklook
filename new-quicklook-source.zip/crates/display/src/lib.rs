//! Native presentation; consumes only core contracts and models.
#[cfg(windows)]
mod windows;
#[cfg(windows)]
pub use windows::*;

#[cfg(windows)]
mod word;

mod selection;
pub use selection::Selection;

mod scrollbar;
pub use scrollbar::{Frame, Hit, Metrics};

#[cfg(any(windows, test))]
mod layout;

#[cfg(windows)]
mod drawing;
#[cfg(windows)]
mod fonts;
#[cfg(windows)]
mod view;

mod canvas;
pub use canvas::Canvas;

#[cfg(any(windows, test))]
mod palette;
