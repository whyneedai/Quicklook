//! Word boundaries for double-click selection.
//!
//! 1. A click inside a matched quote/bracket pair selects the inner content.
//! 2. Otherwise the system ICU break iterator (`icu.dll`, present since Windows 10
//!    1703) provides real, locale-aware, dictionary-based word boundaries - including
//!    Chinese/Japanese/Thai segmentation - instead of a hand-rolled character class.
//! 3. If ICU is unavailable the simple character-class rule is used as a fallback.
use std::ops::Range;
use windows::Win32::System::LibraryLoader::{GetProcAddress, LoadLibraryW};
use windows::core::PCWSTR;

/// Double-quote pairs: a double-click inside them selects the consecutive content
/// between the quotes. Single quotes and backticks are deliberately excluded -
/// apostrophes (`don't`) and code spans would otherwise select surprising spans -
/// so those fall through to the ICU word rules.
const PAIRS: &[(char, char)] = &[
    ('"', '"'),
    ('\u{201c}', '\u{201d}'),
    ('\u{ff02}', '\u{ff02}'),
    ('\u{300c}', '\u{300d}'),
    ('\u{300e}', '\u{300f}'),
];

fn boundary(text: &str, index: usize) -> usize {
    let mut n = index.min(text.len());
    while !text.is_char_boundary(n) {
        n -= 1;
    }
    n
}

/// Inner range of the quote pair containing `index`, if any (same line only).
fn pair_range(text: &str, index: usize) -> Option<Range<usize>> {
    let index = boundary(text, index);
    for &(open, close) in PAIRS {
        if open == close {
            // Symmetric quote: nearest occurrence before and after, same line.
            let before = text[..index]
                .char_indices()
                .rev()
                .take_while(|(_, c)| *c != '\n')
                .find(|(_, c)| *c == open);
            let Some((start, _)) = before else { continue };
            let from = start + open.len_utf8();
            let after = text[from..]
                .char_indices()
                .take_while(|(_, c)| *c != '\n')
                .find(|(_, c)| *c == close);
            let Some((offset, _)) = after else { continue };
            let inner = from..from + offset;
            if !text[inner.clone()].trim().is_empty() && inner.start <= index {
                return Some(inner);
            }
        } else {
            // Find the opening delimiter with balanced nesting before `index`.
            let mut depth = 0usize;
            let mut open_at = None;
            for (i, c) in text[..index].char_indices().rev() {
                if c == '\n' {
                    break;
                }
                if c == close {
                    depth += 1;
                } else if c == open {
                    if depth == 0 {
                        open_at = Some(i);
                        break;
                    }
                    depth -= 1;
                }
            }
            let Some(start) = open_at else { continue };
            let from = start + open.len_utf8();
            let mut depth = 0usize;
            for (i, c) in text[from..].char_indices() {
                if c == '\n' {
                    break;
                }
                if c == open {
                    depth += 1;
                } else if c == close {
                    if depth == 0 {
                        let inner = from..from + i;
                        if !text[inner.clone()].trim().is_empty() {
                            return Some(inner);
                        }
                        break;
                    }
                    depth -= 1;
                }
            }
        }
    }
    None
}

/// Byte range of the ICU word around `index` (`None` when ICU is unavailable).
fn icu_word_range(text: &str, index: usize) -> Option<Range<usize>> {
    type Open =
        unsafe extern "C" fn(i32, *const i8, *const u16, i32, *mut i32) -> *mut core::ffi::c_void;
    type Step = unsafe extern "C" fn(*mut core::ffi::c_void, i32) -> i32;
    type Close = unsafe extern "C" fn(*mut core::ffi::c_void);
    struct Api {
        open: Open,
        preceding: Step,
        following: Step,
        close: Close,
    }
    static API: std::sync::OnceLock<Option<Api>> = std::sync::OnceLock::new();
    let api = API.get_or_init(|| unsafe {
        let name: Vec<u16> = "icu.dll".encode_utf16().chain(Some(0)).collect();
        let module = LoadLibraryW(PCWSTR(name.as_ptr())).ok()?;
        let load = |name: &str| -> Option<*const core::ffi::c_void> {
            let wide: Vec<u8> = name.bytes().chain(Some(0)).collect();
            GetProcAddress(module, windows::core::PCSTR(wide.as_ptr())).map(|f| f as *const _)
        };
        Some(Api {
            open: std::mem::transmute::<*const core::ffi::c_void, Open>(load("ubrk_open")?),
            preceding: std::mem::transmute::<*const core::ffi::c_void, Step>(load(
                "ubrk_preceding",
            )?),
            following: std::mem::transmute::<*const core::ffi::c_void, Step>(load(
                "ubrk_following",
            )?),
            close: std::mem::transmute::<*const core::ffi::c_void, Close>(load("ubrk_close")?),
        })
    });
    let api = api.as_ref()?;
    let wide: Vec<u16> = text.encode_utf16().collect();
    // byte offset -> UTF-16 offset
    let units = text[..boundary(text, index)]
        .chars()
        .map(char::len_utf16)
        .sum::<usize>() as i32;
    unsafe {
        let mut status = 0i32;
        let bi = (api.open)(
            1, /* UBRK_WORD */
            std::ptr::null(),
            wide.as_ptr(),
            wide.len() as i32,
            &mut status,
        );
        if bi.is_null() || status > 0 {
            return None;
        }
        let mut start = (api.preceding)(bi, units + 1);
        let mut end = (api.following)(bi, units);
        if end <= start {
            start = (api.preceding)(bi, units);
            end = (api.following)(bi, units + 1);
        }
        // Double-clicking on whitespace selects the preceding word, as editors do.
        if start >= 0 && end > start && {
            let (a, b) = (
                utf16_to_bytes(text, start as usize),
                utf16_to_bytes(text, end as usize),
            );
            text[a..b].trim().is_empty()
        } {
            let prev_end = start;
            let prev_start = (api.preceding)(bi, start);
            if prev_start >= 0 && prev_end > prev_start {
                start = prev_start;
                end = prev_end;
            }
        }
        (api.close)(bi);
        if start < 0 || end <= start {
            return None;
        }
        let (start, end) = (start as usize, end as usize);
        if end > wide.len() {
            return None;
        }
        Some(utf16_to_bytes(text, start)..utf16_to_bytes(text, end))
    }
}

fn utf16_to_bytes(text: &str, units: usize) -> usize {
    let mut seen = 0usize;
    for (b, c) in text.char_indices() {
        if seen >= units {
            return b;
        }
        seen += c.len_utf16();
    }
    text.len()
}

/// Byte range of the word around `index` for double-click selection.
pub fn word_range(text: &str, index: usize) -> Range<usize> {
    if let Some(range) = pair_range(text, index) {
        return range;
    }
    if let Some(range) = icu_word_range(text, index) {
        return range;
    }
    crate::selection::simple_word_range(text, index)
}

/// True when the system ICU break iterator could be loaded (used by the tests).
#[cfg(test)]
fn icu_available() -> bool {
    icu_word_range("probe", 0).is_some()
}

#[cfg(test)]
mod tests {
    use super::*;

    fn at(text: &str, needle: &str, delta: usize) -> usize {
        text.find(needle).unwrap() + delta
    }

    #[test]
    fn quotes_select_their_content() {
        let t = "他说\"预览自身 Space 关闭\"就行了。";
        assert_eq!(&t[word_range(t, at(t, "自身", 0))], "预览自身 Space 关闭");
        let c = "call foo_bar(arg1, \"some string\") # comment";
        assert_eq!(&c[word_range(c, at(c, "some", 1))], "some string");
        assert_eq!(&c[word_range(c, at(c, "arg1", 1))], "arg1");
        // brackets are not pairs: the word under the cursor wins
        let m = "双击【已完成·有待审查】标记";
        assert_eq!(&m[word_range(m, at(m, "有待", 0))], "有待");
        // single quotes and backticks are not pairs: apostrophes must not create spans
        let a = "it's a 'quoted' word";
        assert_eq!(&a[word_range(a, at(a, "quoted", 2))], "quoted");
        let d = "don't stop, it's fine";
        assert_eq!(&d[word_range(d, at(d, "don't", 2))], "don't");
        let b = "use `code here` inline";
        assert_eq!(&b[word_range(b, at(b, "code", 1))], "code");
        // a pair that spans lines is not a pair
        let n = "open \"line one\nline two\" close";
        let r = word_range(n, at(n, "line one", 2));
        assert_eq!(&n[r], "line");
    }

    #[test]
    fn icu_segments_real_words_when_available() {
        if !icu_available() {
            return;
        }
        let t = ": 两个相关症状已修复。①新文件被误当关闭、窗口缓存画面重显：wndproc.rs 区分";
        assert_eq!(&t[word_range(t, at(t, "修复", 0))], "修复");
        assert_eq!(&t[word_range(t, at(t, "窗口", 0))], "窗口");
        assert_eq!(&t[word_range(t, at(t, "wndproc.rs", 2))], "wndproc.rs");
        let e = "call foo_bar(arg1) # comment";
        assert_eq!(&e[word_range(e, at(e, "foo_bar", 2))], "foo_bar");
        assert_eq!(&e[word_range(e, at(e, "comment", 2))], "comment");
        let v = "version v1.2.3 released";
        assert_eq!(&v[word_range(v, at(v, "v1.2.3", 2))], "v1.2.3");
    }

    #[test]
    fn falls_back_without_pairs() {
        let t = "plain words here";
        assert_eq!(&t[word_range(t, at(t, "words", 1))], "words");
        assert_eq!(&t[word_range(t, at(t, "plain", 5))], "plain");
    }
}
