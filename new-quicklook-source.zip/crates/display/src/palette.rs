//! Code roles share a restrained palette; narrative Markdown keeps its existing
//! foreground, heading, quote, link and inline-code colors and fonts.
use quicklook_core::Style;
pub(crate) fn color(style: Style) -> Option<(u8, u8, u8)> {
    Some(match style {
        Style::Keyword => (183, 168, 217), // lavender: control/declaration words
        Style::String => (168, 197, 155),  // sage: literal text
        Style::Comment => (142, 154, 171), // cool gray, readable but subordinate
        Style::Number | Style::Constant => (210, 183, 149), // muted warm values
        Style::Type | Style::Tag => (157, 201, 198), // subdued teal structure
        Style::Function => (175, 199, 228), // soft blue callable names
        Style::Property | Style::Attribute | Style::Key => (188, 201, 216),
        Style::Added => (170, 199, 167),
        Style::Removed => (214, 170, 169),
        Style::Meta => (161, 175, 191),
        Style::Link => (117, 192, 255),
        Style::Code => (175, 204, 232),
        _ => return None,
    })
}
#[cfg(test)]
mod tests {
    use super::*;
    fn luminance(rgb: (u8, u8, u8)) -> f64 {
        fn linear(c: u8) -> f64 {
            let c = f64::from(c) / 255.0;
            if c <= 0.04045 {
                c / 12.92
            } else {
                ((c + 0.055) / 1.055).powf(2.4)
            }
        }
        0.2126 * linear(rgb.0) + 0.7152 * linear(rgb.1) + 0.0722 * linear(rgb.2)
    }
    #[test]
    fn all_code_roles_remain_readable_on_both_dark_surfaces() {
        for style in [
            Style::Keyword,
            Style::String,
            Style::Comment,
            Style::Number,
            Style::Type,
            Style::Function,
            Style::Constant,
            Style::Property,
            Style::Attribute,
            Style::Tag,
            Style::Key,
            Style::Added,
            Style::Removed,
            Style::Meta,
        ] {
            for background in [(22, 25, 33), (29, 33, 43)] {
                let contrast =
                    (luminance(color(style).unwrap()) + 0.05) / (luminance(background) + 0.05);
                assert!(contrast >= 4.5, "{style:?}: {contrast:.2}");
            }
        }
        assert_eq!(color(Style::Normal), None);
        assert_eq!(color(Style::Bold), None);
        assert_eq!(color(Style::Emphasis), None);
    }
}
