use windows::{Win32::Graphics::Gdi::*, core::PCWSTR};
pub struct Fonts {
    pub ui: HFONT,
    pub bold: HFONT,
    pub italic: HFONT,
    pub mono: HFONT,
    pub headings: [HFONT; 3],
}
impl Fonts {
    pub fn new(dpi: u32) -> Self {
        fn font(size: i32, weight: i32, italic: bool, face: &str, dpi: u32) -> HFONT {
            let face: Vec<u16> = face.encode_utf16().chain(Some(0)).collect();
            unsafe {
                CreateFontW(
                    -((size as u32 * dpi / 96) as i32),
                    0,
                    0,
                    0,
                    weight,
                    u32::from(italic),
                    0,
                    0,
                    DEFAULT_CHARSET,
                    OUT_DEFAULT_PRECIS,
                    CLIP_DEFAULT_PRECIS,
                    CLEARTYPE_QUALITY,
                    DEFAULT_PITCH.0 as u32,
                    PCWSTR(face.as_ptr()),
                )
            }
        }
        Self {
            ui: font(16, 400, false, "Segoe UI", dpi),
            bold: font(16, 700, false, "Segoe UI", dpi),
            italic: font(16, 400, true, "Segoe UI", dpi),
            mono: font(15, 400, false, "Cascadia Mono", dpi),
            headings: [
                font(30, 700, false, "Segoe UI", dpi),
                font(24, 700, false, "Segoe UI", dpi),
                font(20, 700, false, "Segoe UI", dpi),
            ],
        }
    }
}
impl Drop for Fonts {
    fn drop(&mut self) {
        unsafe {
            for font in [
                self.ui,
                self.bold,
                self.italic,
                self.mono,
                self.headings[0],
                self.headings[1],
                self.headings[2],
            ] {
                let _ = DeleteObject(font.into());
            }
        }
    }
}
