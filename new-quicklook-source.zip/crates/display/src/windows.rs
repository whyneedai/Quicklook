//! Stable Windows presentation facade; implementation lives in sibling modules.
pub use crate::drawing::{configure_window, extend_layout, paint};
pub use crate::view::{ScrollFrame, ViewState};
