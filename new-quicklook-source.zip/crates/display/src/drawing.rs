use crate::{
    layout::Layout,
    view::{Hit, ViewState},
};
use quicklook_core::Output as Content;
use std::ops::Range;
use windows::Win32::{Foundation::*, Graphics::Gdi::*, UI::WindowsAndMessaging::SetTimer};
pub(crate) fn rgb(r: u8, g: u8, b: u8) -> COLORREF {
    COLORREF(u32::from(r) | (u32::from(g) << 8) | (u32::from(b) << 16))
}
pub(crate) fn fill(dc: HDC, r: RECT, color: COLORREF) {
    unsafe {
        let brush = CreateSolidBrush(color);
        FillRect(dc, &r, brush);
        let _ = DeleteObject(brush.into());
    }
}
pub(crate) fn text(dc: HDC, x: i32, y: i32, s: &str, font: HFONT, color: COLORREF) -> i32 {
    let b: Vec<u16> = s.encode_utf16().collect();
    unsafe {
        let old = SelectObject(dc, font.into());
        SetTextColor(dc, color);
        let mut size = SIZE::default();
        let _ = GetTextExtentPoint32W(dc, &b, &mut size);
        let _ = TextOutW(dc, x, y, &b);
        SelectObject(dc, old);
        size.cx
    }
}
pub(crate) fn measure(dc: HDC, s: &str, font: HFONT) -> i32 {
    let b: Vec<u16> = s.encode_utf16().collect();
    unsafe {
        let old = SelectObject(dc, font.into());
        let mut z = SIZE::default();
        let _ = GetTextExtentPoint32W(dc, &b, &mut z);
        SelectObject(dc, old);
        z.cx
    }
}
/// Reuse the compatible surface between paints; release on close or resize.
pub(crate) struct BackBuffer {
    pub dc: HDC,
    bitmap: HBITMAP,
    old: HGDIOBJ,
    width: i32,
    height: i32,
}
impl BackBuffer {
    fn new(target: HDC, width: i32, height: i32) -> Self {
        unsafe {
            let dc = CreateCompatibleDC(Some(target));
            let bitmap = CreateCompatibleBitmap(target, width, height);
            let old = SelectObject(dc, bitmap.into());
            Self {
                dc,
                bitmap,
                old,
                width,
                height,
            }
        }
    }
}
impl Drop for BackBuffer {
    fn drop(&mut self) {
        unsafe {
            SelectObject(self.dc, self.old);
            let _ = DeleteObject(self.bitmap.into());
            let _ = DeleteDC(self.dc);
        }
    }
}
/// Lay out more of the document, bounded by time and lines. Returns true when the
/// whole document is laid out. Called from the continuation timer and from `paint`
/// when the viewport catches up with the laid-out content.
pub fn extend_layout(state: &mut ViewState, max_ms: f64, max_lines: usize) -> bool {
    let (Some(Content::Text(doc)), Some(layout)) = (&state.content, state.layout.as_mut()) else {
        return true;
    };
    if layout.complete {
        return true;
    }
    let shared = state.back_buffer.as_ref().map(|b| b.dc);
    let temp = if shared.is_none() {
        Some(unsafe { CreateCompatibleDC(None) })
    } else {
        None
    };
    let dc = shared.or(temp).unwrap();
    let started = std::time::Instant::now();
    let complete = layout.extend(dc, doc, &state.fonts, state.dpi, max_ms, max_lines);
    let (measure_ms, extensions) = (layout.measure_ms, layout.extensions);
    state.layout_ms += started.elapsed().as_secs_f64() * 1000.0;
    state.layout_measure_ms = measure_ms;
    state.layout_extensions = extensions;
    state.layout_complete = complete;
    if let Some(dc) = temp {
        unsafe {
            let _ = DeleteDC(dc);
        }
    }
    complete
}

pub fn paint(hwnd: HWND, state: &mut ViewState) {
    let started = std::time::Instant::now();
    unsafe {
        let mut ps = PAINTSTRUCT::default();
        let target = BeginPaint(hwnd, &mut ps);
        let mut r = RECT::default();
        let _ = windows::Win32::UI::WindowsAndMessaging::GetClientRect(hwnd, &mut r);
        let (w, h) = (r.right.max(1), r.bottom.max(1));
        if state
            .back_buffer
            .as_ref()
            .is_none_or(|b| b.width != w || b.height != h)
        {
            state.back_buffer = Some(BackBuffer::new(target, w, h));
        }
        let dc = state.back_buffer.as_ref().unwrap().dc;
        SetBkMode(dc, TRANSPARENT);
        fill(dc, r, rgb(22, 25, 33));
        let dpi = state.dpi;
        let scale = |v: i32| v * dpi as i32 / 96;
        let bar = scale(64);
        let foot = scale(36);
        let margin = scale(24);
        fill(
            dc,
            RECT {
                left: 0,
                top: 0,
                right: w,
                bottom: bar,
            },
            rgb(29, 33, 43),
        );
        fill(
            dc,
            RECT {
                left: 0,
                top: bar - 2,
                right: w,
                bottom: bar,
            },
            rgb(75, 145, 224),
        );
        let title = &state.title;
        let label: String = title
            .chars()
            .take(((w - scale(240)) / scale(9)).max(8) as usize)
            .collect();
        text(
            dc,
            margin,
            scale(12),
            &label,
            state.fonts.bold,
            rgb(231, 235, 245),
        );
        let kind = if state.type_label.is_empty() {
            "NEW-QUICKLOOK".to_string()
        } else {
            format!(
                "{}  ·  {}{}",
                state.type_label,
                state.mode.label(),
                if state.modes.len() > 1 { "  [M]" } else { "" }
            )
        };
        text(
            dc,
            margin,
            scale(36),
            &kind,
            state.fonts.mono,
            rgb(135, 153, 180),
        );
        text(
            dc,
            w - scale(150),
            scale(22),
            if state.pinned { "PIN ON" } else { "PIN" },
            state.fonts.ui,
            if state.pinned {
                rgb(119, 195, 255)
            } else {
                rgb(164, 178, 200)
            },
        );
        text(
            dc,
            w - scale(40),
            scale(20),
            "×",
            state.fonts.bold,
            rgb(211, 222, 237),
        );
        state.hits.clear();
        let selected = state.selection.range();
        let truncated = matches!(&state.content,Some(Content::Text(doc)) if doc.truncated);
        let top = bar + scale(20) + if truncated { scale(30) } else { 0 };
        let bottom = h - foot;
        let viewport = (bottom - top).max(1);
        let saved = SaveDC(dc);
        let _ = IntersectClipRect(dc, 0, bar, w, bottom);
        if truncated {
            text(
                dc,
                margin,
                bar + scale(12),
                "Preview truncated · open the file to read the rest",
                state.fonts.ui,
                rgb(238, 179, 123),
            );
        }
        let mut content_height = 0;
        match &state.content {
            None => {
                text(
                    dc,
                    margin,
                    top,
                    "Loading preview…",
                    state.fonts.ui,
                    rgb(158, 180, 208),
                );
            }
            Some(Content::Error(e)) => {
                text(
                    dc,
                    margin,
                    top,
                    "Preview unavailable",
                    state.fonts.headings[1],
                    rgb(238, 179, 123),
                );
                for (i, part) in e.as_bytes().chunks(70).enumerate() {
                    text(
                        dc,
                        margin,
                        top + scale(50 + i as i32 * 24),
                        &String::from_utf8_lossy(part),
                        state.fonts.ui,
                        rgb(206, 213, 226),
                    );
                }
            }
            Some(content) if content.image().is_some() => {
                let image = content.image().unwrap();
                let (dw, dh) = quicklook_core::fit_size(
                    image.width,
                    image.height,
                    (w - 2 * margin).max(1) as u32,
                    (bottom - top - scale(12)).max(1) as u32,
                );
                state.canvas.clamp(
                    (f64::from(dw), f64::from(dh)),
                    (f64::from(w - 2 * margin), f64::from(bottom - top)),
                );
                let dw = (f64::from(dw) * state.canvas.zoom).round() as i32;
                let dh = (f64::from(dh) * state.canvas.zoom).round() as i32;
                let x = (w - dw) / 2 + state.canvas.offset.0.round() as i32;
                let y = top + (bottom - top - dh) / 2 + state.canvas.offset.1.round() as i32;
                let bmi = BITMAPINFO {
                    bmiHeader: BITMAPINFOHEADER {
                        biSize: std::mem::size_of::<BITMAPINFOHEADER>() as u32,
                        biWidth: image.width as i32,
                        biHeight: -(image.height as i32),
                        biPlanes: 1,
                        biBitCount: 32,
                        biCompression: BI_RGB.0,
                        ..Default::default()
                    },
                    ..Default::default()
                };
                SetStretchBltMode(dc, HALFTONE);
                let _ = SetBrushOrgEx(dc, 0, 0, None);
                StretchDIBits(
                    dc,
                    x,
                    y,
                    dw,
                    dh,
                    0,
                    0,
                    image.width as i32,
                    image.height as i32,
                    Some(
                        image
                            .pixels_at(state.animation_started.elapsed().as_millis() as u64)
                            .as_ptr()
                            .cast(),
                    ),
                    &bmi,
                    DIB_RGB_COLORS,
                    SRCCOPY,
                );
            }
            Some(Content::Image(_) | Content::Pages(_)) => {
                text(
                    dc,
                    margin,
                    top,
                    "Loading page…",
                    state.fonts.ui,
                    rgb(158, 180, 208),
                );
            }
            Some(Content::Text(doc)) => {
                if state.layout.as_ref().is_none_or(|c| c.width != w) {
                    let t = std::time::Instant::now();
                    // First frame lays out one screen plus half a screen; `extend_layout`
                    // finishes the rest in the background, so the first frame costs one
                    // screen instead of the whole file - for every language, with no
                    // approximation of the text metrics.
                    // Diagnostic switch: QUICKLOOK_FULL_LAYOUT=1 lays out everything on
                    // the first frame (used to compare incremental vs one-shot layout).
                    state.layout = Some(if std::env::var_os("QUICKLOOK_FULL_LAYOUT").is_some() {
                        Layout::build(dc, doc, &state.fonts, state.dpi, w, None)
                    } else {
                        // ~20ms of layout in the first frame, then the continuation timer.
                        Layout::build_within(dc, doc, &state.fonts, state.dpi, w, 20.0, 400)
                    });
                    state.layout_complete =
                        state.layout.as_ref().map(|l| l.complete).unwrap_or(true);
                    state.layout_extensions = 0;
                    state.layout_ms = t.elapsed().as_secs_f64() * 1000.0;
                    state.layout_measure_ms =
                        state.layout.as_ref().map(|l| l.measure_ms).unwrap_or(0.0);
                    state.layout_builds += 1;
                    state.scroll_frames.clear();
                }
                // Catch up when the viewport nears the end of what is laid out, so
                // scrolling does not sit on a blank area.
                let near_end = state
                    .layout
                    .as_ref()
                    .is_some_and(|l| !l.complete && state.scroll + viewport + 60 > l.height);
                if near_end {
                    extend_layout(state, 8.0, 4096);
                }
                let layout = state.layout.as_ref().unwrap();
                content_height = layout.height;
                state.max_scroll = (content_height - (bottom - top) + scale(12)).max(0);
                // Until extension finishes, height is only a lower bound. Keep the
                // user's intent through width/DPI rebuilds; clamp this paint locally.
                if layout.complete {
                    state.scroll = state.scroll.clamp(0, state.max_scroll);
                }
                let draw_scroll = state.scroll.clamp(0, state.max_scroll);
                if state.show_status {
                    let frame = crate::view::ScrollFrame {
                        width: w,
                        complete: layout.complete,
                        scroll: state.scroll,
                        draw_scroll,
                        max_scroll: state.max_scroll,
                    };
                    if state.scroll_frames.len() < 32 {
                        state.scroll_frames.push(frame);
                    } else if frame.complete {
                        // Keep the earliest partial frames and the final complete state.
                        *state.scroll_frames.last_mut().unwrap() = frame;
                    }
                }
                let shift = top - draw_scroll;
                let _ = IntersectClipRect(dc, 0, top, w, bottom);
                let visible = crate::layout::visible_range(
                    &layout.tops,
                    layout.max_height,
                    top - shift,
                    bottom - shift,
                );
                state.visible_runs = 0;
                let draw_started = std::time::Instant::now();
                for run in &layout.runs[visible] {
                    if run.hit.rect.bottom + shift <= top {
                        continue;
                    }
                    let mut hit = run.hit.clone();
                    hit.rect.top += shift;
                    hit.rect.bottom += shift;
                    if let Some(bitmap) = &run.math {
                        let bmi = BITMAPINFO {
                            bmiHeader: BITMAPINFOHEADER {
                                biSize: std::mem::size_of::<BITMAPINFOHEADER>() as u32,
                                biWidth: bitmap.width as i32,
                                biHeight: -(bitmap.height as i32),
                                biPlanes: 1,
                                biBitCount: 32,
                                biCompression: BI_RGB.0,
                                ..Default::default()
                            },
                            ..Default::default()
                        };
                        SetStretchBltMode(dc, HALFTONE);
                        StretchDIBits(
                            dc,
                            hit.rect.left,
                            hit.rect.top,
                            hit.rect.right - hit.rect.left,
                            hit.rect.bottom - hit.rect.top,
                            0,
                            0,
                            bitmap.width as i32,
                            bitmap.height as i32,
                            Some(bitmap.bgra.as_ptr().cast()),
                            &bmi,
                            DIB_RGB_COLORS,
                            SRCCOPY,
                        );
                        if selected.start < hit.range.end && selected.end > hit.range.start {
                            fill(
                                dc,
                                RECT {
                                    left: hit.rect.left,
                                    top: hit.rect.bottom - 2,
                                    right: hit.rect.right,
                                    bottom: hit.rect.bottom,
                                },
                                rgb(75, 145, 224),
                            );
                        }
                        state.hits.push(hit);
                    } else if run.decoration {
                        fill(dc, hit.rect, run.color);
                    } else {
                        if !hit.range.is_empty() {
                            draw_selection(dc, &run.value, &hit, &selected);
                        }
                        let clipped = run.clip_right.map(|right| {
                            let saved = SaveDC(dc);
                            let _ = IntersectClipRect(
                                dc,
                                hit.rect.left,
                                hit.rect.top,
                                right,
                                hit.rect.bottom,
                            );
                            saved
                        });
                        text(
                            dc,
                            hit.rect.left,
                            hit.rect.top,
                            &run.value,
                            hit.font,
                            run.color,
                        );
                        if let Some(saved) = clipped {
                            let _ = RestoreDC(dc, saved);
                        }
                        if let Some(right) = run.clip_right {
                            hit.rect.right = hit.rect.right.min(right);
                        }
                        if !hit.range.is_empty() {
                            state.hits.push(hit);
                        }
                    }
                    state.visible_runs += 1;
                }
                state.draw_ms = draw_started.elapsed().as_secs_f64() * 1000.0;
            }
        }
        let _ = RestoreDC(dc, saved);
        state.max_scroll = (content_height - (bottom - top) + scale(12)).max(0);
        fill(
            dc,
            RECT {
                left: 0,
                top: bottom,
                right: w,
                bottom: h,
            },
            rgb(29, 33, 43),
        );
        let mut status = match &state.content {
            Some(Content::Text(d)) => format!(
                "{} blocks{}",
                d.lines.len(),
                if d.truncated {
                    " · truncated at preview limit"
                } else {
                    ""
                }
            ),
            Some(Content::Image(i)) => format!(
                "{} × {}  →  {} × {}",
                i.original.0, i.original.1, i.width, i.height
            ),
            _ => String::new(),
        };
        if let Some(Content::Pages(p)) = &state.content {
            status = format!(
                "Page {} / {}   ·   Wheel: pages   Ctrl+wheel: zoom",
                p.index + 1,
                p.count
            );
        }
        if let Some(ms) = state.first_paint_ms {
            status.push_str(&format!("   ·   {ms:.1} ms"));
        }
        if state.show_status || matches!(state.content, Some(Content::Pages(_))) {
            text(
                dc,
                margin,
                bottom + scale(8),
                &status,
                state.fonts.mono,
                rgb(135, 153, 180),
            );
        }
        if w > scale(680) {
            text(
                dc,
                w - scale(255),
                bottom + scale(8),
                "P  pin    Space / Esc  close",
                state.fonts.ui,
                rgb(135, 153, 180),
            );
        }
        if let Some(frame) = state.scrollbar_frame(w, h)
            && let Some(metrics) = state.scrollbar_metrics(w, h)
        {
            let color = if state.scrollbar_drag {
                rgb(120, 152, 192)
            } else if state.scrollbar_hover {
                rgb(101, 132, 174)
            } else {
                rgb(77, 100, 132)
            };
            fill(
                dc,
                RECT {
                    left: frame.left,
                    top: frame.top + metrics.thumb_pos,
                    right: frame.left + frame.width,
                    bottom: frame.top + metrics.thumb_pos + metrics.thumb_len,
                },
                color,
            );
        }
        let _ = BitBlt(target, 0, 0, w, h, Some(dc), 0, 0, SRCCOPY);
        let _ = EndPaint(hwnd, &ps);
        if state
            .layout
            .as_ref()
            .is_some_and(|l| !l.complete && matches!(state.content, Some(Content::Text(_))))
        {
            // 15ms timer with a small time budget per tick: the document finishes in
            // the background without saturating the UI thread (keeps input responsive).
            SetTimer(Some(hwnd), 5, 15, None);
        }
        state.paint_ms = started.elapsed().as_secs_f64() * 1000.0;
    }
}

/// DWM appearance belongs to presentation; lifecycle/activation remains in app.
pub fn configure_window(hwnd: HWND) {
    use windows::Win32::Graphics::Dwm::*;
    unsafe {
        let corners = DWMWCP_ROUND;
        let _ = DwmSetWindowAttribute(
            hwnd,
            DWMWA_WINDOW_CORNER_PREFERENCE,
            (&corners as *const DWM_WINDOW_CORNER_PREFERENCE).cast(),
            std::mem::size_of_val(&corners) as u32,
        );
        // Skip the DWM show/hide transition: the fade alone costs ~10ms of the
        // first-frame latency (measured), and the preview is meant to appear instantly.
        let no_transitions = 1i32;
        let _ = DwmSetWindowAttribute(
            hwnd,
            DWMWA_TRANSITIONS_FORCEDISABLED,
            (&no_transitions as *const i32).cast(),
            4,
        );
        let dark = 1i32;
        let _ = DwmSetWindowAttribute(
            hwnd,
            DWMWA_USE_IMMERSIVE_DARK_MODE,
            (&dark as *const i32).cast(),
            4,
        );
    }
}

pub(crate) fn draw_selection(dc: HDC, value: &str, hit: &Hit, selection: &Range<usize>) {
    let x = hit.rect.left;
    let y = hit.rect.top;
    let height = hit.rect.bottom - y;
    let font = hit.font;
    let offset = hit.range.start;
    let start = selection.start.max(offset);
    let end = selection.end.min(offset + value.len());
    if start < end {
        let a = start - offset;
        let b = end - offset;
        if value.is_char_boundary(a) && value.is_char_boundary(b) {
            let left = x + measure(dc, &value[..a], font);
            let width = measure(dc, &value[a..b], font);
            fill(
                dc,
                RECT {
                    left,
                    top: y,
                    right: left + width,
                    bottom: y + height,
                },
                rgb(49, 76, 116),
            );
        }
    }
}
