#![cfg(all(windows, feature = "worker-tests"))]
#[path = "../src/native/worker.rs"]
mod runtime;
use quicklook_core::worker::Spec;
use std::{
    path::PathBuf,
    time::{Duration, Instant},
};
const SPEC: Spec = Spec {
    id: 42,
    exe: "worker-probe.exe",
    memory_bytes: 64 * 1024 * 1024,
    timeout_ms: 500,
    idle_ms: 50,
    cache_bytes: 1024,
    request_bytes: 8 * 1024 * 1024,
    response_bytes: 1024,
};
fn client() -> runtime::Client {
    runtime::Client::with_path(SPEC, PathBuf::from(env!("CARGO_BIN_EXE_worker-probe")))
}
#[test]
fn second_spec_reuses_expires_and_recovers() {
    let mut c = client();
    assert!(!c.available());
    let a = c.request(9, vec![0], || false).unwrap();
    assert_eq!(c.request(10, vec![0], || false).unwrap(), a);
    std::thread::sleep(Duration::from_millis(70));
    assert!(c.expire());
    assert!(!c.available());
    let b = c.request(11, vec![0], || false).unwrap();
    assert_ne!(a, b);
    assert!(c.request(12, vec![2], || false).is_err());
    assert!(!c.available());
    assert!(c.request(13, vec![0], || false).is_ok());
    c.reset();
}
#[test]
fn timeout_cancel_and_protocol_faults_kill_and_restart() {
    let mut c = client();
    for mode in [1, 3, 4] {
        let start = Instant::now();
        assert!(c.request(1, vec![mode], || false).is_err());
        assert!(start.elapsed() < Duration::from_secs(3));
        assert!(!c.available());
        assert!(c.request(2, vec![0], || false).is_ok());
    }
    let start = Instant::now();
    assert!(
        c.request(3, vec![1], || start.elapsed() > Duration::from_millis(25))
            .is_err()
    );
    assert!(!c.available());
    assert!(c.request(4, vec![0], || false).is_ok());
    c.reset();
}
#[test]
fn missing_wrong_spec_and_local_limits_are_safe() {
    let mut missing = runtime::Client::new(SPEC);
    assert!(missing.request(1, vec![0], || false).is_err());
    let mut spec = SPEC;
    spec.id = 43;
    let mut wrong =
        runtime::Client::with_path(spec, PathBuf::from(env!("CARGO_BIN_EXE_worker-probe")));
    assert!(wrong.request(1, vec![0], || false).is_err());
    assert!(!wrong.available());
    let mut c = client();
    assert!(
        c.request(1, vec![0; SPEC.request_bytes + 1], || false)
            .is_err()
    );
    assert!(!c.available());
}
#[test]
fn blocked_large_pipe_write_is_inside_timeout() {
    let mut c = client();
    c.request(1, vec![6], || false).unwrap();
    let start = Instant::now();
    assert!(c.request(2, vec![0; SPEC.request_bytes], || false).is_err());
    assert!(start.elapsed() < Duration::from_secs(3));
    assert!(!c.available());
    assert!(c.request(3, vec![0], || false).is_ok());
    c.reset();
}
