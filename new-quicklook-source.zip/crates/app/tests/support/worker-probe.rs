//! Test-only process. Never delivered or listed in the production inventory.
use quicklook_core::worker::{self, Spec};
pub const SPEC: Spec = Spec {
    id: 42,
    exe: "worker-probe.exe",
    memory_bytes: 64 * 1024 * 1024,
    timeout_ms: 250,
    idle_ms: 50,
    cache_bytes: 1024,
    request_bytes: 8 * 1024 * 1024,
    response_bytes: 1024,
};
fn main() {
    let mut r = std::io::stdin().lock();
    let mut w = std::io::stdout().lock();
    let _ = worker::serve(&mut r, &mut w, SPEC, |f| {
        match f.payload.first() {
            Some(1) => std::thread::sleep(std::time::Duration::from_secs(60)),
            Some(2) => std::process::exit(9),
            Some(3) => {
                use std::io::Write;
                let _ = w_fault(f);
                return Err(worker::invalid());
                fn w_fault(f: &worker::Frame) -> std::io::Result<()> {
                    let mut out = std::io::stdout().lock();
                    let mut bytes = Vec::new();
                    worker::write(
                        &mut bytes,
                        &worker::Frame {
                            message: worker::Message::Response,
                            id: f.id + 1,
                            generation: f.generation,
                            payload: vec![],
                        },
                        1024,
                    )?;
                    out.write_all(&bytes)
                }
            }
            Some(4) => return Ok(vec![0; 2048]),
            Some(6) => {
                let reply = worker::Frame {
                    message: worker::Message::Response,
                    id: f.id,
                    generation: f.generation,
                    payload: std::process::id().to_le_bytes().to_vec(),
                };
                worker::write(&mut std::io::stdout().lock(), &reply, 1024)?;
                std::thread::sleep(std::time::Duration::from_secs(60));
            }
            _ => {}
        }
        Ok(std::process::id().to_le_bytes().to_vec())
    });
}
