#![cfg(all(windows, feature = "worker-tests"))]
#[path = "../src/native/worker.rs"]
mod runtime;
use quicklook_core::pages::{self, PDF_WORKER, Request};
use std::{
    path::PathBuf,
    time::{Duration, Instant},
};
fn client() -> runtime::Client {
    runtime::Client::with_path(PDF_WORKER, PathBuf::from(env!("CARGO_BIN_EXE_pdf-worker")))
}
fn fixture(name: &str) -> Vec<u8> {
    std::fs::read(
        PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .join("../../samples/pdf")
            .join(name),
    )
    .unwrap()
}
#[test]
fn system_pdf_pages_errors_and_crash_recovery() {
    let mut c = client();
    let source = fixture("01-pages.pdf");
    assert!(!c.available());
    let result = c
        .request(
            10,
            Request {
                source: Some(&source),
                index: 0,
                bounds: (900, 900),
            }
            .encode()
            .unwrap(),
            || false,
        )
        .unwrap();
    let first = pages::decode(&result).unwrap().unwrap();
    assert_eq!(first.count, 3);
    assert_eq!(first.size, (675, 900));
    assert_eq!(
        (
            u32::from_be_bytes(first.image[16..20].try_into().unwrap()),
            u32::from_be_bytes(first.image[20..24].try_into().unwrap())
        ),
        first.size
    );
    assert!(first.image.starts_with(b"\x89PNG\r\n\x1a\n"));
    let result = c
        .request(
            11,
            Request {
                source: None,
                index: 1,
                bounds: (900, 900),
            }
            .encode()
            .unwrap(),
            || false,
        )
        .unwrap();
    let second = pages::decode(&result).unwrap().unwrap();
    assert_eq!(second.size, (900, 675));
    assert!(c.available());
    for name in ["broken.pdf", "password.pdf"] {
        let source = fixture(name);
        let result = c
            .request(
                12,
                Request {
                    source: Some(&source),
                    index: 0,
                    bounds: (900, 900),
                }
                .encode()
                .unwrap(),
                || false,
            )
            .unwrap();
        let error = pages::decode(&result).unwrap().err().unwrap();
        assert!(!error.is_empty());
        if name == "password.pdf" {
            assert!(error.contains("password"), "{error}");
        }
    }
    assert!(c.request(13, vec![0], || false).is_err());
    assert!(!c.available());
    assert!(
        c.request(
            14,
            Request {
                source: Some(&source),
                index: 2,
                bounds: (900, 900)
            }
            .encode()
            .unwrap(),
            || false
        )
        .is_ok()
    );
    c.reset();
}
#[test]
fn pdf_spec_missing_wrong_handshake_and_cancel_are_bounded() {
    let mut missing = runtime::Client::new(PDF_WORKER);
    assert!(missing.request(1, vec![0], || false).is_err());
    let mut wrong = runtime::Client::with_path(
        PDF_WORKER,
        PathBuf::from(env!("CARGO_BIN_EXE_worker-probe")),
    );
    assert!(wrong.request(2, vec![0], || false).is_err());
    assert!(!wrong.available());
    let source = fixture("01-pages.pdf");
    let mut c = client();
    let start = Instant::now();
    assert!(
        c.request(
            3,
            Request {
                source: Some(&source),
                index: 0,
                bounds: (900, 900)
            }
            .encode()
            .unwrap(),
            || true
        )
        .is_err()
    );
    assert!(!c.available());
    assert!(start.elapsed() < Duration::from_secs(1));
    assert!(
        c.request(
            4,
            Request {
                source: Some(&source),
                index: 0,
                bounds: (900, 900)
            }
            .encode()
            .unwrap(),
            || false
        )
        .is_ok()
    );
    std::thread::sleep(Duration::from_millis(5));
    c.touch();
    assert!(!c.expire());
    c.reset();
}
