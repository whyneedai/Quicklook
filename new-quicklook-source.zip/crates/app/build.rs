use std::{env, path::PathBuf, process::Command};
fn main() {
    println!("cargo:rerun-if-changed=assets/app.ico");
    println!("cargo:rerun-if-changed=assets/app.rc");
    println!("cargo:rerun-if-changed=assets/app.manifest");
    if env::var("CARGO_CFG_TARGET_OS").as_deref() != Ok("windows") {
        return;
    }
    let root = PathBuf::from(env::var_os("CARGO_MANIFEST_DIR").unwrap());
    let output = PathBuf::from(env::var_os("OUT_DIR").unwrap()).join("app.res");
    let status = Command::new("rc.exe")
        .arg("/nologo")
        .arg("/I")
        .arg(root.join("assets"))
        .arg("/fo")
        .arg(&output)
        .arg(root.join("assets/app.rc"))
        .status()
        .expect("Windows SDK rc.exe must be available; use scripts/cargo.cmd");
    assert!(status.success(), "Windows resource compilation failed");
    println!(
        "cargo:rustc-link-arg-bin=new-quicklook={}",
        output.display()
    );
}
