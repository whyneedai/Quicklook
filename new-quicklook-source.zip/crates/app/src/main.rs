#![cfg_attr(windows, windows_subsystem = "windows")]
#[cfg(windows)]
mod native;
mod worker_specs;
fn main() {
    let mut args = std::env::args_os().skip(1);
    if args.next().is_some_and(|s| s == "--worker-specs") {
        let result = args
            .next()
            .ok_or_else(|| std::io::Error::other("Missing inventory path"))
            .and_then(|p| worker_specs::export(std::path::Path::new(&p)));
        if result.is_err() {
            std::process::exit(1);
        }
        return;
    }
    #[cfg(windows)]
    native::run();
    #[cfg(not(windows))]
    eprintln!("new-quicklook requires Windows 11");
}
