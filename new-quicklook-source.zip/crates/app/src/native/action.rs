use super::*;
pub(super) fn invalidate(hwnd: HWND) {
    unsafe {
        let _ = InvalidateRect(Some(hwnd), None, false);
    }
}
pub(super) fn activate(hwnd: HWND) {
    unsafe {
        let t0 = Instant::now();
        let _ = ShowWindow(hwnd, SW_SHOW);
        let t1 = Instant::now();
        let _ = BringWindowToTop(hwnd);
        let t2 = Instant::now();
        let foreground_ok = SetForegroundWindow(hwnd).as_bool();
        let t3 = Instant::now();
        if !foreground_ok {
            let foreground = GetForegroundWindow();
            let target_thread = GetWindowThreadProcessId(foreground, None);
            let this_thread = GetCurrentThreadId();
            let attached = target_thread != this_thread
                && AttachThreadInput(this_thread, target_thread, true).as_bool();
            let _ = SetForegroundWindow(hwnd);
            if attached {
                let _ = AttachThreadInput(this_thread, target_thread, false);
            }
        }
        let t4 = Instant::now();
        let _ = SetActiveWindow(hwnd);
        let _ = SetFocus(Some(hwnd));
        let t5 = Instant::now();
        with_state(|s| {
            s.view.activate_show_ms = (t1 - t0).as_secs_f64() * 1000.0;
            s.view.activate_top_ms = (t2 - t1).as_secs_f64() * 1000.0;
            s.view.activate_fg_ms = (t3 - t2).as_secs_f64() * 1000.0;
            s.view.activate_fallback_ms = (t4 - t3).as_secs_f64() * 1000.0;
            s.view.activate_rest_ms = (t5 - t4).as_secs_f64() * 1000.0;
        });
    }
}
pub(super) fn preview(
    hwnd: HWND,
    path: PathBuf,
    anchor: Option<POINT>,
    started: Option<Instant>,
    mode: Option<PreviewMode>,
    keep_geometry: bool,
) {
    let now = started.unwrap_or_else(Instant::now);
    unsafe {
        // Opening a preview centres the window; arrow-key navigation keeps it put.
        if !keep_geometry {
            // Always place the window centred on the monitor the user is working on
            // (the monitor under the cursor / selection), sized relative to that monitor.
            let point = anchor.unwrap_or_else(|| {
                let mut cursor = POINT::default();
                let _ = GetCursorPos(&mut cursor);
                cursor
            });
            let monitor = MonitorFromPoint(point, MONITOR_DEFAULTTONEAREST);
            let mut info = MONITORINFO {
                cbSize: std::mem::size_of::<MONITORINFO>() as u32,
                ..Default::default()
            };
            let _ = GetMonitorInfoW(monitor, &mut info);
            let area = info.rcWork;
            let dpi = GetDpiForWindow(hwnd).max(96) as i32;
            let (w, h) = text_window_size(area, dpi, configured_base());
            let (x, y) = centred_in(area, w, h);
            let _ = SetWindowPos(hwnd, None, x, y, w, h, SWP_NOZORDER | SWP_NOACTIVATE);
        }
        let mut rect = RECT::default();
        let _ = GetClientRect(hwnd, &mut rect);
        let prep_ms = now.elapsed().as_secs_f64() * 1000.0;
        with_state(|s| {
            s.generation += 1;
            s.input_digest = file::InputDigest::default();
            s.view.scroll = 0;
            s.view.max_scroll = 0;
            s.view.replace_content(None);
            s.format = None;
            s.view.title = path
                .file_name()
                .map(|x| x.to_string_lossy().into_owned())
                .unwrap_or_else(|| "new-quicklook".into());
            s.view.type_label.clear();
            s.view.modes = &[];
            s.path = Some(path.clone());
            s.started = now;
            s.view.first_paint_ms = None;
            s.view.image_fit.clear();
            s.keep_geometry = keep_geometry;
            s.worker.request(Request {
                page: None,
                generation: s.generation,
                dpi: s.view.dpi,
                mode,
                path,
                bounds: (
                    (rect.right - 48).max(1) as u32,
                    (rect.bottom - 130).max(1) as u32,
                ),
            });
        });
        // Repaint the cleared model before ShowWindow can expose a cached surface.
        let rdw_started = Instant::now();
        let _ = RedrawWindow(Some(hwnd), None, None, RDW_INVALIDATE | RDW_UPDATENOW);
        let rdw_ms = rdw_started.elapsed().as_secs_f64() * 1000.0;
        let activate_started = Instant::now();
        // QuickLook-style: appear above everything but never steal the focus, so the
        // Explorer file list keeps handling Space/arrows itself.
        show_no_activate(hwnd);
        let activate_ms = activate_started.elapsed().as_secs_f64() * 1000.0;
        invalidate(hwnd);
        let show_ms = now.elapsed().as_secs_f64() * 1000.0;
        with_state(|s| {
            s.view.prep_ms = prep_ms;
            s.view.show_ms = show_ms;
            s.view.rdw_ms = rdw_ms;
            s.view.activate_ms = activate_ms;
            s.view.ready_ms = 0.0;
            s.view.paint_start_ms = 0.0;
        });
    }
}
/// Show (or raise) the preview without taking the focus away from Explorer. The file
/// list keeps the keyboard, so arrow keys keep moving Explorer's own selection and the
/// preview merely follows it.
pub(super) fn show_no_activate(hwnd: HWND) {
    unsafe {
        let _ = ShowWindow(hwnd, SW_SHOWNOACTIVATE);
        // Above every window, including other topmost ones, without staying on top -
        // and without activating, so Explorer keeps the keyboard.
        let _ = SetWindowPos(
            hwnd,
            Some(HWND_TOPMOST),
            0,
            0,
            0,
            0,
            SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE,
        );
        if !with_state(|s| s.view.pinned).unwrap_or(false) {
            let _ = SetWindowPos(
                hwnd,
                Some(HWND_NOTOPMOST),
                0,
                0,
                0,
                0,
                SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE,
            );
        }
    }
    overlays::suppress_existing(hwnd);
}

pub(super) fn hide(hwnd: HWND) {
    unsafe {
        let _ = KillTimer(Some(hwnd), 3);
        let _ = KillTimer(Some(hwnd), 5);
        let _ = KillTimer(Some(hwnd), 6);
    }
    EXPLORER.store(0, Ordering::Relaxed);
    EXPLORER_VIEW.store(0, Ordering::Relaxed);
    let standalone = with_state(|s| {
        s.generation += 1;
        s.view.replace_content(None);
        s.path = None;
        s.input_digest = file::InputDigest::default();
        s.worker.clear();
        s.navigation = None;
        s.standalone
    })
    .unwrap_or(false);
    unsafe {
        if standalone {
            let _ = DestroyWindow(hwnd);
        } else {
            let _ = ShowWindow(hwnd, SW_HIDE);
        }
    }
    overlays::restore(hwnd);
}
pub(super) fn switch_mode(hwnd: HWND) {
    let request = with_state(|s| {
        s.path.clone().zip(s.format).and_then(|(path, format)| {
            if format.modes.len() < 2 {
                return None;
            }
            let index = format
                .modes
                .iter()
                .position(|mode| *mode == s.view.mode)
                .unwrap_or(0);
            Some((path, format.modes[(index + 1) % format.modes.len()]))
        })
    })
    .flatten();
    if let Some((path, mode)) = request {
        preview(hwnd, path, None, None, Some(mode), true);
    }
}
pub(super) fn pin(hwnd: HWND) {
    let pinned = with_state(|s| {
        s.view.pinned = !s.view.pinned;
        s.view.pinned
    })
    .unwrap_or(false);
    unsafe {
        let _ = SetWindowPos(
            hwnd,
            Some(if pinned { HWND_TOPMOST } else { HWND_NOTOPMOST }),
            0,
            0,
            0,
            0,
            SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE,
        );
    }
    invalidate(hwnd);
}
pub(super) fn scroll(hwnd: HWND, delta: i32) {
    with_state(|s| {
        s.view.scroll = s
            .view
            .scroll
            .saturating_add(delta)
            .clamp(0, s.view.max_scroll)
    });
    invalidate(hwnd);
}
pub(super) fn track_leave(hwnd: HWND) {
    // Arrange to be told when the pointer leaves the window so the thumb
    // hover highlight can be cleared without polling every mouse move.
    unsafe {
        let mut tracking = TRACKMOUSEEVENT {
            cbSize: std::mem::size_of::<TRACKMOUSEEVENT>() as u32,
            dwFlags: TME_LEAVE,
            hwndTrack: hwnd,
            dwHoverTime: 0,
        };
        let _ = TrackMouseEvent(&mut tracking);
    }
}
pub(super) fn app_icon() -> HICON {
    unsafe {
        let module = GetModuleHandleW(None).unwrap_or_default();
        LoadIconW(
            Some(HINSTANCE(module.0)),
            windows::core::PCWSTR(std::ptr::without_provenance(1)),
        )
        .unwrap_or_default()
    }
}
pub(super) fn tray(hwnd: HWND, action: NOTIFY_ICON_MESSAGE) {
    unsafe {
        let mut data = NOTIFYICONDATAW {
            cbSize: std::mem::size_of::<NOTIFYICONDATAW>() as u32,
            hWnd: hwnd,
            uID: 1,
            uFlags: NIF_ICON | NIF_MESSAGE | NIF_TIP,
            uCallbackMessage: TRAY,
            hIcon: app_icon(),
            ..Default::default()
        };
        let tip: Vec<u16> = "new-quicklook · Space to preview · Right-click to exit"
            .encode_utf16()
            .collect();
        data.szTip[..tip.len()].copy_from_slice(&tip);
        let _ = Shell_NotifyIconW(action, &data);
    }
}
pub(super) fn write_report() {
    with_state(|s| {
        if let Some(path) = &s.report {
            let mut counters = PROCESS_MEMORY_COUNTERS_EX::default();
            unsafe {
                let _ = GetProcessMemoryInfo(
                    GetCurrentProcess(),
                    (&mut counters as *mut PROCESS_MEMORY_COUNTERS_EX).cast(),
                    std::mem::size_of::<PROCESS_MEMORY_COUNTERS_EX>() as u32,
                );
            }
            let (kind, error) = match &s.view.content {
                Some(Content::Text(_)) => ("text", false),
                Some(Content::Image(_)) => ("image", false),
                Some(Content::Pages(_)) => ("pages", false),
                Some(Content::Error(_)) => ("error", true),
                None => ("idle", false),
            };
            let shell_trace = shell::trace()
                .replace('\\', "\\\\")
                .replace('"', "\\\"")
                .replace(['\r', '\n'], " ");
            let message = match &s.view.content {
                Some(Content::Error(e)) => e.as_str(),
                _ => "",
            };
            let escaped: String = message
                .chars()
                .flat_map(|c| match c {
                    '\\' => "\\\\".chars().collect::<Vec<_>>(),
                    '"' => "\\\"".chars().collect(),
                    c if c.is_control() => vec![' '],
                    c => vec![c],
                })
                .collect();
            let file_name = s
                .path
                .as_ref()
                .and_then(|p| p.file_name())
                .map(|p| p.to_string_lossy().replace(['"', '\\'], "_"))
                .unwrap_or_default();
            let body_hash = s
                .view
                .content
                .as_ref()
                .and_then(|c| c.plain_text())
                .map(|t| {
                    t.bytes().fold(14695981039346656037u64, |h, b| {
                        (h ^ u64::from(b)).wrapping_mul(1099511628211)
                    })
                })
                .unwrap_or(0);
            let content_hash = &s.input_digest.sha256;
            let content_hash_bytes = s.input_digest.bytes;
            let content_hash_scope = if content_hash.is_empty() {
                "none"
            } else if s.input_digest.truncated {
                "bounded_input"
            } else {
                "full_input"
            };
            let generation = s.generation;
            let (mut math_pending, mut math_ready, mut math_fallback) = (0, 0, 0);
            let (mut math_backend_rich, mut math_backend_self) = (0, 0);
            if let Some(Content::Text(doc)) = &s.view.content {
                for formula in doc
                    .lines
                    .iter()
                    .flat_map(|l| &l.spans)
                    .filter_map(|s| s.math.as_ref())
                {
                    match &formula.state {
                        quicklook_core::math::State::Pending => math_pending += 1,
                        quicklook_core::math::State::Ready(bitmap) => {
                            math_ready += 1;
                            match bitmap.backend {
                                quicklook_core::math::Backend::Rich => math_backend_rich += 1,
                                quicklook_core::math::Backend::SelfRender => math_backend_self += 1,
                                quicklook_core::math::Backend::Fallback => {}
                            }
                        }
                        quicklook_core::math::State::Fallback => math_fallback += 1,
                    }
                }
            }
            let math_paint_ms = s.view.math_paint_ms.unwrap_or(0.0);
            let format = s.format.map(|f| f.id).unwrap_or("");
            let mode = s.view.mode.label();
            let truncated = matches!(&s.view.content,Some(Content::Text(doc)) if doc.truncated);
            let line_numbers =
                matches!(&s.view.content,Some(Content::Text(doc)) if doc.line_numbers);
            let (image_width, image_height) = match s.view.content.as_ref().and_then(Content::image)
            {
                Some(image) => (image.width, image.height),
                _ => (0, 0),
            };
            let (frame_count, frame_index) = match &s.view.content {
                Some(Content::Image(i)) => (
                    i.animation.as_ref().map_or(1, |a| a.frames.len() + 1),
                    i.frame_index(s.view.animation_started.elapsed().as_millis() as u64),
                ),
                _ => (0, 0),
            };
            let (page_index, page_count, page_ready) = match &s.view.content {
                Some(Content::Pages(p)) => (p.index, p.count, p.image.is_some()),
                _ => (0, 0, false),
            };
            let page_image_hash = s
                .view
                .content
                .as_ref()
                .and_then(Content::image)
                .map(|i| {
                    file::input_digest(&i.bgra, false)
                        .map(|d| d.sha256)
                        .unwrap_or_default()
                })
                .unwrap_or_default();
            let zoom = s.view.canvas.zoom;
            let pan_x = s.view.canvas.offset.0;
            let pan_y = s.view.canvas.offset.1;
            let icon_loaded = !app_icon().0.is_null();
            let layout_builds = s.view.layout_builds;
            let visible_runs = s.view.visible_runs;
            let scroll = s.view.scroll;
            let infotips_hidden = s.infotips_hidden;
            let max_scroll = s.view.max_scroll;
            let scroll_frames = s.view.scroll_frames.iter().map(|f| format!(
                "{{\"width\":{},\"complete\":{},\"scroll\":{},\"draw_scroll\":{},\"max_scroll\":{}}}",
                f.width, f.complete, f.scroll, f.draw_scroll, f.max_scroll
            )).collect::<Vec<_>>().join(",");
            let mut client = RECT::default();
            unsafe {
                let hwnd = HWND(super::WINDOW.load(Ordering::Relaxed) as *mut _);
                let _ = GetClientRect(hwnd, &mut client);
            }
            let scrollbar = s.view.scrollbar_frame(client.right, client.bottom)
                .zip(s.view.scrollbar_metrics(client.right, client.bottom))
                .map(|(f, m)| format!("{{\"left\":{},\"width\":{},\"top\":{},\"track_len\":{},\"thumb_len\":{},\"thumb_pos\":{}}}", f.left, f.width, f.top, m.track_len, m.thumb_len, m.thumb_pos))
                .unwrap_or_else(|| "null".into());
            let paint_ms = s.view.paint_ms;
            let load_ms = s.view.load_ms;
            let image_fit = s.view.image_fit.clone();
            let nav_direction = s.view.nav_direction.clone();
            let nav_diag = s.view.nav_diag.clone();
            let nav_from = s.view.nav_from.clone();
            let nav_to = s.view.nav_to.clone();
            let nav_from_pos = s.view.nav_from_pos.clone();
            let nav_to_pos = s.view.nav_to_pos.clone();
            let topmost = unsafe {
                let hwnd = HWND(super::WINDOW.load(std::sync::atomic::Ordering::Relaxed) as *mut _);
                (GetWindowLongW(hwnd, GWL_EXSTYLE) & WS_EX_TOPMOST.0 as i32) != 0
            };
            let prep_ms = s.view.prep_ms;
            let show_ms = s.view.show_ms;
            let rdw_ms = s.view.rdw_ms;
            let activate_ms = s.view.activate_ms;
            let activate_show_ms = s.view.activate_show_ms;
            let activate_top_ms = s.view.activate_top_ms;
            let activate_fg_ms = s.view.activate_fg_ms;
            let activate_fallback_ms = s.view.activate_fallback_ms;
            let activate_rest_ms = s.view.activate_rest_ms;
            let ready_ms = s.view.ready_ms;
            let paint_start_ms = s.view.paint_start_ms;
            let layout_ms = s.view.layout_ms;
            let layout_measure_ms = s.view.layout_measure_ms;
            let layout_complete = s.view.layout_complete;
            let layout_extensions = s.view.layout_extensions;
            let draw_ms = s.view.draw_ms;
            let output = format!(
                "{{\"shell_resolution\":\"{shell_trace}\",\"infotips_hidden\":{infotips_hidden},\"math_pending\":{math_pending},\"math_ready\":{math_ready},\"math_fallback\":{math_fallback},\"math_backend_rich\":{math_backend_rich},\"math_backend_self\":{math_backend_self},\"math_paint_ms\":{math_paint_ms:.3},\"file_name\":\"{file_name}\",\"content_hash\":\"{content_hash}\",\"body_hash\":\"{body_hash:016x}\",\"content_hash_algorithm\":\"sha256\",\"content_hash_bytes\":{content_hash_bytes},\"content_hash_scope\":\"{content_hash_scope}\",\"generation\":{generation},\"kind\":\"{kind}\",\"error\":{error},\"format\":\"{format}\",\"mode\":\"{mode}\",\"line_numbers\":{line_numbers},\"truncated\":{truncated},\"page_index\":{page_index},\"page_count\":{page_count},\"page_ready\":{page_ready},\"page_image_hash\":\"{page_image_hash}\",\"image_width\":{image_width},\"image_height\":{image_height},\"frame_count\":{frame_count},\"frame_index\":{frame_index},\"zoom\":{zoom:.3},\"pan_x\":{pan_x:.3},\"pan_y\":{pan_y:.3},\"icon_loaded\":{icon_loaded},\"layout_builds\":{layout_builds},\"visible_runs\":{visible_runs},\"scroll\":{scroll},\"max_scroll\":{max_scroll},\"scroll_frames\":[{scroll_frames}],\"scrollbar\":{scrollbar},\"paint_ms\":{paint_ms:.3},\"load_ms\":{load_ms:.3},\"image_fit\":\"{image_fit}\",\"nav_direction\":\"{nav_direction}\",\"nav_diag\":\"{nav_diag}\",\"nav_from\":\"{nav_from}\",\"nav_to\":\"{nav_to}\",\"nav_from_pos\":\"{nav_from_pos}\",\"nav_to_pos\":\"{nav_to_pos}\",\"topmost\":{topmost},\"prep_ms\":{prep_ms:.3},\"show_ms\":{show_ms:.3},\"rdw_ms\":{rdw_ms:.3},\"activate_ms\":{activate_ms:.3},\"activate_show_ms\":{activate_show_ms:.3},\"activate_top_ms\":{activate_top_ms:.3},\"activate_fg_ms\":{activate_fg_ms:.3},\"activate_fallback_ms\":{activate_fallback_ms:.3},\"activate_rest_ms\":{activate_rest_ms:.3},\"ready_ms\":{ready_ms:.3},\"paint_start_ms\":{paint_start_ms:.3},\"layout_ms\":{layout_ms:.3},\"layout_measure_ms\":{layout_measure_ms:.3},\"layout_complete\":{layout_complete},\"layout_extensions\":{layout_extensions},\"draw_ms\":{draw_ms:.3},\"last_key\":{},\"message\":\"{escaped}\",\"first_content_paint_ms\":{},\"working_set_bytes\":{},\"private_bytes\":{}}}\n",
                s.last_key,
                s.view
                    .first_paint_ms
                    .map(|n| format!("{n:.3}"))
                    .unwrap_or_else(|| "null".into()),
                counters.WorkingSetSize,
                counters.PrivateUsage
            );
            let _ = std::fs::write(path, output);
        }
    });
}

/// Comfortable default size for text previews (logical pixels at 96 DPI).
const BASE_W: i32 = 900;
const BASE_H: i32 = 680;
/// Largest image the decoder produces (`render::image::common`); growing the window
/// beyond this cannot add detail.
const DECODE_W: i32 = 1600;
const DECODE_H: i32 = 1200;

/// `QUICKLOOK_WINDOW=WxH` overrides the text default (diagnostics / user preference).
fn configured_base() -> (i32, i32) {
    std::env::var("QUICKLOOK_WINDOW")
        .ok()
        .and_then(|value| {
            let (w, h) = value.split_once(['x', 'X'])?;
            Some((w.trim().parse().ok()?, h.trim().parse().ok()?))
        })
        .unwrap_or((BASE_W, BASE_H))
}

fn work_bounds(area: RECT) -> (i32, i32) {
    (
        (area.right - area.left - 40).max(320),
        (area.bottom - area.top - 40).max(240),
    )
}

/// Text previews open at the configured size, clamped to the monitor work area.
fn text_window_size(area: RECT, dpi: i32, base: (i32, i32)) -> (i32, i32) {
    let dpi = dpi.max(96);
    let (max_w, max_h) = work_bounds(area);
    (
        (base.0.saturating_mul(dpi) / 96).min(max_w).max(320),
        (base.1.saturating_mul(dpi) / 96).min(max_h).max(240),
    )
}

/// Image previews never open smaller than the text size. When the picture (as the
/// decoder would produce it) cannot fit that window, the window grows so the image is
/// shown 1:1, capped by the decode limit and the monitor work area.
fn image_window_size(original: (u32, u32), area: RECT, dpi: i32, base: (i32, i32)) -> (i32, i32) {
    let dpi = dpi.max(96);
    let (min_w, min_h) = text_window_size(area, dpi, base);
    let (max_w, max_h) = work_bounds(area);
    let chrome_w = 48 * dpi / 96; // left + right margin
    let chrome_h = 132 * dpi / 96; // top bar + footer + inner margin
    let content_w = (max_w - chrome_w).max(1) as u32;
    let content_h = (max_h - chrome_h).max(1) as u32;
    let (shown_w, shown_h) = quicklook_core::fit_size(
        original.0,
        original.1,
        content_w.min(DECODE_W as u32),
        content_h.min(DECODE_H as u32),
    );
    (
        (shown_w as i32 + chrome_w).clamp(min_w, max_w),
        (shown_h as i32 + chrome_h).clamp(min_h, max_h),
    )
}

/// Grow the window so an image fits 1:1. Called once per preview, when the decoded
/// image (and its source size) is known. Returns true when the window was resized, in
/// which case the caller re-requests the preview so the decode matches the new size.
pub(super) fn fit_window_to_image(hwnd: HWND, original: (u32, u32)) -> bool {
    unsafe {
        let monitor = MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST);
        let mut info = MONITORINFO {
            cbSize: std::mem::size_of::<MONITORINFO>() as u32,
            ..Default::default()
        };
        let _ = GetMonitorInfoW(monitor, &mut info);
        let area = info.rcWork;
        let dpi = GetDpiForWindow(hwnd).max(96) as i32;
        let (w, h) = image_window_size(original, area, dpi, configured_base());
        let mut current = RECT::default();
        let _ = GetWindowRect(hwnd, &mut current);
        if w == current.right - current.left && h == current.bottom - current.top {
            // Keep the first diagnosis (the follow-up request after a growth lands here).
            with_state(|s| {
                if s.view.image_fit.is_empty() {
                    s.view.image_fit = format!("{w}x{h} (kept)");
                }
            });
            return false;
        }
        let (x, y) = centred_in(area, w, h);
        let _ = SetWindowPos(hwnd, None, x, y, w, h, SWP_NOZORDER | SWP_NOACTIVATE);
        with_state(|s| s.view.image_fit = format!("{w}x{h} (grown)"));
        true
    }
}

/// Top-left corner that centres a `w`x`h` window inside `area`.
fn centred_in(area: RECT, w: i32, h: i32) -> (i32, i32) {
    let x = area.left + ((area.right - area.left) - w) / 2;
    let y = area.top + ((area.bottom - area.top) - h) / 2;
    (x, y)
}

/// Page turns keep the file digest/format/geometry; only the latest page is published.
pub(super) fn turn_page(hwnd: HWND, movement: i32) {
    unsafe {
        let mut rect = RECT::default();
        let _ = GetClientRect(hwnd, &mut rect);
        let changed = with_state(|s| {
            let Some(Content::Pages(p)) = &mut s.view.content else {
                return false;
            };
            if p.count == 0 {
                return false;
            }
            let index =
                (i64::from(p.index) + i64::from(movement)).clamp(0, i64::from(p.count - 1)) as u32;
            if index == p.index && movement != 0 {
                return false;
            }
            p.index = index;
            p.image = None;
            s.view.reset_canvas();
            s.generation += 1;
            s.started = Instant::now();
            s.view.first_paint_ms = None;
            let Some(path) = s.path.clone() else {
                return false;
            };
            s.worker.request(Request {
                page: Some(index),
                generation: s.generation,
                dpi: s.view.dpi,
                path,
                bounds: (
                    (rect.right - 48).max(1) as u32,
                    (rect.bottom - 130).max(1) as u32,
                ),
                mode: None,
            });
            true
        })
        .unwrap_or(false);
        if changed {
            invalidate(hwnd);
        }
    }
}

#[cfg(test)]
mod placement_tests {
    use super::*;

    fn rect(left: i32, top: i32, right: i32, bottom: i32) -> RECT {
        RECT {
            left,
            top,
            right,
            bottom,
        }
    }

    #[test]
    fn centres_within_the_work_area() {
        let area = rect(0, 0, 1920, 1040);
        let (w, h) = text_window_size(area, 96, (BASE_W, BASE_H));
        let (x, y) = centred_in(area, w, h);
        assert_eq!(x + w / 2, 960);
        assert_eq!(y + h / 2, 520);
        // second monitor to the left, with a taskbar offset
        let area = rect(-1920, 0, 0, 1000);
        let (w, h) = text_window_size(area, 96, (BASE_W, BASE_H));
        let (x, y) = centred_in(area, w, h);
        assert_eq!(x + w / 2, -960);
        assert_eq!(y + h / 2, 500);
    }

    #[test]
    fn text_uses_a_fixed_comfortable_size() {
        let base = (BASE_W, BASE_H);
        assert_eq!(
            text_window_size(rect(0, 0, 1920, 1040), 96, base),
            (900, 680)
        );
        // DPI scaling keeps the same logical size
        assert_eq!(
            text_window_size(rect(0, 0, 2880, 1704), 192, base),
            (1800, 1360)
        );
        assert_eq!(
            text_window_size(rect(0, 0, 2880, 1704), 144, base),
            (1350, 1020)
        );
        assert_eq!(
            text_window_size(rect(0, 0, 2880, 1704), 120, base),
            (1125, 850)
        );
        // small screens are clamped to the work area
        let small = text_window_size(rect(0, 0, 1366, 650), 96, base);
        assert_eq!(small, (900, 610));
        // an explicit preference is honoured
        assert_eq!(
            text_window_size(rect(0, 0, 1920, 1040), 96, (800, 600)),
            (800, 600)
        );
    }

    #[test]
    fn images_never_shrink_below_text_and_grow_when_needed() {
        let base = (BASE_W, BASE_H);
        // small picture on a large screen: the comfortable text size is kept
        let big_screen = rect(0, 0, 2880, 1704);
        assert_eq!(
            image_window_size((64, 48), big_screen, 192, base),
            text_window_size(big_screen, 192, base)
        );
        // picture larger than the default window: the window grows to show it 1:1
        let laptop = rect(0, 0, 1920, 1040);
        let (w, h) = image_window_size((4096, 3072), laptop, 96, base);
        assert!(w > BASE_W && h > BASE_H, "expected growth, got {w}x{h}");
        assert!(w <= 1880 && h <= 1000);
        // growth is capped by the decode limit: a huge picture never exceeds it
        let (w, h) = image_window_size((12000, 9000), rect(0, 0, 3840, 2120), 96, base);
        assert_eq!((w, h), (DECODE_W + 48, DECODE_H + 132));
    }
}
