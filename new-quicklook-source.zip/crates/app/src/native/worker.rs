//! Serial worker client. Pipes stay off the caller; Job ownership bounds failures.
use quicklook_core::worker::{self, Frame, Message, Spec};
use std::{
    io,
    os::windows::{io::AsRawHandle, process::CommandExt},
    path::PathBuf,
    process::{Child, Command, Stdio},
    sync::mpsc,
    thread,
    time::{Duration, Instant},
};
use windows::Win32::{Foundation::*, System::JobObjects::*};
struct Job(HANDLE);
impl Drop for Job {
    fn drop(&mut self) {
        unsafe {
            let _ = CloseHandle(self.0);
        }
    }
}
struct Process {
    child: Child,
    input: Option<mpsc::SyncSender<Frame>>,
    output: mpsc::Receiver<io::Result<Frame>>,
    writer: Option<thread::JoinHandle<()>>,
    reader: Option<thread::JoinHandle<()>>,
    _job: Job,
}
impl Drop for Process {
    fn drop(&mut self) {
        // Killing first unblocks either pipe. Closing the sender wakes an idle writer.
        let _ = self.child.kill();
        let _ = self.child.wait();
        self.input.take();
        if let Some(t) = self.writer.take() {
            let _ = t.join();
        }
        if let Some(t) = self.reader.take() {
            let _ = t.join();
        }
    }
}
impl Process {
    fn new(spec: Spec, exe: &std::path::Path) -> io::Result<Self> {
        // This owning background thread assigns the child before sending even Hello.
        unsafe {
            let job = Job(CreateJobObjectW(None, None).map_err(io::Error::other)?);
            let mut limits = JOBOBJECT_EXTENDED_LIMIT_INFORMATION::default();
            limits.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
                | JOB_OBJECT_LIMIT_PROCESS_MEMORY
                | JOB_OBJECT_LIMIT_ACTIVE_PROCESS;
            limits.BasicLimitInformation.ActiveProcessLimit = 1;
            limits.ProcessMemoryLimit = spec.memory_bytes;
            SetInformationJobObject(
                job.0,
                JobObjectExtendedLimitInformation,
                (&limits as *const JOBOBJECT_EXTENDED_LIMIT_INFORMATION).cast(),
                std::mem::size_of_val(&limits) as u32,
            )
            .map_err(io::Error::other)?;
            let mut child = Command::new(exe)
                .creation_flags(0x08000000)
                .stdin(Stdio::piped())
                .stdout(Stdio::piped())
                .stderr(Stdio::null())
                .spawn()?;
            if let Err(e) = AssignProcessToJobObject(job.0, HANDLE(child.as_raw_handle())) {
                let _ = child.kill();
                let _ = child.wait();
                return Err(io::Error::other(e));
            }
            let mut input = child.stdin.take().unwrap();
            let mut output = child.stdout.take().unwrap();
            let (tx, rx) = mpsc::sync_channel(1);
            let (writes, pending) = mpsc::sync_channel(1);
            let errors = tx.clone();
            let writer = thread::spawn(move || {
                while let Ok(f) = pending.recv() {
                    if let Err(e) = worker::write(&mut input, &f, spec.request_bytes.max(2)) {
                        let _ = errors.try_send(Err(e));
                        break;
                    }
                }
            });
            let reader = thread::spawn(move || {
                loop {
                    let result = worker::read(&mut output, spec.response_bytes.max(2));
                    let failed = result.is_err();
                    if tx.try_send(result).is_err() || failed {
                        break;
                    }
                }
            });
            Ok(Self {
                child,
                input: Some(writes),
                output: rx,
                writer: Some(writer),
                reader: Some(reader),
                _job: job,
            })
        }
    }
    fn exchange(
        &mut self,
        request: Frame,
        expected: Message,
        timeout: u64,
        cancel: &impl Fn() -> bool,
    ) -> io::Result<Frame> {
        let id = request.id;
        let generation = request.generation;
        self.input
            .as_ref()
            .unwrap()
            .try_send(request)
            .map_err(io::Error::other)?;
        let deadline = Instant::now() + Duration::from_millis(timeout);
        loop {
            if cancel() {
                return Err(io::Error::new(
                    io::ErrorKind::Interrupted,
                    "Worker request cancelled",
                ));
            }
            if Instant::now() >= deadline {
                return Err(io::Error::new(
                    io::ErrorKind::TimedOut,
                    "Worker request timed out",
                ));
            }
            match self.output.recv_timeout(Duration::from_millis(5)) {
                Ok(Ok(f)) if f.id == id && f.generation == generation && f.message == expected => {
                    return Ok(f);
                }
                Err(mpsc::RecvTimeoutError::Timeout) => {}
                Ok(Err(e)) => return Err(e),
                _ => return Err(worker::invalid()),
            }
        }
    }
}
pub struct Client {
    spec: Spec,
    exe: PathBuf,
    process: Option<Process>,
    last_use: Option<Instant>,
    next_id: u64,
}
impl Client {
    pub fn new(spec: Spec) -> Self {
        let exe = std::env::current_exe()
            .ok()
            .and_then(|p| p.parent().map(|p| p.join("worker").join(spec.exe)))
            .unwrap_or_default();
        Self::with_path(spec, exe)
    }
    pub fn with_path(spec: Spec, exe: PathBuf) -> Self {
        Self {
            spec,
            exe,
            process: None,
            last_use: None,
            next_id: 0,
        }
    }
    pub fn available(&self) -> bool {
        self.process.is_some()
    }
    pub fn touch(&mut self) {
        self.last_use = Some(Instant::now());
    }
    pub fn reset(&mut self) {
        self.process = None;
        self.last_use = None;
    }
    pub fn expire(&mut self) -> bool {
        if self
            .last_use
            .is_some_and(|t| t.elapsed() >= Duration::from_millis(self.spec.idle_ms))
        {
            self.reset();
            return true;
        }
        false
    }
    pub fn request(
        &mut self,
        generation: u64,
        payload: Vec<u8>,
        cancel: impl Fn() -> bool,
    ) -> io::Result<Vec<u8>> {
        if payload.len() > self.spec.request_bytes {
            return Err(worker::invalid());
        }
        if cancel() {
            return Err(io::Error::new(
                io::ErrorKind::Interrupted,
                "Worker request cancelled",
            ));
        }
        self.touch();
        let result = (|| {
            if self.process.is_none() {
                let mut process = Process::new(self.spec, &self.exe)?;
                let welcome = process.exchange(
                    worker::hello(self.spec, Message::Hello),
                    Message::Welcome,
                    self.spec.timeout_ms,
                    &cancel,
                )?;
                if welcome != worker::hello(self.spec, Message::Welcome) {
                    return Err(worker::invalid());
                }
                self.process = Some(process);
            }
            self.next_id = self.next_id.checked_add(1).ok_or_else(worker::invalid)?;
            let f = Frame {
                message: Message::Request,
                id: self.next_id,
                generation,
                payload,
            };
            Ok(self
                .process
                .as_mut()
                .unwrap()
                .exchange(f, Message::Response, self.spec.timeout_ms, &cancel)?
                .payload)
        })();
        if result.is_err() {
            self.reset();
        }
        result
    }
}
