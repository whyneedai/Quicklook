use super::*;

/// Only the original root and active Shell view may recall a covered preview.
/// Read HWND/focus values only; Shell COM stays on the UI thread.
pub(super) fn original_list(foreground: HWND) -> bool {
    unsafe {
        let view = HWND(EXPLORER_VIEW.load(Ordering::Relaxed) as *mut _);
        let mut info = GUITHREADINFO {
            cbSize: std::mem::size_of::<GUITHREADINFO>() as u32,
            ..Default::default()
        };
        GetForegroundWindow() == foreground
            && foreground.0 as usize == EXPLORER.load(Ordering::Relaxed)
            && !view.0.is_null()
            && IsWindowVisible(view).as_bool()
            && GetAncestor(view, GA_ROOT) == foreground
            && shell::explorer_list(foreground)
            && GetGUIThreadInfo(GetWindowThreadProcessId(foreground, None), &mut info).is_ok()
            && (info.hwndFocus == view || IsChild(view, info.hwndFocus).as_bool())
    }
}

/// A visible preview accepts keys while it is foreground, or while its original
/// Explorer list is foreground and the preview remains above overlapping windows.
/// Called again on the UI thread before acting on a queued keyboard message.
pub(super) fn keyboard_target(hwnd: HWND, foreground: HWND) -> bool {
    unsafe {
        if !IsWindowVisible(hwnd).as_bool()
            || GetForegroundWindow() != foreground
            || (foreground != hwnd && !original_list(foreground))
        {
            return false;
        }
        overlays::uncovered(hwnd)
    }
}

pub(super) unsafe extern "system" fn keyboard(code: i32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    thread_local! {static HELD:RefCell<(bool,bool)>=const{RefCell::new((false,false))};}
    // SAFETY: Windows supplies KBDLLHOOKSTRUCT for HC_ACTION, valid only in this callback.
    // The hook never queries Shell COM or borrows UI state; it posts value-only messages.
    unsafe {
        if code == HC_ACTION as i32 {
            let key = &*(lp.0 as *const KBDLLHOOKSTRUCT);
            let down = wp.0 as u32 == WM_KEYDOWN || wp.0 as u32 == WM_SYSKEYDOWN;
            let foreground = GetForegroundWindow();
            let hwnd = HWND(WINDOW.load(Ordering::Relaxed) as *mut _);
            let modifiers = [VK_CONTROL, VK_MENU, VK_SHIFT, VK_LWIN, VK_RWIN]
                .iter()
                .any(|k| GetAsyncKeyState(k.0 as i32) < 0);
            let accepts = !modifiers && !hwnd.0.is_null() && keyboard_target(hwnd, foreground);
            if matches!(key.vkCode, 0x25..=0x28) && accepts {
                if foreground == hwnd {
                    if down {
                        let _ = PostMessageW(
                            Some(hwnd),
                            NAVIGATE,
                            WPARAM(key.vkCode as usize),
                            LPARAM(foreground.0 as isize),
                        );
                    }
                    return LRESULT(1);
                }
                // Explorer owns layout, sorting, groups and native row wrapping. Follow
                // after key-up and retry briefly if its asynchronous selection is late.
                {
                    let _ = PostMessageW(
                        Some(hwnd),
                        FOLLOW,
                        WPARAM(key.vkCode as usize),
                        LPARAM(foreground.0 as isize),
                    );
                }
            }
            let command = match key.vkCode {
                0x50 => Some((1u8, PIN)),
                0x4d => Some((2u8, SWITCH_MODE)),
                0x1b => Some((4u8, CLOSE_PREVIEW)),
                _ => None,
            };
            if let Some((bit, message)) = command {
                thread_local! { static COMMANDS: RefCell<(u8,u8)> = const { RefCell::new((0,0)) }; }
                let consumed = COMMANDS.with(|state| {
                    let mut state = state.borrow_mut();
                    if !down {
                        let consumed = state.1 & bit != 0;
                        state.0 &= !bit;
                        state.1 &= !bit;
                        return consumed;
                    }
                    if state.0 & bit == 0 {
                        state.0 |= bit;
                        if accepts
                            && PostMessageW(
                                Some(hwnd),
                                message,
                                WPARAM(0),
                                LPARAM(foreground.0 as isize),
                            )
                            .is_ok()
                        {
                            state.1 |= bit;
                        }
                    }
                    state.1 & bit != 0
                });
                // P/M must not start Explorer's incremental filename search, and
                // holding a toggle key must not toggle once per repeat message.
                if consumed {
                    return LRESULT(1);
                }
            }
            if key.vkCode == VK_SPACE.0 as u32 {
                let consume = HELD.with(|held| {
                    let mut pair = held.borrow_mut();
                    if !down {
                        let consumed = pair.1;
                        *pair = (false, false);
                        return consumed;
                    }
                    if pair.0 {
                        return pair.1;
                    }
                    pair.0 = true;
                    let opening =
                        !IsWindowVisible(hwnd).as_bool() && shell::explorer_list(foreground);
                    if !modifiers
                        && !hwnd.0.is_null()
                        && (accepts || opening || original_list(foreground))
                    {
                        KEY_TICK.store(
                            CLOCK
                                .get()
                                .map(|t| t.elapsed().as_nanos() as u64)
                                .unwrap_or(0),
                            Ordering::Relaxed,
                        );
                        pair.1 = PostMessageW(
                            Some(hwnd),
                            TOGGLE,
                            WPARAM(0),
                            LPARAM(foreground.0 as isize),
                        )
                        .is_ok();
                    }
                    pair.1
                });
                if consume {
                    return LRESULT(1);
                }
            }
        }
        CallNextHookEx(None, code, wp, lp)
    }
}
