use super::*;

/// Follow a value-only hook request on the STA. Selection is queried afresh, and
/// only the exact Explorer tab that opened this preview may replace its content.
pub(super) fn follow_navigation(hwnd: HWND) {
    let Some((owner, key, attempts)) = with_state(|s| s.navigation).flatten() else {
        return;
    };
    if !hook::keyboard_target(hwnd, owner) {
        with_state(|s| s.navigation = None);
        unsafe {
            let _ = KillTimer(Some(hwnd), 6);
        }
        return;
    }
    let view = with_state(|s| s.explorer_view).flatten();
    let result = view.map(|view| shell::navigation(owner, view, key));
    if let Some(Ok(Some(selection))) = result.as_ref() {
        let changed = with_state(|s| s.path.as_ref() != Some(&selection.path)).unwrap_or(false);
        if changed {
            with_state(|s| {
                s.view.nav_direction = format!("vk{key}");
                s.view.nav_from = s
                    .path
                    .as_ref()
                    .and_then(|p| p.file_name())
                    .map(|n| n.to_string_lossy().into_owned())
                    .unwrap_or_default();
                s.view.nav_to = selection
                    .path
                    .file_name()
                    .map(|n| n.to_string_lossy().into_owned())
                    .unwrap_or_default();
                s.view.nav_diag =
                    shell::sanitized(format!("native follow {}", selection.path.display()));
                s.navigation = None;
            });
            unsafe {
                let _ = KillTimer(Some(hwnd), 6);
            }
            preview(
                hwnd,
                selection.path.clone(),
                None,
                Some(Instant::now()),
                None,
                true,
            );
            return;
        }
    }
    if let Some(Err(error)) = result {
        with_state(|s| s.view.nav_diag = shell::sanitized(error));
    }
    with_state(|s| {
        s.navigation = if attempts < 8 {
            Some((owner, key, attempts + 1))
        } else {
            None
        }
    });
    unsafe {
        if attempts < 8 {
            SetTimer(Some(hwnd), 6, 25, None);
        } else {
            let _ = KillTimer(Some(hwnd), 6);
        }
    }
}

/// If the user clicked the preview, return keyboard focus to the original list
/// before replaying the arrow. Explorer remains the authority for grid navigation.
pub(super) fn navigate_from_preview(hwnd: HWND, key: usize) {
    if !hook::keyboard_target(hwnd, hwnd) {
        return;
    }
    let Some((owner, focus, view)) =
        with_state(|s| Some((s.explorer?, s.explorer_focus?, s.explorer_view?))).flatten()
    else {
        return;
    };
    unsafe {
        if !IsWindow(Some(owner)).as_bool()
            || !IsWindowVisible(view).as_bool()
            || !IsChild(view, focus).as_bool()
        {
            return;
        }
        // SAFETY: attach only for foreground/focus restoration. No state borrow or
        // COM object survives these reentrant calls; always detach before SendInput.
        let current = GetCurrentThreadId();
        let target = GetWindowThreadProcessId(owner, None);
        let attached = current != target && AttachThreadInput(current, target, true).as_bool();
        let foreground_ok = SetForegroundWindow(owner).as_bool();
        if foreground_ok {
            let _ = SetFocus(Some(focus));
        }
        if attached {
            let _ = AttachThreadInput(current, target, false);
        }
        if !foreground_ok || GetForegroundWindow() != owner || !shell::explorer_list(owner) {
            return;
        }
        show_no_activate(hwnd);
        let inputs = [0, KEYEVENTF_KEYUP.0].map(|flags| INPUT {
            r#type: INPUT_KEYBOARD,
            Anonymous: INPUT_0 {
                ki: KEYBDINPUT {
                    wVk: VIRTUAL_KEY(key as u16),
                    dwFlags: KEYBD_EVENT_FLAGS(flags),
                    ..Default::default()
                },
            },
        });
        let _ = SendInput(&inputs, std::mem::size_of::<INPUT>() as i32);
    }
}
