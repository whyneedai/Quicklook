//! Adapter for the public paginated capability; no filename/extension dispatch.
use super::{file::InputDigest, worker::Client};
use quicklook_core::{FormatInfo, Image, Input, Output, Pages, PreviewMode, pages};
use quicklook_engine::Engine;
use std::{collections::VecDeque, sync::Arc};
type CacheEntry = ((u32, (u32, u32)), Arc<Image>);
#[derive(Default)]
pub struct Service {
    client: Option<Client>,
    spec: Option<quicklook_core::worker::Spec>,
    count: u32,
    cache: VecDeque<CacheEntry>,
    bytes: usize,
    pub metadata: Option<(FormatInfo, PreviewMode, InputDigest)>,
}
impl Service {
    pub fn available(&self) -> bool {
        self.client.as_ref().is_some_and(Client::available)
            && self.count > 0
            && self.metadata.is_some()
    }
    pub fn clear(&mut self) {
        if let Some(c) = &mut self.client {
            c.reset();
        }
        self.clear_document();
    }
    fn clear_document(&mut self) {
        self.count = 0;
        self.cache.clear();
        self.bytes = 0;
        self.metadata = None;
    }
    pub fn expire(&mut self) {
        if self.client.as_mut().is_some_and(Client::expire) {
            self.clear_document();
        }
    }
    pub fn open(
        &mut self,
        model: Pages,
        index: u32,
        bounds: (u32, u32),
        generation: u64,
        cancel: impl Fn() -> bool,
    ) -> Result<Pages, String> {
        self.clear_document();
        if self.spec.is_none_or(|s| s.id != model.worker.id) {
            self.clear();
            self.spec = Some(model.worker);
            self.client = Some(Client::new(model.worker));
        }
        let source = model
            .source
            .ok_or_else(|| "Missing document input".to_string())?;
        self.render_request(Some(&source), index, bounds, generation, cancel)
    }
    pub fn page(
        &mut self,
        index: u32,
        bounds: (u32, u32),
        generation: u64,
        cancel: impl Fn() -> bool,
    ) -> Result<Pages, String> {
        self.render_request(None, index, bounds, generation, cancel)
    }
    fn render_request(
        &mut self,
        source: Option<&[u8]>,
        index: u32,
        bounds: (u32, u32),
        generation: u64,
        cancel: impl Fn() -> bool,
    ) -> Result<Pages, String> {
        let result = self.render_inner(source, index, bounds, generation, cancel);
        if result.is_err() {
            self.clear();
        }
        result
    }
    fn render_inner(
        &mut self,
        source: Option<&[u8]>,
        index: u32,
        bounds: (u32, u32),
        generation: u64,
        cancel: impl Fn() -> bool,
    ) -> Result<Pages, String> {
        if cancel() {
            return Err("Document request cancelled".into());
        }
        let bounds = (bounds.0.clamp(1, 1600), bounds.1.clamp(1, 1200));
        let spec = self.spec.ok_or("No document worker specification")?;
        self.client.as_mut().ok_or("No document worker")?.touch();
        if source.is_none()
            && let Some(i) = self.cache.iter().position(|c| c.0 == (index, bounds))
        {
            let entry = self.cache.remove(i).unwrap();
            let image = entry.1.clone();
            self.cache.push_back(entry);
            return Ok(Pages {
                worker: spec,
                source: None,
                index,
                count: self.count,
                image: Some(image),
            });
        }
        let payload = pages::Request {
            source,
            index,
            bounds,
        }
        .encode()
        .map_err(|e| e.to_string())?;
        let bytes = self
            .client
            .as_mut()
            .ok_or("No document worker")?
            .request(generation, payload, cancel)
            .map_err(|e| format!("Document worker unavailable: {e}"))?;
        let response = pages::decode(&bytes).map_err(|e| e.to_string())??;
        if response.index != index
            || response.size.0 > bounds.0
            || response.size.1 > bounds.1
            || (source.is_none() && response.count != self.count)
        {
            return Err("Invalid document page response".into());
        }
        let engine = Engine::default();
        let info = engine
            .detect(std::path::Path::new("worker-image"), response.image)
            .map_err(|e| e.to_string())?;
        let preview = engine
            .preview(
                info.id,
                Input {
                    bytes: response.image,
                    viewport: bounds,
                    mode: PreviewMode::Rendered,
                    truncated: false,
                },
            )
            .map_err(|e| e.to_string())?;
        let Output::Image(image) = preview.output else {
            return Err("Worker did not return an image".into());
        };
        if image.original != response.size || image.bgra.len() > spec.cache_bytes {
            return Err("Document page dimensions or budget mismatch".into());
        }
        self.count = response.count;
        while self.bytes + image.bgra.len() > spec.cache_bytes {
            let entry = self
                .cache
                .pop_front()
                .ok_or("Document page exceeds cache budget")?;
            self.bytes -= entry.1.bgra.len();
        }
        self.bytes += image.bgra.len();
        let image = Arc::new(image);
        self.cache.push_back(((index, bounds), image.clone()));
        Ok(Pages {
            worker: spec,
            source: None,
            index,
            count: self.count,
            image: Some(image),
        })
    }
}
