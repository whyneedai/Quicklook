use super::*;
use windows::Win32::UI::Accessibility::{HWINEVENTHOOK, SetWinEventHook, UnhookWinEvent};

/// Temporary Shell surfaces do not own preview keyboard eligibility.
fn ignored(class: &str) -> bool {
    matches!(
        class,
        "Shell_TrayWnd"
            | "Shell_SecondaryTrayWnd"
            | "Progman"
            | "WorkerW"
            | "tooltips_class32"
            | "#32768"
            | "SysShadow"
    )
}

fn visible_bounds(hwnd: HWND) -> Option<RECT> {
    unsafe {
        if !IsWindowVisible(hwnd).as_bool() || IsIconic(hwnd).as_bool() {
            return None;
        }
        let mut cloaked = 0u32;
        let _ = windows::Win32::Graphics::Dwm::DwmGetWindowAttribute(
            hwnd,
            windows::Win32::Graphics::Dwm::DWMWA_CLOAKED,
            (&mut cloaked as *mut u32).cast(),
            std::mem::size_of::<u32>() as u32,
        );
        let mut bounds = RECT::default();
        (cloaked == 0 && GetWindowRect(hwnd, &mut bounds).is_ok()).then_some(bounds)
    }
}
fn intersects(a: RECT, b: RECT) -> bool {
    a.left < b.right && a.right > b.left && a.top < b.bottom && a.bottom > b.top
}

/// Shared by the hook, queued actions and infotip suppression. No UI-state borrow.
pub(super) fn uncovered(hwnd: HWND) -> bool {
    let Some(preview) = visible_bounds(hwnd) else {
        return false;
    };
    unsafe {
        let mut above = GetWindow(hwnd, GW_HWNDPREV).unwrap_or_default();
        for _ in 0..256 {
            if above.0.is_null() {
                return true;
            }
            if !ignored(&shell::class(above))
                && visible_bounds(above).is_some_and(|bounds| intersects(bounds, preview))
            {
                return false;
            }
            above = GetWindow(above, GW_HWNDPREV).unwrap_or_default();
        }
        false
    }
}

fn explorer_tip(tip_pid: u32) -> bool {
    unsafe {
        let source = HWND(EXPLORER.load(Ordering::Relaxed) as *mut _);
        let mut source_pid = 0;
        if !source.0.is_null() {
            GetWindowThreadProcessId(source, Some(&mut source_pid));
        }
        if tip_pid != 0 && source_pid == tip_pid {
            return true;
        }
        // A separate Explorer process can also expose a strip beside the preview.
        // Identify its PID through a real Shell root, never by a tooltip title.
        let mut window = GetTopWindow(None).unwrap_or_default();
        for _ in 0..512 {
            if window.0.is_null() {
                break;
            }
            let mut pid = 0;
            GetWindowThreadProcessId(window, Some(&mut pid));
            if pid == tip_pid
                && matches!(
                    shell::class(window).as_str(),
                    "CabinetWClass" | "ExploreWClass"
                )
            {
                return true;
            }
            window = GetWindow(window, GW_HWNDNEXT).unwrap_or_default();
        }
        false
    }
}

struct Region(Option<HRGN>);
impl Drop for Region {
    fn drop(&mut self) {
        if let Some(region) = self.0 {
            // This is our copy; regions transferred to USER32 are removed from it.
            unsafe {
                let _ = DeleteObject(HGDIOBJ(region.0));
            }
        }
    }
}
pub(super) struct SuppressedTip {
    hwnd: HWND,
    pid: u32,
    region: Region,
    region_restored: bool,
    topmost: bool,
}

pub(super) fn restore(preview: HWND) {
    let tips = with_state(|s| std::mem::take(&mut s.suppressed_tips)).unwrap_or_default();
    let mut pending = Vec::new();
    for mut tip in tips {
        unsafe {
            let mut pid = 0;
            GetWindowThreadProcessId(tip.hwnd, Some(&mut pid));
            if pid != tip.pid || shell::class(tip.hwnd) != "tooltips_class32" {
                continue;
            }
            if !tip.region_restored {
                if SetWindowRgn(tip.hwnd, tip.region.0, true) == 0 {
                    pending.push(tip);
                    continue;
                }
                // USER32 now owns the restored region (or the default rectangle).
                tip.region.0 = None;
                tip.region_restored = true;
            }
            let level = if tip.topmost {
                HWND_TOPMOST
            } else {
                HWND_NOTOPMOST
            };
            if SetWindowPos(
                tip.hwnd,
                Some(level),
                0,
                0,
                0,
                0,
                SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE,
            )
            .is_err()
            {
                pending.push(tip);
            }
        }
    }
    let complete = pending.is_empty();
    with_state(|s| s.suppressed_tips = pending);
    if complete {
        unsafe {
            let _ = KillTimer(Some(preview), 9);
        }
    }
}

pub(super) fn sync_scope(preview: HWND) {
    if !uncovered(preview) {
        restore(preview);
    } else {
        suppress_existing(preview);
        let tips = with_state(|s| s.suppressed_tips.iter().map(|t| t.hwnd).collect::<Vec<_>>())
            .unwrap_or_default();
        for tip in tips {
            suppress_tip(preview, tip);
        }
    }
}

fn above(preview: HWND, tip: HWND) -> bool {
    unsafe {
        let mut window = GetWindow(preview, GW_HWNDPREV).unwrap_or_default();
        for _ in 0..256 {
            if window.0.is_null() {
                break;
            }
            if window == tip {
                return true;
            }
            window = GetWindow(window, GW_HWNDPREV).unwrap_or_default();
        }
        false
    }
}

pub(super) fn suppress_tip(preview: HWND, tip: HWND) {
    // Only suppress Explorer's currently overlapping infotip. Never deactivate the
    // tooltip control, alter Explorer settings or send input to its file list.
    unsafe {
        if shell::class(tip) != "tooltips_class32" || !uncovered(preview) {
            return;
        }
        let mut tip_pid = 0;
        GetWindowThreadProcessId(tip, Some(&mut tip_pid));
        if !explorer_tip(tip_pid) {
            return;
        }
        if let (Some(a), Some(b)) = (visible_bounds(preview), visible_bounds(tip))
            && intersects(a, b)
        {
            // Preserve the tooltip's logical visibility/current tool. An empty
            // region hides every pixel; place it behind the preview as well, so the
            // shared z-order visibility rule remains true. No control/input message.
            let saved = with_state(|s| {
                s.suppressed_tips
                    .iter()
                    .position(|t| t.hwnd == tip && t.pid == tip_pid)
            })
            .flatten();
            if saved.is_none() && with_state(|s| s.suppressed_tips.len() >= 256).unwrap_or(true) {
                return;
            }
            let copy = CreateRectRgn(0, 0, 0, 0);
            if copy.0.is_null() {
                return;
            }
            let kind = GetWindowRgn(tip, copy);
            let region = if kind.0 == 0 {
                let _ = DeleteObject(HGDIOBJ(copy.0));
                Region(None)
            } else {
                Region(Some(copy))
            };
            if saved.is_some() && kind == NULLREGION && !above(preview, tip) {
                return;
            }
            let topmost = GetWindowLongPtrW(tip, GWL_EXSTYLE) as u32 & WS_EX_TOPMOST.0 != 0;
            let empty = CreateRectRgn(0, 0, 0, 0);
            if empty.0.is_null() {
                return;
            }
            if SetWindowRgn(tip, Some(empty), true) == 0 {
                let _ = DeleteObject(HGDIOBJ(empty.0));
                return;
            }
            // Empty region ownership has transferred to the foreign window.
            let old = with_state(|s| {
                if let Some(index) = saved {
                    if kind == NULLREGION {
                        return Some(region);
                    }
                    s.suppressed_tips[index].region_restored = false;
                    Some(std::mem::replace(
                        &mut s.suppressed_tips[index].region,
                        region,
                    ))
                } else {
                    s.suppressed_tips.push(SuppressedTip {
                        hwnd: tip,
                        pid: tip_pid,
                        region,
                        region_restored: false,
                        topmost,
                    });
                    None
                }
            });
            drop(old);
            if SetWindowPos(
                tip,
                Some(preview),
                0,
                0,
                0,
                0,
                SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE,
            )
            .is_ok()
            {
                with_state(|s| s.infotips_hidden += 1);
            }
            SetTimer(Some(preview), 9, 100, None);
            write_report();
        }
    }
}
pub(super) fn suppress_existing(preview: HWND) {
    unsafe {
        let mut above = GetWindow(preview, GW_HWNDPREV).unwrap_or_default();
        for _ in 0..256 {
            if above.0.is_null() {
                break;
            }
            let next = GetWindow(above, GW_HWNDPREV).unwrap_or_default();
            suppress_tip(preview, above);
            above = next;
        }
    }
}

/// Out-of-context events are delivered on the registering STA. Callback never
/// borrows State; queued HWND values are revalidated before hiding any surface.
unsafe extern "system" fn event(
    _: HWINEVENTHOOK,
    event_id: u32,
    hwnd: HWND,
    _: i32,
    _: i32,
    _: u32,
    _: u32,
) {
    unsafe {
        let preview = HWND(WINDOW.load(Ordering::Relaxed) as *mut _);
        if preview.0.is_null() {
            return;
        }
        if event_id == EVENT_SYSTEM_FOREGROUND || event_id == EVENT_OBJECT_REORDER {
            let _ = PostMessageW(Some(preview), INFOTIP_SCOPE, WPARAM(0), LPARAM(0));
        } else if IsWindowVisible(preview).as_bool() && shell::class(hwnd) == "tooltips_class32" {
            let _ = PostMessageW(Some(preview), INFOTIP, WPARAM(0), LPARAM(hwnd.0 as isize));
        }
    }
}
pub(super) struct Events(Vec<HWINEVENTHOOK>);
impl Events {
    pub(super) fn new() -> Self {
        let hooks = [
            EVENT_OBJECT_SHOW,
            EVENT_OBJECT_LOCATIONCHANGE,
            EVENT_SYSTEM_FOREGROUND,
            EVENT_OBJECT_REORDER,
        ]
        .into_iter()
        .map(|event_id| unsafe {
            SetWinEventHook(
                event_id,
                event_id,
                None,
                Some(event),
                0,
                0,
                WINEVENT_OUTOFCONTEXT | WINEVENT_SKIPOWNPROCESS,
            )
        })
        .filter(|hook| !hook.0.is_null())
        .collect();
        Self(hooks)
    }
}
impl Drop for Events {
    fn drop(&mut self) {
        restore(HWND(WINDOW.load(Ordering::Relaxed) as *mut _));
        for hook in &self.0 {
            // Same registering STA; unhook before State/COM teardown.
            unsafe {
                let _ = UnhookWinEvent(*hook);
            }
        }
    }
}
