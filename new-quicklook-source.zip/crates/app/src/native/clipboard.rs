//! Write-only clipboard adapter. The app never reads pre-existing clipboard contents.
use windows::Win32::{
    Foundation::*,
    System::{DataExchange::*, Memory::*},
};
pub fn write(hwnd: HWND, text: &str) -> windows::core::Result<()> {
    let encoded: Vec<u16> = text.encode_utf16().chain(Some(0)).collect();
    unsafe {
        let memory = GlobalAlloc(GMEM_MOVEABLE, encoded.len() * 2)?;
        let pointer = GlobalLock(memory);
        if pointer.is_null() {
            let _ = GlobalFree(Some(memory));
            return Err(windows::core::Error::from_thread());
        }
        std::ptr::copy_nonoverlapping(encoded.as_ptr(), pointer.cast::<u16>(), encoded.len());
        let _ = GlobalUnlock(memory);
        if let Err(error) = OpenClipboard(Some(hwnd)) {
            let _ = GlobalFree(Some(memory));
            return Err(error);
        }
        let result = EmptyClipboard()
            .and_then(|()| SetClipboardData(13, Some(HANDLE(memory.0))).map(|_| ()));
        let _ = CloseClipboard();
        if result.is_err() {
            let _ = GlobalFree(Some(memory));
        }
        // SetClipboardData owns the allocation after success; do not free it then.
        result
    }
}
