mod clipboard;
mod file;

mod loader;
mod math_worker;
mod page_worker;
mod shell;
mod worker;
use loader::{Request, Worker};
use quicklook_core::{FormatInfo, Output as Content, PreviewMode};
use quicklook_display::{self as display, ViewState};
use std::{
    cell::RefCell,
    path::PathBuf,
    sync::{
        OnceLock,
        atomic::{AtomicU64, AtomicUsize, Ordering},
    },
    time::{Duration, Instant},
};
use windows::{
    Win32::{
        Foundation::*,
        Graphics::Gdi::*,
        System::{Com::*, LibraryLoader::GetModuleHandleW, ProcessStatus::*, Threading::*},
        UI::{
            HiDpi::*,
            Input::{Ime::*, KeyboardAndMouse::*},
            Shell::*,
            WindowsAndMessaging::*,
        },
    },
    core::w,
};
const TOGGLE: u32 = WM_APP + 1;
const READY: u32 = WM_APP + 2;
const TRAY: u32 = WM_APP + 3;
static CLOCK: OnceLock<Instant> = OnceLock::new();
static KEY_TICK: AtomicU64 = AtomicU64::new(0);
static WINDOW: AtomicUsize = AtomicUsize::new(0);
// Only HWND values cross to the hook thread; Shell interfaces remain on the STA.
static EXPLORER: AtomicUsize = AtomicUsize::new(0);
static EXPLORER_VIEW: AtomicUsize = AtomicUsize::new(0);
/// Posted by the hook when Explorer moved its selection with an arrow key.
const FOLLOW: u32 = WM_APP + 5;
/// Posted by the hook when Escape was released while the preview is up.
const CLOSE_PREVIEW: u32 = WM_APP + 6;
/// Posted by the hook for P (pin) and M (mode) while Explorer owns the focus.
const PIN: u32 = WM_APP + 7;
const SWITCH_MODE: u32 = WM_APP + 8;
const NAVIGATE: u32 = WM_APP + 9;
const INFOTIP: u32 = WM_APP + 10;
const INFOTIP_SCOPE: u32 = WM_APP + 11;
thread_local! {static STATE:RefCell<Option<State>>=const{RefCell::new(None)};}
struct State {
    explorer: Option<HWND>,
    explorer_view: Option<HWND>,
    explorer_focus: Option<HWND>,
    worker: Worker,
    view: ViewState,
    path: Option<PathBuf>,
    format: Option<FormatInfo>,
    generation: u64,
    started: Instant,
    report: Option<PathBuf>,
    standalone: bool,
    /// Arrow-key navigation keeps the window where the user put it.
    keep_geometry: bool,
    last_key: usize,
    input_digest: file::InputDigest,
    navigation: Option<(HWND, usize, u8)>,
    infotips_hidden: u64,
    suppressed_tips: Vec<overlays::SuppressedTip>,
}
fn with_state<T>(f: impl FnOnce(&mut State) -> T) -> Option<T> {
    STATE.with(|s| s.borrow_mut().as_mut().map(f))
}

mod action;
mod bootstrap;
mod hook;
mod navigation;
mod overlays;
mod wndproc;
use action::*;
pub use bootstrap::run;
use hook::keyboard;
use navigation::*;
use wndproc::window_proc;
