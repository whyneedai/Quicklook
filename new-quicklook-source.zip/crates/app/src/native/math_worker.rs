//! Formula cache and payload adapter; lifecycle is shared with other workers.
use quicklook_core::math::{self, Bitmap, Request};
use std::{collections::VecDeque, sync::Arc};
pub struct Service {
    client: super::worker::Client,
    cache: VecDeque<(String, bool, u32, Arc<Bitmap>)>,
    bytes: usize,
    next_id: u64,
}
impl Service {
    pub fn available(&self) -> bool {
        self.client.available()
    }
    pub fn expire(&mut self) {
        if self.client.expire() {
            self.cache.clear();
            self.bytes = 0;
        }
    }
    pub fn render(
        &mut self,
        tex: &str,
        display: bool,
        dpi: u32,
        generation: u64,
        cancel: impl Fn() -> bool,
    ) -> Option<Arc<Bitmap>> {
        if !math::structurally_valid(tex) || cancel() {
            return None;
        }
        self.client.touch();
        if let Some(index) = self
            .cache
            .iter()
            .position(|c| c.0 == tex && c.1 == display && c.2 == dpi)
        {
            let entry = self.cache.remove(index)?;
            let bitmap = entry.3.clone();
            self.cache.push_back(entry);
            return Some(bitmap);
        }
        self.next_id += 1;
        let request = Request {
            id: self.next_id,
            generation,
            tex: tex.into(),
            display,
            dpi,
        };
        let mut payload = Vec::new();
        math::write_request(&mut payload, &request).ok()?;
        let bytes = self.client.request(generation, payload, cancel).ok()?;
        let mut wire = std::io::Cursor::new(&bytes);
        let bitmap = match math::read_response(&mut wire) {
            Ok((id, g, b))
                if id == request.id && g == generation && wire.position() == bytes.len() as u64 =>
            {
                b?
            }
            _ => {
                self.client.reset();
                return None;
            }
        };
        while self.bytes + bitmap.bgra.len() > math::CACHE_BYTES {
            let old = self.cache.pop_front()?;
            self.bytes -= old.3.bgra.len();
        }
        self.bytes += bitmap.bgra.len();
        let bitmap = Arc::new(bitmap);
        self.cache
            .push_back((tex.into(), display, dpi, bitmap.clone()));
        Some(bitmap)
    }
}

impl Default for Service {
    fn default() -> Self {
        Self {
            client: super::worker::Client::new(math::WORKER),
            cache: VecDeque::new(),
            bytes: 0,
            next_id: 0,
        }
    }
}
