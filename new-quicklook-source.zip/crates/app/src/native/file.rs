use std::{
    fs::File,
    io::{self, Read},
    path::Path,
};

pub fn read_bounded(reader: impl Read, limit: usize) -> io::Result<(Vec<u8>, bool)> {
    let mut bytes = Vec::new();
    reader
        .take(limit.saturating_add(1) as u64)
        .read_to_end(&mut bytes)?;
    let truncated = bytes.len() > limit;
    bytes.truncate(limit);
    Ok((bytes, truncated))
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum PathKind {
    Local,
    Wsl,
    Rejected,
}

fn wsl_path(tail: &str) -> bool {
    let mut parts = tail.split('\\');
    let host = parts.next().unwrap_or_default();
    let distro = parts.next().unwrap_or_default();
    (host.eq_ignore_ascii_case("wsl.localhost") || host.eq_ignore_ascii_case("wsl$"))
        && !distro.is_empty()
        && !matches!(distro, "." | "..")
        && parts.clone().next().is_some()
        && parts.all(|part| !part.is_empty() && !matches!(part, "." | ".."))
        && !tail.chars().any(|c| c == ':' || c == '/' || c.is_control())
}
fn path_kind(path: &Path) -> PathKind {
    let raw = path.to_string_lossy();
    if let Some(rest) = raw.strip_prefix(r"\\?\") {
        if rest
            .get(..4)
            .is_some_and(|s| s.eq_ignore_ascii_case(r"UNC\"))
        {
            return if wsl_path(&rest[4..]) {
                PathKind::Wsl
            } else {
                PathKind::Rejected
            };
        }
        let bytes = rest.as_bytes();
        return if bytes.len() >= 3
            && bytes[0].is_ascii_alphabetic()
            && bytes[1] == b':'
            && bytes[2] == b'\\'
            && !rest.chars().skip(2).any(|c| c == ':' || c.is_control())
        {
            PathKind::Local
        } else {
            PathKind::Rejected
        };
    }
    if let Some(tail) = raw.strip_prefix(r"\\") {
        return if wsl_path(tail) {
            PathKind::Wsl
        } else {
            PathKind::Rejected
        };
    }
    if raw.starts_with("//")
        || raw.starts_with(r"\??\")
        || raw.chars().skip(2).any(|c| c == ':' || c.is_control())
    {
        PathKind::Rejected
    } else {
        PathKind::Local
    }
}

pub fn describe_error(path: &Path, error: io::Error) -> String {
    if path_kind(path) != PathKind::Wsl {
        return error.to_string();
    }
    match error.kind() {
        io::ErrorKind::PermissionDenied => {
            format!("WSL permission denied. Check Linux file/directory permissions. {error}")
        }
        _ => format!(
            "WSL file unavailable. Check the distribution name, startup state, and path. {error}"
        ),
    }
}
pub fn open_preview(path: &Path) -> io::Result<File> {
    let kind = path_kind(path);
    if kind == PathKind::Rejected {
        return Err(io::Error::other(
            "Only local files and \\\\wsl.localhost or \\\\wsl$ distribution files are supported; network, device and alternate-stream paths are disabled",
        ));
    }
    let meta = std::fs::metadata(path)?;
    if !meta.is_file() {
        return Err(io::Error::other("Select one regular file"));
    }
    #[cfg(windows)]
    {
        use std::os::windows::fs::MetadataExt;
        // Only local cloud placeholders have hydration semantics; WSL uses its OS
        // filesystem provider. The application never invokes wsl.exe to start it.
        if kind == PathKind::Local && meta.file_attributes() & (0x1000 | 0x40000 | 0x400000) != 0 {
            return Err(io::Error::other(
                "Download this cloud file before previewing",
            ));
        }
    }
    File::open(path)
}

#[derive(Clone, Default)]
pub struct InputDigest {
    pub sha256: String,
    pub bytes: usize,
    pub truncated: bool,
}
/// Hash precisely the bounded bytes passed to engine, before text normalization or
/// image decode. Only trace/smoke requests do this; normal previews incur no hash work.
pub fn input_digest(bytes: &[u8], truncated: bool) -> io::Result<InputDigest> {
    use std::fmt::Write;
    use windows::Win32::Security::Cryptography::{BCRYPT_SHA256_ALG_HANDLE, BCryptHash};
    let mut hash = [0u8; 32];
    // SAFETY: CNG owns its predefined SHA-256 pseudo-handle (never close it), and
    // borrows bounded input/output slices only for this synchronous worker call.
    unsafe { BCryptHash(BCRYPT_SHA256_ALG_HANDLE, None, bytes, &mut hash).ok() }
        .map_err(|e| io::Error::other(format!("Input SHA-256 unavailable: {e}")))?;
    let mut sha256 = String::with_capacity(64);
    for byte in hash {
        let _ = write!(sha256, "{byte:02x}");
    }
    Ok(InputDigest {
        sha256,
        bytes: bytes.len(),
        truncated,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn bounded_read() {
        assert_eq!(
            read_bounded(&b"abcd"[..], 3).unwrap(),
            (b"abc".to_vec(), true)
        );
    }
    #[test]
    fn extended_local_but_no_devices_or_streams() {
        for path in [
            r"C:\work\samples\welcome.md",
            r"\\?\C:\work\samples\welcome.md",
        ] {
            assert_eq!(path_kind(Path::new(path)), PathKind::Local);
        }
        for path in [
            r"\\server\share\a.md",
            r"\\?\UNC\server\share\a.md",
            r"\\.\pipe\a.md",
            r"\\?\GLOBALROOT\Device\a.md",
            r"D:\a.md:secret",
        ] {
            assert_eq!(path_kind(Path::new(path)), PathKind::Rejected);
        }
    }
    #[test]
    fn only_exact_wsl_hosts_and_distribution_files_are_allowed() {
        for path in [
            r"\\wsl.localhost\TestDistro\home\preview\中文.md",
            r"\\wsl$\Ubuntu\tmp\a.py",
            r"\\WSL.LOCALHOST\Ubuntu-24.04\a.png",
            r"\\?\UNC\wsl.localhost\Ubuntu\tmp\a.md",
        ] {
            assert_eq!(path_kind(Path::new(path)), PathKind::Wsl, "{path}");
        }
        for path in [
            r"\\wsl.localhost.evil\Ubuntu\a.md",
            r"\\wsl.localhost\Ubuntu",
            r"\\wsl$\\a.md",
            r"\\wsl$\..\a.md",
            r"\\wsl$\Ubuntu\..\a.md",
            r"\\wsl$\Ubuntu\a.md:secret",
            r"\\wsl$\Ubuntu\a/b.md",
            r"\\?\UNC\server\share\a.md",
            r"\\wsl.localhost.\Ubuntu\a.md",
        ] {
            assert_eq!(path_kind(Path::new(path)), PathKind::Rejected, "{path}");
        }
    }
    #[test]
    fn sha256_is_raw_input_and_reports_its_bounded_scope() {
        assert_eq!(
            input_digest(b"", false).unwrap().sha256,
            "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        );
        let hash = input_digest(b"abc", true).unwrap();
        assert_eq!(
            hash.sha256,
            "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
        );
        assert_eq!(hash.bytes, 3);
        assert!(hash.truncated);
    }
}
