use super::*;
pub(super) unsafe extern "system" fn window_proc(
    hwnd: HWND,
    msg: u32,
    wp: WPARAM,
    lp: LPARAM,
) -> LRESULT {
    // SAFETY: callback runs on the UI thread. State borrows end before reentrant window APIs.
    unsafe {
        if msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN {
            with_state(|s| s.last_key = wp.0);
            write_report();
        }
        match msg {
            WM_PAINT => {
                with_state(|s| {
                    if s.view.content.is_some()
                        && s.view.first_paint_ms.is_none()
                        && s.view.paint_start_ms == 0.0
                    {
                        s.view.paint_start_ms = s.started.elapsed().as_secs_f64() * 1000.0;
                    }
                });
                if with_state(|s| {
                    display::paint(hwnd, &mut s.view);
                    if s.view.math_paint_ms.is_none() && let Some(Content::Text(doc)) = &s.view.content {
                        let formulas: Vec<_> = doc.lines.iter().flat_map(|l| &l.spans).filter_map(|span|span.math.as_ref()).collect();
                        if !formulas.is_empty() && formulas.iter().all(|m| !matches!(m.state,quicklook_core::math::State::Pending)) {
                            s.view.math_paint_ms = Some(s.started.elapsed().as_secs_f64()*1000.0);
                        }
                    }
                    if matches!(&s.view.content,Some(Content::Image(i)) if i.is_playing(s.view.animation_started.elapsed().as_millis() as u64)) {
                        SetTimer(Some(hwnd), 3, 20, None);
                    }
                    if s.view.content.as_ref().is_some_and(|c|!matches!(c,Content::Pages(p) if p.image.is_none())) && s.view.first_paint_ms.is_none() {
                        s.view.first_paint_ms = Some(s.started.elapsed().as_secs_f64() * 1000.0);
                        s.worker.painted(s.generation);
                    }
                })
                .is_none()
                {
                    return DefWindowProcW(hwnd, msg, wp, lp);
                }
                write_report();
                LRESULT(0)
            }
            WM_ERASEBKGND => LRESULT(1),
            INFOTIP => {
                overlays::suppress_tip(hwnd, HWND(lp.0 as *mut _));
                LRESULT(0)
            }
            INFOTIP_SCOPE => {
                overlays::sync_scope(hwnd);
                LRESULT(0)
            }
            WM_NCCALCSIZE => LRESULT(0),
            READY => {
                let mut image_original: Option<(u32, u32)> = None;
                with_state(|s| {
                    if let Some(r) = s.worker.take()
                        && r.generation == s.generation
                    {
                        if let Content::Image(i) = &r.content {
                            image_original = Some(i.original);
                        }
                        if s.view.first_paint_ms.is_some() {
                            s.view.update_content(r.content);
                        } else {
                            s.view.replace_content(Some(r.content));
                        }
                        s.input_digest = r.digest;
                        s.view.load_ms = r.load_ms;
                        if s.view.ready_ms == 0.0 {
                            s.view.ready_ms = s.started.elapsed().as_secs_f64() * 1000.0;
                        }
                        s.format = r.format;
                        s.view.type_label = r
                            .format
                            .map(|f| f.display_name.to_uppercase())
                            .unwrap_or_default();
                        s.view.mode = r.mode;
                        s.view.modes = r.format.map(|f| f.modes).unwrap_or(&[]);
                    }
                });
                let keep_geometry = with_state(|s| s.keep_geometry).unwrap_or(false);
                if let Some(original) = image_original.filter(|_| !keep_geometry) {
                    // Images may need a bigger window than the text default. When the
                    // window grows, ask for the picture again so the decode (which is
                    // bounded by the viewport) matches the larger window.
                    if fit_window_to_image(hwnd, original) {
                        with_state(|s| {
                            if let Some(path) = s.path.clone() {
                                let mut rect = RECT::default();
                                let _ = GetClientRect(hwnd, &mut rect);
                                s.generation += 1;
                                s.worker.request(Request {
                                    page: None,
                                    generation: s.generation,
                                    dpi: s.view.dpi,
                                    mode: None,
                                    path,
                                    bounds: (
                                        (rect.right - 48).max(1) as u32,
                                        (rect.bottom - 130).max(1) as u32,
                                    ),
                                });
                            }
                        });
                    }
                }
                invalidate(hwnd);
                LRESULT(0)
            }
            FOLLOW => {
                let owner = HWND(lp.0 as *mut _);
                if hook::keyboard_target(hwnd, owner) {
                    with_state(|s| s.navigation = Some((owner, wp.0, 0)));
                    follow_navigation(hwnd);
                }
                LRESULT(0)
            }
            NAVIGATE => {
                navigate_from_preview(hwnd, wp.0);
                LRESULT(0)
            }
            PIN | SWITCH_MODE | CLOSE_PREVIEW => {
                if hook::keyboard_target(hwnd, HWND(lp.0 as *mut _)) {
                    match msg {
                        PIN => pin(hwnd),
                        SWITCH_MODE => switch_mode(hwnd),
                        _ => hide(hwnd),
                    }
                    write_report();
                }
                LRESULT(0)
            }
            TOGGLE => {
                let foreground = HWND(lp.0 as *mut _);
                let visible = IsWindowVisible(hwnd).as_bool();
                if visible
                    && !hook::keyboard_target(hwnd, foreground)
                    && !hook::original_list(foreground)
                {
                    return LRESULT(0);
                }
                if foreground == hwnd {
                    hide(hwnd);
                } else if GetForegroundWindow() == foreground && shell::explorer_list(foreground) {
                    match shell::selection(foreground) {
                        Ok(Some(selection))
                            if visible
                                && with_state(|s| s.explorer_view != Some(selection.view))
                                    .unwrap_or(true) => {}
                        Ok(Some(selection))
                            if visible
                                && with_state(|s| s.path.as_ref() == Some(&selection.path))
                                    .unwrap_or(false) =>
                        {
                            if overlays::uncovered(hwnd) {
                                hide(hwnd);
                            } else {
                                // Recall the same content: preserve generation, model,
                                // layout, scroll, digest and the user's window geometry.
                                show_no_activate(hwnd);
                                write_report();
                            }
                        }
                        Ok(Some(selection)) => {
                            EXPLORER.store(foreground.0 as usize, Ordering::Relaxed);
                            EXPLORER_VIEW.store(selection.view.0 as usize, Ordering::Relaxed);
                            with_state(|s| {
                                s.explorer = Some(foreground);
                                s.explorer_view = Some(selection.view);
                                s.explorer_focus = Some(selection.focus);
                            });
                            preview(
                                hwnd,
                                selection.path,
                                Some(selection.anchor),
                                CLOCK.get().map(|t| {
                                    *t + Duration::from_nanos(KEY_TICK.load(Ordering::Relaxed))
                                }),
                                None,
                                false,
                            );
                        }
                        // Nothing selected (or multiple selections) is not a preview failure.
                        // Clear any previous content, but leave Explorer in control.
                        Ok(None) => hide(hwnd),
                        Err(error) => {
                            with_state(|s| {
                                s.generation += 1;
                                s.worker.clear();
                                s.path = None;
                                s.input_digest = file::InputDigest::default();
                                s.format = None;
                                s.view.title = "Selection unavailable".into();
                                s.view.type_label.clear();
                                s.view.modes = &[];
                                s.view.replace_content(Some(Content::Error(error)));
                                s.started = Instant::now();
                                s.view.first_paint_ms = None;
                            });
                            activate(hwnd);
                            invalidate(hwnd);
                        }
                    }
                }
                LRESULT(0)
            }
            WM_KEYDOWN => {
                if !hook::keyboard_target(hwnd, GetForegroundWindow()) {
                    return LRESULT(0);
                }
                if GetKeyState(VK_CONTROL.0 as i32) < 0 {
                    if wp.0 == 0x41 {
                        with_state(|s| s.view.select_all());
                        invalidate(hwnd);
                        return LRESULT(0);
                    }
                    if wp.0 == 0x43 {
                        if let Some(text) = with_state(|s| s.view.selected_text()).flatten() {
                            let _ = clipboard::write(hwnd, &text);
                        }
                        return LRESULT(0);
                    }
                }
                match wp.0 as u16 {
                    0x1b | 0x20 if (lp.0 & (1 << 30)) == 0 => hide(hwnd),
                    0x4d if (lp.0 & (1 << 30)) == 0 => switch_mode(hwnd),
                    0x50 if (lp.0 & (1 << 30)) == 0 => pin(hwnd),
                    _ => {}
                }
                write_report();
                LRESULT(0)
            }
            WM_MOUSEWHEEL => {
                let delta = (wp.0 >> 16) as u16 as i16 as i32;
                if with_state(|s| matches!(s.view.content, Some(Content::Pages(_))))
                    .unwrap_or(false)
                    && (wp.0 & 8) == 0
                {
                    let movement = with_state(|s| {
                        s.view.wheel_remainder -= delta;
                        let amount = s.view.wheel_remainder / 120;
                        s.view.wheel_remainder %= 120;
                        amount
                    })
                    .unwrap_or(0);
                    if movement != 0 {
                        turn_page(hwnd, movement);
                    }
                    return LRESULT(0);
                }
                let mut point = POINT {
                    x: lp.0 as i16 as i32,
                    y: (lp.0 >> 16) as i16 as i32,
                };
                let _ = ScreenToClient(hwnd, &mut point);
                let mut r = RECT::default();
                let _ = GetClientRect(hwnd, &mut r);
                if with_state(|s| s.view.zoom_image(delta, point, r.right, r.bottom))
                    .unwrap_or(false)
                {
                    invalidate(hwnd);
                } else {
                    let movement = with_state(|s| {
                        s.view.wheel_remainder -= delta * 90;
                        let amount = s.view.wheel_remainder / 120;
                        s.view.wheel_remainder %= 120;
                        amount
                    })
                    .unwrap_or(0);
                    scroll(hwnd, movement);
                }
                LRESULT(0)
            }
            WM_LBUTTONDBLCLK => {
                let point = POINT {
                    x: (lp.0 & 0xffff) as i16 as i32,
                    y: ((lp.0 >> 16) & 0xffff) as i16 as i32,
                };
                // Text: select the word under the cursor (dragging extends by word).
                // Image: keep the existing canvas reset behaviour.
                let selected = with_state(|s| {
                    if matches!(s.view.content, Some(Content::Text(_))) {
                        s.view.select_word(hwnd, point)
                    } else {
                        s.view.reset_canvas();
                        false
                    }
                })
                .unwrap_or(false);
                if selected {
                    SetCapture(hwnd);
                }
                invalidate(hwnd);
                LRESULT(0)
            }
            WM_LBUTTONDOWN => {
                let point = POINT {
                    x: (lp.0 & 0xffff) as i16 as i32,
                    y: ((lp.0 >> 16) & 0xffff) as i16 as i32,
                };
                let mut r = RECT::default();
                let _ = GetClientRect(hwnd, &mut r);
                let (w, h) = (r.right.max(1), r.bottom.max(1));
                if with_state(|s| s.view.begin_pan(point)).unwrap_or(false) {
                    SetCapture(hwnd);
                    return LRESULT(0);
                }
                let scrollbar = with_state(|s| {
                    (
                        s.view.scrollbar_hit(w, h, point.x, point.y),
                        s.view.scrollbar_frame(w, h),
                    )
                });
                if let Some((hit_scroll, frame)) = scrollbar {
                    match (hit_scroll, frame) {
                        (Some(display::Hit::Thumb), Some(_)) => {
                            with_state(|s| s.view.begin_scroll_drag(point.y));
                            SetCapture(hwnd);
                            invalidate(hwnd);
                            return LRESULT(0);
                        }
                        (Some(display::Hit::PageUp), Some(frame)) => {
                            with_state(|s| {
                                s.view.scroll = s
                                    .view
                                    .scroll
                                    .saturating_sub(frame.track_len)
                                    .clamp(0, s.view.max_scroll);
                            });
                            invalidate(hwnd);
                            return LRESULT(0);
                        }
                        (Some(display::Hit::PageDown), Some(frame)) => {
                            with_state(|s| {
                                s.view.scroll = s
                                    .view
                                    .scroll
                                    .saturating_add(frame.track_len)
                                    .clamp(0, s.view.max_scroll);
                            });
                            invalidate(hwnd);
                            return LRESULT(0);
                        }
                        _ => {}
                    }
                }
                if with_state(|s| s.view.begin_selection(hwnd, point)).unwrap_or(false) {
                    SetCapture(hwnd);
                    invalidate(hwnd);
                }
                LRESULT(0)
            }
            WM_MOUSEMOVE => {
                let point = POINT {
                    x: (lp.0 & 0xffff) as i16 as i32,
                    y: ((lp.0 >> 16) & 0xffff) as i16 as i32,
                };
                let mut r = RECT::default();
                let _ = GetClientRect(hwnd, &mut r);
                let (w, h) = (r.right.max(1), r.bottom.max(1));
                if with_state(|s| s.view.panning.is_some()).unwrap_or(false) {
                    with_state(|s| s.view.pan_to(point));
                    invalidate(hwnd);
                } else if with_state(|s| s.view.selecting).unwrap_or(false) {
                    with_state(|s| s.view.extend_selection(hwnd, point));
                    invalidate(hwnd);
                } else if with_state(|s| s.view.scrollbar_drag).unwrap_or(false) {
                    with_state(|s| s.view.scroll_drag_to(w, h, point.y));
                    invalidate(hwnd);
                } else {
                    let hover = with_state(|s| {
                        matches!(
                            s.view.scrollbar_hit(w, h, point.x, point.y),
                            Some(display::Hit::Thumb)
                        )
                    })
                    .unwrap_or(false);
                    if with_state(|s| {
                        if s.view.scrollbar_hover != hover {
                            s.view.scrollbar_hover = hover;
                            true
                        } else {
                            false
                        }
                    })
                    .unwrap_or(false)
                    {
                        track_leave(hwnd);
                        invalidate(hwnd);
                    }
                }
                LRESULT(0)
            }
            WM_CAPTURECHANGED => {
                with_state(|s| {
                    s.view.panning = None;
                    s.view.selecting = false;
                    s.view.end_scroll_drag();
                });
                LRESULT(0)
            }
            WM_LBUTTONUP => {
                if with_state(|s| s.view.panning.take().is_some()).unwrap_or(false) {
                    let _ = ReleaseCapture();
                    invalidate(hwnd);
                    return LRESULT(0);
                }
                if with_state(|s| s.view.scrollbar_drag).unwrap_or(false) {
                    with_state(|s| s.view.end_scroll_drag());
                    let _ = ReleaseCapture();
                    invalidate(hwnd);
                    return LRESULT(0);
                }
                if with_state(|s| {
                    let selecting = s.view.selecting;
                    s.view.panning = None;
                    s.view.selecting = false;
                    selecting
                })
                .unwrap_or(false)
                {
                    let _ = ReleaseCapture();
                    invalidate(hwnd);
                    return LRESULT(0);
                }
                let x = (lp.0 & 0xffff) as i16 as i32;
                let y = ((lp.0 >> 16) & 0xffff) as i16 as i32;
                let mut r = RECT::default();
                let _ = GetClientRect(hwnd, &mut r);
                let dpi = GetDpiForWindow(hwnd).max(96) as i32;
                if y < 64 * dpi / 96 {
                    if x > r.right - 64 * dpi / 96 {
                        hide(hwnd);
                    } else if x > r.right - 170 * dpi / 96 {
                        pin(hwnd);
                    }
                }
                LRESULT(0)
            }
            // WM_MOUSELEAVE (0x02A3): the win32 binding exports it as a raw
            // message id, so it is spelled numerically to avoid shadowing the
            // rest of the match.
            0x02A3 => {
                if with_state(|s| {
                    let changed = s.view.scrollbar_hover;
                    s.view.scrollbar_hover = false;
                    changed
                })
                .unwrap_or(false)
                {
                    invalidate(hwnd);
                }
                LRESULT(0)
            }
            WM_NCHITTEST => {
                let mut r = RECT::default();
                let _ = GetWindowRect(hwnd, &mut r);
                let x = (lp.0 & 0xffff) as i16 as i32 - r.left;
                let y = ((lp.0 >> 16) & 0xffff) as i16 as i32 - r.top;
                let dpi = GetDpiForWindow(hwnd).max(96) as i32;
                let edge = 7 * dpi / 96;
                let right = x >= r.right - r.left - edge;
                let bottom = y >= r.bottom - r.top - edge;
                let hit = if y < edge {
                    if x < edge {
                        HTTOPLEFT
                    } else if right {
                        HTTOPRIGHT
                    } else {
                        HTTOP
                    }
                } else if bottom {
                    if x < edge {
                        HTBOTTOMLEFT
                    } else if right {
                        HTBOTTOMRIGHT
                    } else {
                        HTBOTTOM
                    }
                } else if x < edge {
                    HTLEFT
                } else if right {
                    HTRIGHT
                } else if y < 64 * dpi / 96 && x < r.right - r.left - 170 * dpi / 96 {
                    HTCAPTION
                } else {
                    HTCLIENT
                };
                LRESULT(hit as isize)
            }
            WM_GETMINMAXINFO => {
                let info = &mut *(lp.0 as *mut MINMAXINFO);
                info.ptMinTrackSize = POINT { x: 480, y: 320 };
                LRESULT(0)
            }
            WM_SIZE => {
                invalidate(hwnd);
                LRESULT(0)
            }
            WM_EXITSIZEMOVE => {
                if with_state(|s| matches!(s.view.content, Some(Content::Pages(_))))
                    .unwrap_or(false)
                {
                    turn_page(hwnd, 0);
                    return LRESULT(0);
                }
                let path = with_state(|s| {
                    if matches!(s.view.content, Some(Content::Image(_))) {
                        s.path.clone()
                    } else {
                        None
                    }
                })
                .flatten();
                if let Some(path) = path {
                    preview(hwnd, path, None, None, None, false);
                }
                LRESULT(0)
            }
            WM_DPICHANGED => {
                let dpi = (wp.0 & 0xffff) as u32;
                with_state(|s| {
                    s.view.set_dpi(dpi);
                });
                let r = *(lp.0 as *const RECT);
                let _ = SetWindowPos(
                    hwnd,
                    None,
                    r.left,
                    r.top,
                    r.right - r.left,
                    r.bottom - r.top,
                    SWP_NOZORDER | SWP_NOACTIVATE,
                );
                if with_state(|s| matches!(s.view.content, Some(Content::Pages(_))))
                    .unwrap_or(false)
                {
                    turn_page(hwnd, 0);
                }
                LRESULT(0)
            }
            TRAY => {
                if lp.0 as u32 == WM_RBUTTONUP
                    && let Ok(menu) = CreatePopupMenu()
                {
                    let _ = AppendMenuW(menu, MF_STRING, 1, w!("Exit new-quicklook"));
                    let mut p = POINT::default();
                    let _ = GetCursorPos(&mut p);
                    let _ = SetForegroundWindow(hwnd);
                    let chosen = TrackPopupMenu(
                        menu,
                        TPM_RETURNCMD | TPM_NONOTIFY,
                        p.x,
                        p.y,
                        Some(0),
                        hwnd,
                        None,
                    );
                    let _ = DestroyMenu(menu);
                    if chosen.0 == 1 {
                        let _ = DestroyWindow(hwnd);
                    }
                }
                LRESULT(0)
            }
            WM_TIMER if wp.0 == 9 => {
                overlays::sync_scope(hwnd);
                LRESULT(0)
            }
            WM_TIMER if wp.0 == 6 => {
                follow_navigation(hwnd);
                LRESULT(0)
            }
            WM_TIMER if wp.0 == 5 => {
                // Background continuation of the incremental text layout. Stop as soon
                // as the document is complete or the preview is hidden, and keep each
                // chunk short so key handling stays responsive.
                let visible = IsWindowVisible(hwnd).as_bool();
                let complete = if visible {
                    with_state(|s| display::extend_layout(&mut s.view, 10.0, 2048)).unwrap_or(true)
                } else {
                    true
                };
                if complete || !visible {
                    let _ = KillTimer(Some(hwnd), 5);
                }
                if visible {
                    invalidate(hwnd);
                }
                LRESULT(0)
            }
            WM_TIMER if wp.0 == 3 => {
                let active = with_state(
                    |s| matches!(&s.view.content,Some(Content::Image(i)) if i.is_playing(s.view.animation_started.elapsed().as_millis() as u64)),
                )
                .unwrap_or(false);
                if active {
                    invalidate(hwnd);
                } else {
                    let _ = KillTimer(Some(hwnd), 3);
                }
                LRESULT(0)
            }
            WM_TIMER => {
                let pending = with_state(|s| {
                    s.path.is_some()
                        && s.view.content.is_none()
                        && s.started.elapsed() < Duration::from_secs(12)
                })
                .unwrap_or(false);
                if pending {
                    SetTimer(Some(hwnd), 1, 100, None);
                    return LRESULT(0);
                }
                with_state(|s| {
                    if s.path.is_some() && s.view.content.is_none() {
                        s.view.replace_content(Some(Content::Error(
                            "Preview did not finish within the diagnostic time limit".into(),
                        )));
                    }
                });
                write_report();
                let _ = DestroyWindow(hwnd);
                LRESULT(0)
            }
            WM_CLOSE => {
                let _ = DestroyWindow(hwnd);
                LRESULT(0)
            }
            WM_DESTROY => {
                overlays::restore(hwnd);
                tray(hwnd, NIM_DELETE);
                with_state(|s| s.worker.stop());
                WINDOW.store(0, Ordering::Relaxed);
                PostQuitMessage(0);
                LRESULT(0)
            }
            _ => DefWindowProcW(hwnd, msg, wp, lp),
        }
    }
}
