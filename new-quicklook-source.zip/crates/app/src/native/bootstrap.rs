use super::*;
pub fn run() {
    let _ = CLOCK.set(Instant::now());
    unsafe {
        let _ = SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);
        if CoInitializeEx(None, COINIT_APARTMENTTHREADED).is_err() {
            return;
        }
        let args: Vec<_> = std::env::args_os().skip(1).collect();
        let smoke = args.first().is_some_and(|a| a == "--smoke");
        let trace = args.first().is_some_and(|a| a == "--trace");
        let idle = args.first().is_some_and(|a| a == "--idle-probe");
        if args.first().is_some_and(|a| a == "--quit") {
            if let Ok(hwnd) = FindWindowW(w!("NewQuickLook.Native.Window"), None) {
                let _ = PostMessageW(Some(hwnd), WM_CLOSE, WPARAM(0), LPARAM(0));
            }
            CoUninitialize();
            return;
        }
        if args.is_empty() && FindWindowW(w!("NewQuickLook.Native.Window"), None).is_ok() {
            CoUninitialize();
            return;
        }
        let path = if idle || trace {
            None
        } else {
            args.get(usize::from(smoke)).map(PathBuf::from)
        };
        let report = if smoke {
            args.get(2).map(PathBuf::from)
        } else if idle || trace {
            args.get(1).map(PathBuf::from)
        } else {
            None
        };
        let module = GetModuleHandleW(None).unwrap_or_default();
        let wc = WNDCLASSW {
            style: CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS,
            lpfnWndProc: Some(window_proc),
            hInstance: HINSTANCE(module.0),
            hCursor: LoadCursorW(None, IDC_ARROW).unwrap_or_default(),
            hIcon: app_icon(),
            lpszClassName: w!("NewQuickLook.Native.Window"),
            ..Default::default()
        };
        if RegisterClassW(&wc) == 0 {
            CoUninitialize();
            return;
        }
        let Ok(hwnd) = CreateWindowExW(
            WS_EX_APPWINDOW,
            w!("NewQuickLook.Native.Window"),
            w!("new-quicklook"),
            WS_POPUP | WS_THICKFRAME | WS_CLIPCHILDREN,
            180,
            120,
            860,
            640,
            None,
            None,
            Some(HINSTANCE(module.0)),
            None,
        ) else {
            CoUninitialize();
            return;
        };
        // This read-only preview window must not let the IME consume P/Space shortcuts.
        ImmAssociateContext(hwnd, HIMC::default());
        display::configure_window(hwnd);
        let dpi = GetDpiForWindow(hwnd).max(96);
        let mut view = ViewState::new(dpi);
        view.show_status |= smoke || trace || idle;
        let state = State {
            explorer: None,
            explorer_view: None,
            explorer_focus: None,
            worker: Worker::new(hwnd, report.is_some()),
            view,
            path: None,
            format: None,
            generation: 0,
            started: Instant::now(),
            report,
            standalone: path.is_some(),
            keep_geometry: false,
            last_key: 0,
            input_digest: file::InputDigest::default(),
            navigation: None,
            infotips_hidden: 0,
            suppressed_tips: Vec::new(),
        };
        STATE.with(|s| *s.borrow_mut() = Some(state));
        WINDOW.store(hwnd.0 as usize, Ordering::Relaxed);
        let overlay_events = overlays::Events::new();
        let mut hook_thread = None;
        if path.is_none() {
            tray(hwnd, NIM_ADD);
            let (tx, rx) = std::sync::mpsc::channel();
            let module_address = module.0 as usize;
            std::thread::spawn(move || {
                let hook = SetWindowsHookExW(
                    WH_KEYBOARD_LL,
                    Some(keyboard),
                    Some(HINSTANCE(module_address as *mut _)),
                    0,
                );
                let id = GetCurrentThreadId();
                let _ = tx.send((id, hook.is_ok()));
                if let Ok(hook) = hook {
                    let mut msg = MSG::default();
                    while GetMessageW(&mut msg, None, 0, 0).0 > 0 {
                        let _ = TranslateMessage(&msg);
                        DispatchMessageW(&msg);
                    }
                    let _ = UnhookWindowsHookEx(hook);
                }
            });
            if let Ok((id, true)) = rx.recv() {
                hook_thread = Some(id);
            } else {
                let _ = MessageBoxW(
                    None,
                    w!("Could not install the Space-key hook."),
                    w!("new-quicklook"),
                    MB_ICONERROR,
                );
                let _ = DestroyWindow(hwnd);
            }
        }
        if let Some(path) = path {
            preview(hwnd, path, Some(POINT { x: 140, y: 80 }), None, None, false);
        }
        if smoke || idle {
            SetTimer(Some(hwnd), 1, 1500, None);
        }
        let mut msg = MSG::default();
        while GetMessageW(&mut msg, None, 0, 0).0 > 0 {
            let _ = TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
        if let Some(id) = hook_thread {
            let _ = PostThreadMessageW(id, WM_QUIT, WPARAM(0), LPARAM(0));
        }
        drop(overlay_events);
        STATE.with(|s| *s.borrow_mut() = None);
        shell::clear_cache();
        CoUninitialize();
    }
}
