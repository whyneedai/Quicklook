//! COM objects stay on the main STA. Returned PIDLs/strings use CoTaskMemFree.
use std::path::PathBuf;
use windows::{
    Win32::{
        Foundation::*,
        System::{Com::*, SystemServices::SFGAO_FOLDER, Variant::VARIANT},
        UI::{Shell::*, WindowsAndMessaging::*},
    },
    core::Interface,
};

// Cache only the Shell collection service, never a view, path, or selection.
// It is queried afresh for every keypress and released before STA teardown.
thread_local! { static WINDOWS: std::cell::RefCell<Option<IShellWindows>> = const { std::cell::RefCell::new(None) }; }
fn shell_windows() -> windows::core::Result<IShellWindows> {
    WINDOWS.with(|slot| {
        if let Some(windows) = slot.borrow().as_ref() {
            return Ok(windows.clone());
        }
        let windows: IShellWindows = unsafe { CoCreateInstance(&ShellWindows, None, CLSCTX_ALL)? };
        *slot.borrow_mut() = Some(windows.clone());
        Ok(windows)
    })
}
thread_local! { static TRACE: std::cell::RefCell<String> = const { std::cell::RefCell::new(String::new()) }; }
pub fn trace() -> String {
    TRACE.with(|s| s.borrow().clone())
}
fn record(value: impl AsRef<str>) {
    TRACE.with(|s| {
        s.borrow_mut().push_str(value.as_ref());
    });
}
pub fn clear_cache() {
    WINDOWS.with(|slot| {
        slot.borrow_mut().take();
    });
}
pub fn class(hwnd: HWND) -> String {
    let mut b = [0u16; 128];
    let n = unsafe { GetClassNameW(hwnd, &mut b) };
    String::from_utf16_lossy(&b[..n.max(0) as usize])
}
pub fn explorer_list(hwnd: HWND) -> bool {
    if !matches!(class(hwnd).as_str(), "CabinetWClass" | "ExploreWClass") {
        return false;
    }
    let thread = unsafe { GetWindowThreadProcessId(hwnd, None) };
    let mut info = GUITHREADINFO {
        cbSize: std::mem::size_of::<GUITHREADINFO>() as u32,
        ..Default::default()
    };
    if unsafe { GetGUIThreadInfo(thread, &mut info) }.is_err() {
        return false;
    }
    // Allow only the file-view focus. Rename/search/address edit controls pass through.
    matches!(
        class(info.hwndFocus).as_str(),
        "DirectUIHWND" | "SysListView32"
    )
}
pub struct Selection {
    pub path: PathBuf,
    pub anchor: POINT,
    pub view: HWND,
    pub focus: HWND,
}
pub fn selection(foreground: HWND) -> Result<Option<Selection>, String> {
    unsafe {
        resolve(foreground, None).map_err(|e| {
            clear_cache();
            format!("Explorer selection unavailable: {e}")
        })
    }
}
pub fn navigation(foreground: HWND, view: HWND, key: usize) -> Result<Option<Selection>, String> {
    unsafe {
        resolve(foreground, Some((view, key)))
            .map_err(|e| format!("Explorer navigation unavailable: {e}"))
    }
}
unsafe fn resolve(
    foreground: HWND,
    navigation: Option<(HWND, usize)>,
) -> windows::core::Result<Option<Selection>> {
    // SAFETY: caller runs on the initialized STA; all COM interfaces are local to this call.
    unsafe {
        TRACE.with(|s| s.borrow_mut().clear());
        let started = std::time::Instant::now();
        let mut focus_info = GUITHREADINFO {
            cbSize: std::mem::size_of::<GUITHREADINFO>() as u32,
            ..Default::default()
        };
        GetGUIThreadInfo(GetWindowThreadProcessId(foreground, None), &mut focus_info)?;
        let focus = focus_info.hwndFocus;
        record(format!(
            "owner={:?} focus={:?} {} ; ",
            foreground,
            focus,
            class(focus)
        ));
        let windows = shell_windows()?;
        record(format!(
            "[:{}ms] collection",
            started.elapsed().as_micros() / 1000
        ));
        for index in 0..windows.Count()? {
            let Ok(dispatch) = windows.Item(&VARIANT::from(index)) else {
                continue;
            };
            let Ok(browser) = dispatch.cast::<IWebBrowserApp>() else {
                continue;
            };
            if browser.HWND()?.0 != foreground.0 as isize {
                continue;
            }
            record(format!(
                "[:{}ms] match entry={index}",
                started.elapsed().as_micros() / 1000
            ));
            let provider: IServiceProvider = browser.cast()?;
            let shell: IShellBrowser = stage(
                provider.QueryService(&SID_STopLevelBrowser),
                "QueryService browser",
            )?;
            let view = stage(shell.QueryActiveShellView(), "Active view")?;
            let view_hwnd = view.GetWindow()?;
            if navigation.is_some_and(|(expected, _)| expected != view_hwnd) {
                continue;
            }
            record(format!(
                "entry={index} view={view_hwnd:?} visible={} owns_focus={} ; ",
                IsWindowVisible(view_hwnd).as_bool(),
                focus == view_hwnd || IsChild(view_hwnd, focus).as_bool()
            ));
            if !IsWindowVisible(view_hwnd).as_bool()
                || (focus != view_hwnd && !IsChild(view_hwnd, focus).as_bool())
            {
                continue;
            }
            record(format!(
                "[:{}ms] view ok",
                started.elapsed().as_micros() / 1000
            ));
            let folder: IFolderView2 = stage(view.cast(), "IFolderView2")?;
            // An empty selection is normal (including immediately after navigation/startup).
            // Windows 11 can return ERROR_NOT_FOUND from GetSelection(false) in this state.
            // Do not substitute the focused item: focus can remain on an unselected old file.
            // Transient "view not ready" HRESULTs (element not found / general failure) are
            // treated as "nothing selected right now" instead of a preview failure, so the
            // startup race never flashes a scary error window.
            let count = match folder.ItemCount(SVGIO_SELECTION) {
                Ok(count) => count,
                Err(error) if transient(&error) => return Ok(None),
                Err(error) => return Err(error),
            };
            record(format!("selected_count={count} ; "));
            if count != 1 {
                record(format!(
                    "[:{}ms] done(none)",
                    started.elapsed().as_micros() / 1000
                ));
                return Ok(None);
            }
            let selected = match folder.GetSelection(false) {
                Ok(items) => items,
                Err(error) if transient(&error) => {
                    record(format!(
                        "[:{}ms] done(transient)",
                        started.elapsed().as_micros() / 1000
                    ));
                    return Ok(None);
                }
                Err(error) => {
                    // Selection may change between the count and the collection query.
                    if folder.ItemCount(SVGIO_SELECTION)? != 1 {
                        return Ok(None);
                    }
                    return Err(error);
                }
            };
            if selected.GetCount()? != 1 {
                return Ok(None);
            }
            let mut item = selected.GetItemAt(0)?;
            if item.GetAttributes(SFGAO_FOLDER)?.0 != 0 {
                let Some((_, key)) = navigation else {
                    return Ok(None);
                };
                // Native arrows choose the geometric neighbour; if that is a directory,
                // continue in the current view's index order to a regular file. Never
                // enumerate beyond the established 5000-item navigation budget.
                let count = folder.ItemCount(SVGIO_ALLVIEW)?.min(5000);
                let step = if matches!(key, 0x25 | 0x26) { -1 } else { 1 };
                let mut index = folder.GetSelectedItem(-1)? + step;
                let mut found = false;
                while index >= 0 && index < count {
                    let candidate: IShellItem = folder.GetItem(index)?;
                    if candidate.GetAttributes(SFGAO_FOLDER)?.0 == 0 {
                        folder.SelectItem(
                            index,
                            (SVSI_SELECT.0
                                | SVSI_DESELECTOTHERS.0
                                | SVSI_FOCUSED.0
                                | SVSI_ENSUREVISIBLE.0) as u32,
                        )?;
                        item = candidate;
                        found = true;
                        break;
                    }
                    index += step;
                }
                if !found {
                    return Ok(None);
                }
            }
            let raw = item.GetDisplayName(SIGDN_FILESYSPATH)?;
            let path = raw.to_string();
            CoTaskMemFree(Some(raw.0.cast()));
            let mut bounds = RECT::default();
            GetWindowRect(foreground, &mut bounds)?;
            let mut point = POINT {
                x: bounds.left + 80,
                y: bounds.top + 100,
            };
            if let Ok(index) = folder.GetFocusedItem()
                && let Ok(pidl) = folder.Item(index)
            {
                if let Ok(mut pos) = folder.GetItemPosition(pidl)
                    && let Ok(view_hwnd) = view.GetWindow()
                {
                    let _ = windows::Win32::Graphics::Gdi::ClientToScreen(view_hwnd, &mut pos);
                    if pos.x >= bounds.left
                        && pos.x <= bounds.right
                        && pos.y >= bounds.top
                        && pos.y <= bounds.bottom
                    {
                        point = pos;
                    }
                }
                CoTaskMemFree(Some(pidl.cast()));
            }
            let path = PathBuf::from(path?);
            record(format!(
                "resolved={} [:{}ms] done",
                path.display(),
                started.elapsed().as_micros() / 1000
            ));
            return Ok(Some(Selection {
                path,
                anchor: point,
                view: view_hwnd,
                focus,
            }));
        }
        Err(windows::core::Error::from_hresult(E_FAIL))
    }
}

fn stage<T>(result: windows::core::Result<T>, label: &str) -> windows::core::Result<T> {
    result.map_err(|error| windows::core::Error::new(error.code(), format!("{label}: {error}")))
}

/// Transient Shell "view not ready" codes observed on Windows 11 right after
/// startup/navigation: ELEMENT_NOT_FOUND (0x80070490) and E_FAIL (0x80004005).
/// They mean "no usable single selection right now", not a broken viewer.
fn transient(error: &windows::core::Error) -> bool {
    matches!(error.code().0 as u32, 0x80070490 | 0x80004005)
}

/// Diagnostics go into a hand-built JSON report: keep them quote/backslash free.
pub(super) fn sanitized(value: String) -> String {
    value.replace(['"', '\\'], "'")
}
