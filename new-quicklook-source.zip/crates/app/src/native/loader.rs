use super::file::{InputDigest, describe_error, input_digest, open_preview, read_bounded};
use quicklook_core::{FormatInfo, Input, Output as Content, Preview, PreviewError, PreviewMode};
use quicklook_engine::Engine;
use std::{
    io::{Read, Seek},
    path::PathBuf,
    sync::{Arc, Condvar, Mutex},
    thread,
};
use windows::Win32::{
    Foundation::{HWND, LPARAM, WPARAM},
    UI::WindowsAndMessaging::PostMessageW,
};
pub struct Request {
    pub page: Option<u32>,
    pub dpi: u32,
    pub generation: u64,
    pub path: PathBuf,
    pub bounds: (u32, u32),
    pub mode: Option<PreviewMode>,
}
pub struct Loaded {
    pub load_ms: f64,
    pub generation: u64,
    pub content: Content,
    pub format: Option<FormatInfo>,
    pub mode: PreviewMode,
    pub digest: InputDigest,
}
#[derive(Default)]
struct Queue {
    latest: Option<u64>,
    painted: Option<u64>,
    request: Option<Request>,
    result: Option<Loaded>,
    stopping: bool,
}
#[derive(Clone)]
pub struct Worker(Arc<(Mutex<Queue>, Condvar)>);
impl Worker {
    pub fn new(hwnd: HWND, diagnostics: bool) -> Self {
        let shared = Arc::new((Mutex::new(Queue::default()), Condvar::new()));
        let worker = Self(shared.clone());
        let handle = hwnd.0 as usize;
        thread::spawn(move || {
            let mut math = super::math_worker::Service::default();
            let mut pages = super::page_worker::Service::default();
            loop {
                let request = {
                    let (lock, ready) = &*shared;
                    let mut q = lock.lock().unwrap_or_else(|e| e.into_inner());
                    while q.request.is_none() && !q.stopping {
                        if q.latest.is_none() {
                            pages.clear();
                        }
                        q = ready
                            .wait_timeout(q, std::time::Duration::from_secs(1))
                            .unwrap_or_else(|e| e.into_inner())
                            .0;
                        math.expire();
                        pages.expire();
                    }
                    if q.stopping {
                        break;
                    }
                    q.request.take().expect("request checked")
                };
                let load_started = std::time::Instant::now();
                let cancelled = || {
                    let q = shared.0.lock().unwrap_or_else(|e| e.into_inner());
                    q.stopping || q.latest != Some(request.generation)
                };
                let loaded = if let Some(index) = request.page.filter(|_| pages.available()) {
                    let (format, mode, digest) = pages.metadata.as_ref().unwrap().clone();
                    pages
                        .page(index, request.bounds, request.generation, cancelled)
                        .map(|p| {
                            (
                                Preview {
                                    format,
                                    mode,
                                    output: Content::Pages(p),
                                },
                                digest,
                            )
                        })
                        .map_err(PreviewError::InvalidData)
                } else {
                    if request.page.is_none() {
                        pages.metadata = None;
                    }
                    load(&request.path, request.bounds, request.mode, diagnostics).and_then(
                        |(mut preview, digest)| {
                            if let Content::Pages(model) = preview.output {
                                let result = pages
                                    .open(
                                        model,
                                        request.page.unwrap_or(0),
                                        request.bounds,
                                        request.generation,
                                        cancelled,
                                    )
                                    .map_err(PreviewError::InvalidData)?;
                                pages.metadata =
                                    Some((preview.format, preview.mode, digest.clone()));
                                preview.output = Content::Pages(result);
                            } else {
                                pages.clear();
                            }
                            Ok((preview, digest))
                        },
                    )
                };
                if loaded.is_err() {
                    pages.clear();
                }
                let load_ms = load_started.elapsed().as_secs_f64() * 1000.0;
                let (content, format, mode, digest) = match loaded {
                    Ok((preview, digest)) => {
                        (preview.output, Some(preview.format), preview.mode, digest)
                    }
                    Err(error) => (
                        Content::Error(error.to_string()),
                        None,
                        PreviewMode::Rendered,
                        InputDigest::default(),
                    ),
                };
                let pending = match &content {
                    Content::Text(doc)
                        if doc.lines.iter().flat_map(|l| &l.spans).any(|s| {
                            matches!(
                                s.math.as_ref().map(|m| &m.state),
                                Some(quicklook_core::math::State::Pending)
                            )
                        }) =>
                    {
                        Some(doc.clone())
                    }
                    _ => None,
                };
                let notify = || unsafe {
                    let _ = PostMessageW(
                        Some(HWND(handle as *mut _)),
                        super::READY,
                        WPARAM(0),
                        LPARAM(0),
                    );
                };
                let (lock, ready) = &*shared;
                let mut q = lock.lock().unwrap_or_else(|e| e.into_inner());
                if q.stopping {
                    break;
                }
                if q.latest != Some(request.generation) {
                    continue;
                }
                q.result = Some(Loaded {
                    load_ms,
                    generation: request.generation,
                    content,
                    format,
                    mode,
                    digest: digest.clone(),
                });
                drop(q);
                notify();
                let Some(mut doc) = pending else {
                    continue;
                };
                // Ordinary Markdown must reach EndPaint before formula work starts.
                let mut q = lock.lock().unwrap_or_else(|e| e.into_inner());
                while q.painted != Some(request.generation)
                    && q.latest == Some(request.generation)
                    && !q.stopping
                {
                    q = ready.wait(q).unwrap_or_else(|e| e.into_inner());
                }
                drop(q);
                let cancelled = || {
                    let q = lock.lock().unwrap_or_else(|e| e.into_inner());
                    q.stopping || q.latest != Some(request.generation)
                };
                let mut bytes = 0usize;
                let mut failed = false;
                for span in doc.lines.iter_mut().flat_map(|l| &mut l.spans) {
                    if cancelled() {
                        break;
                    }
                    let Some(formula) = &mut span.math else {
                        continue;
                    };
                    if !matches!(formula.state, quicklook_core::math::State::Pending) {
                        continue;
                    }
                    let bitmap = if failed {
                        None
                    } else {
                        math.render(
                            &span.text,
                            formula.display,
                            request.dpi,
                            request.generation,
                            cancelled,
                        )
                    };
                    if bitmap.is_none() && !math.available() {
                        failed = true;
                    }
                    formula.state = match bitmap {
                        Some(bitmap)
                            if bytes + bitmap.bgra.len() <= quicklook_core::math::CACHE_BYTES =>
                        {
                            bytes += bitmap.bgra.len();
                            quicklook_core::math::State::Ready(bitmap)
                        }
                        _ => quicklook_core::math::State::Fallback,
                    };
                }
                let mut q = lock.lock().unwrap_or_else(|e| e.into_inner());
                if !q.stopping && q.latest == Some(request.generation) {
                    q.result = Some(Loaded {
                        load_ms,
                        generation: request.generation,
                        content: Content::Text(doc),
                        format,
                        mode,
                        digest,
                    });
                    drop(q);
                    notify();
                }
            }
        });
        worker
    }
    pub fn request(&self, request: Request) {
        let (lock, ready) = &*self.0;
        let mut q = lock.lock().unwrap_or_else(|e| e.into_inner());
        q.latest = Some(request.generation);
        q.painted = None;
        q.request = Some(request);
        q.result = None;
        ready.notify_one();
    }
    pub fn painted(&self, generation: u64) {
        let (lock, ready) = &*self.0;
        lock.lock().unwrap_or_else(|e| e.into_inner()).painted = Some(generation);
        ready.notify_one();
    }
    pub fn take(&self) -> Option<Loaded> {
        self.0
            .0
            .lock()
            .unwrap_or_else(|e| e.into_inner())
            .result
            .take()
    }
    pub fn clear(&self) {
        let mut q = self.0.0.lock().unwrap_or_else(|e| e.into_inner());
        q.latest = None;
        q.request = None;
        q.result = None;
        self.0.1.notify_one();
    }
    pub fn stop(&self) {
        let (lock, ready) = &*self.0;
        lock.lock().unwrap_or_else(|e| e.into_inner()).stopping = true;
        ready.notify_one();
    }
}
pub fn load(
    path: &std::path::Path,
    bounds: (u32, u32),
    mode: Option<PreviewMode>,
    diagnostics: bool,
) -> Result<(Preview, InputDigest), PreviewError> {
    let mut file = open_preview(path).map_err(|e| {
        PreviewError::Io(format!("{}: {}", path.display(), describe_error(path, e)))
    })?;
    let mut prefix = [0u8; 512];
    let n = file
        .read(&mut prefix)
        .map_err(|e| PreviewError::Io(describe_error(path, e)))?;
    let engine = Engine::default();
    let info = engine.detect(path, &prefix[..n])?;
    file.rewind()
        .map_err(|e| PreviewError::Io(describe_error(path, e)))?;
    if !info.limits.allow_truncation
        && file
            .metadata()
            .map_err(|e| PreviewError::Io(describe_error(path, e)))?
            .len()
            > info.limits.max_input_bytes as u64
    {
        return Err(PreviewError::LimitExceeded("file size"));
    }
    let (bytes, truncated) = read_bounded(file, info.limits.max_input_bytes)
        .map_err(|e| PreviewError::Io(describe_error(path, e)))?;
    let mode = mode.unwrap_or(info.modes[0]);
    let input = Input {
        bytes: &bytes,
        viewport: bounds,
        mode,
        truncated,
    };
    let digest = if diagnostics {
        input_digest(&bytes, truncated).map_err(|e| PreviewError::Io(e.to_string()))?
    } else {
        InputDigest::default()
    };
    Ok((engine.preview(info.id, input)?, digest))
}
