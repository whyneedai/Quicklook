//! Production inventory is also exported for delivery/process verification scripts.
pub const SPECS: &[quicklook_core::worker::Spec] = &[
    quicklook_core::math::WORKER,
    quicklook_core::pages::PDF_WORKER,
];
pub fn export(path: &std::path::Path) -> std::io::Result<()> {
    let entries: Vec<_> = SPECS.iter().map(|s| format!("{{\"id\":{},\"exe\":\"{}\",\"memory_bytes\":{},\"timeout_ms\":{},\"idle_ms\":{},\"cache_bytes\":{},\"request_bytes\":{},\"response_bytes\":{}}}",s.id,s.exe,s.memory_bytes,s.timeout_ms,s.idle_ms,s.cache_bytes,s.request_bytes,s.response_bytes)).collect();
    std::fs::write(
        path,
        format!(
            "{{\"protocol_version\":{},\"workers\":[{}]}}\n",
            quicklook_core::worker::VERSION,
            entries.join(",")
        ),
    )
}
