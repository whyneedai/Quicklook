use quicklook_core::*;
pub struct Component;
impl FormatPreview for Component {
    fn info(&self) -> FormatInfo {
        super::common::info("bmp", "BMP", &["bmp"], &[b"BM"])
    }
    fn preview(&self, input: &Input<'_>) -> Result<Output, PreviewError> {
        super::common::check(input)?;
        super::common::decode(input.bytes, input.viewport, super::common::Codec::Bmp)
            .map(Output::Image)
            .map_err(PreviewError::InvalidData)
    }
}
