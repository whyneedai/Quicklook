use quicklook_core::*;
pub struct Component;
impl FormatPreview for Component {
    /// HEIC/HEIF/AVIF share the ISO-BMFF container; the brand is validated in
    /// `common::decode`. The system codec may be absent (Store extensions) and then
    /// the preview reports a clear error instead of guessing.
    fn info(&self) -> FormatInfo {
        super::common::info("heif", "HEIF", &["heic", "heif", "avif"], &[])
    }
    fn preview(&self, input: &Input<'_>) -> Result<Output, PreviewError> {
        super::common::check(input)?;
        super::common::decode(input.bytes, input.viewport, super::common::Codec::Heif)
            .map(Output::Image)
            .map_err(PreviewError::InvalidData)
    }
}
