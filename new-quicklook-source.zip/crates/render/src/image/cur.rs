use quicklook_core::*;
pub struct Component;
impl FormatPreview for Component {
    fn info(&self) -> FormatInfo {
        super::common::info("cur", "Cursor", &["cur"], &[b"\0\0\x02\0"])
    }
    fn preview(&self, input: &Input<'_>) -> Result<Output, PreviewError> {
        super::common::check(input)?;
        super::common::decode(input.bytes, input.viewport, super::common::Codec::Cur)
            .map(Output::Image)
            .map_err(PreviewError::InvalidData)
    }
}
