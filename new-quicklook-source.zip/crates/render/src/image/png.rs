//! PNG: WIC first (Adam7/interlace, palette, 16-bit), bounded scanline fallback.
//!
//! Measured on 2026-09-29 (archive/wic-compare): WIC ties or wins around
//! 800×600–1024×768 and is the only path that decodes Adam7; the hand-written
//! scanline decoder stays faster on very large images (4096×3072: 43ms vs 55ms,
//! ~7MB less private memory) because it only decodes the rows the bounded canvas
//! needs. So: WIC by default, scanline for large non-interlaced sources.
use quicklook_core::*;
use std::io::{BufRead, Cursor, Seek};
/// Above this many source pixels the bounded scanline decoder is materially faster.
const SCANLINE_THRESHOLD: u64 = 2_000_000;

/// Minimal IHDR read: signature, width, height, interlace flag.
fn ihdr(bytes: &[u8]) -> Result<(u32, u32, bool), String> {
    if bytes.len() < 29 || !bytes.starts_with(b"\x89PNG\r\n\x1a\n") || &bytes[12..16] != b"IHDR" {
        return Err("Invalid PNG header".into());
    }
    let be = |o: usize| u32::from_be_bytes([bytes[o], bytes[o + 1], bytes[o + 2], bytes[o + 3]]);
    Ok((be(16), be(20), bytes[28] == 1))
}

pub fn decode(bytes: &[u8], bounds: (u32, u32)) -> Result<Image, String> {
    let (w, h, interlaced) = ihdr(bytes)?;
    if !interlaced && u64::from(w) * u64::from(h) > SCANLINE_THRESHOLD {
        return scanline(Cursor::new(bytes), bounds);
    }
    match super::common::decode(bytes, bounds, super::common::Codec::Png) {
        Ok(image) => Ok(image),
        Err(error) if !interlaced => scanline(Cursor::new(bytes), bounds).map_err(|_| error),
        Err(error) => Err(error),
    }
}

/// Bounded scanline decoder: decodes only the rows the target canvas samples.
pub fn scanline(reader: impl BufRead + Seek, bounds: (u32, u32)) -> Result<Image, String> {
    let mut decoder = png::Decoder::new_with_limits(
        reader,
        png::Limits {
            bytes: 8 * 1024 * 1024,
        },
    );
    decoder.set_transformations(png::Transformations::EXPAND | png::Transformations::STRIP_16);
    let mut reader = decoder.read_info().map_err(|e| e.to_string())?;
    let info = reader.info();
    let (w, h) = (info.width, info.height);
    if info.interlaced {
        return Err("Interlaced PNG is not supported by the bounded scanline preview yet".into());
    }
    let (ow, oh) = super::common::dimensions(w, h, bounds)?;
    let channels = reader.output_color_type().0.samples();
    let mut bgra = vec![0; ow as usize * oh as usize * 4];
    let mut out_y = 0;
    for y in 0..h {
        let row = reader
            .next_row()
            .map_err(|e| e.to_string())?
            .ok_or("Missing PNG row")?;
        if out_y >= oh || y != ((u64::from(out_y) * u64::from(h)) / u64::from(oh)) as u32 {
            continue;
        }
        for x in 0..ow {
            let sx = (u64::from(x) * u64::from(w) / u64::from(ow)) as usize;
            let p = &row.data()[sx * channels..(sx + 1) * channels];
            let (r, g, b, a) = match channels {
                1 => (p[0], p[0], p[0], 255),
                2 => (p[0], p[0], p[0], p[1]),
                3 => (p[0], p[1], p[2], 255),
                4 => (p[0], p[1], p[2], p[3]),
                _ => return Err("Unsupported PNG channels".into()),
            };
            let offset = ((out_y * ow + x) * 4) as usize;
            bgra[offset..offset + 4].copy_from_slice(&[b, g, r, a]);
        }
        out_y += 1;
    }
    reader.finish().map_err(|e| e.to_string())?;
    super::common::checker(&mut bgra, ow);
    Ok(Image {
        width: ow,
        height: oh,
        original: (w, h),
        bgra,
        animation: None,
    })
}

pub struct Png;
impl FormatPreview for Png {
    fn info(&self) -> FormatInfo {
        super::common::info("png", "PNG", &["png"], &[b"\x89PNG\r\n\x1a\n"])
    }
    fn preview(&self, input: &Input<'_>) -> Result<Output, PreviewError> {
        super::common::check(input)?;
        decode(input.bytes, input.viewport)
            .map(Output::Image)
            .map_err(PreviewError::InvalidData)
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    use proptest::prelude::*;
    fn fixture() -> Vec<u8> {
        let mut b = Vec::new();
        {
            let mut e = png::Encoder::new(&mut b, 64, 32);
            e.set_color(png::ColorType::Rgba);
            e.set_depth(png::BitDepth::Eight);
            let mut w = e.write_header().unwrap();
            w.write_image_data(&[10, 20, 30, 255].repeat(64 * 32))
                .unwrap();
        }
        b
    }
    #[test]
    fn scales_and_converts() {
        let i = scanline(Cursor::new(fixture()), (16, 16)).unwrap();
        assert_eq!((i.width, i.height), (16, 8));
        assert_eq!(&i.bgra[..4], &[30, 20, 10, 255]);
        assert_eq!(i.bgra.len(), 16 * 8 * 4);
    }
    #[test]
    fn interlaced_is_rejected_by_the_scanline_path() {
        let mut b = Vec::new();
        let mut info = png::Info::with_size(8, 8);
        info.color_type = png::ColorType::Rgb;
        info.bit_depth = png::BitDepth::Eight;
        info.interlaced = true;
        {
            let encoder = png::Encoder::with_info(&mut b, info).unwrap();
            let mut writer = encoder.write_header().unwrap();
            writer.write_image_data(&[0; 8 * 8 * 3]).unwrap();
        }
        let error = scanline(Cursor::new(b), (8, 8)).unwrap_err();
        assert!(error.contains("Interlaced"), "{error}");
    }
    #[cfg(windows)]
    #[test]
    fn interlaced_decodes_through_wic() {
        let bytes = include_bytes!("../../../../samples/images/interlaced.png");
        let image = decode(bytes, (64, 64)).unwrap();
        assert!(image.width <= 64 && image.height <= 64);
        assert_eq!(
            image.bgra.len(),
            image.width as usize * image.height as usize * 4
        );
    }
    #[test]
    fn zero_viewport_rejected() {
        assert!(scanline(Cursor::new(fixture()), (0, 100)).is_err());
    }
    #[test]
    fn truncated_png_rejected() {
        let mut b = fixture();
        b.truncate(b.len() / 2);
        assert!(scanline(Cursor::new(b), (16, 16)).is_err());
    }
    proptest! {
        #![proptest_config(ProptestConfig::with_cases(128))]
        #[test] fn malformed_never_panics(b in proptest::collection::vec(any::<u8>(),0..8192)) { let _=scanline(Cursor::new(b.clone()),(100,100)); let _=decode(&b,(100,100)); }
        #[test] fn mutated_png_never_panics(index in 0usize..200,value in any::<u8>()) { let mut b=fixture(); let n=b.len(); b[index%n]=value; let _=scanline(Cursor::new(b.clone()),(32,32)); let _=decode(&b,(32,32)); }
    }
}
