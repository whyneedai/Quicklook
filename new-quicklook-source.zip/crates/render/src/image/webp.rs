//! Pure Rust WebP, with the explicitly approved bounded source-buffer exception.
use quicklook_core::*;
pub struct Component;
impl FormatPreview for Component {
    fn info(&self) -> FormatInfo {
        super::common::info("webp", "WebP", &["webp"], &[])
    }
    fn preview(&self, input: &Input<'_>) -> Result<Output, PreviewError> {
        super::common::check(input)?;
        decode(input)
            .map(Output::Image)
            .map_err(PreviewError::InvalidData)
    }
}
fn decode(input: &Input<'_>) -> Result<Image, String> {
    let mut decoder = image_webp::WebPDecoder::new(std::io::Cursor::new(input.bytes))
        .map_err(|e| e.to_string())?;
    let (w, h) = decoder.dimensions();
    if u64::from(w) * u64::from(h) > 4_000_000 {
        return Err("WebP exceeds the 4 million source-pixel budget".into());
    }
    let (ow, oh) = super::common::dimensions(w, h, input.viewport)?;
    let size = decoder
        .output_buffer_size()
        .ok_or("Invalid WebP buffer size")?;
    if size > 16_000_000 {
        return Err("WebP source buffer exceeds budget".into());
    }
    // Includes source buffer in the 64 MiB requested decode budget. The upstream
    // decoder documents that some scratch allocations do not honor its limit;
    // this is a bounded best-effort policy, not a process memory sandbox.
    decoder.set_memory_limit(64 * 1024 * 1024 - size);
    let count = if decoder.is_animated() {
        decoder.num_frames() as usize
    } else {
        1
    };
    let output_size = ow as usize * oh as usize * 4;
    if u64::from(w) * u64::from(h) * count as u64 > 100_000_000
        || count == 0
        || count > MAX_ANIMATION_FRAMES
        || output_size * count > MAX_ANIMATION_BYTES
    {
        return Err("WebP animation exceeds frame/memory budget".into());
    }
    let mut source = vec![0; size];
    let channels = if decoder.has_alpha() { 4 } else { 3 };
    let mut frames = Vec::with_capacity(count);
    let mut delays_ms = Vec::with_capacity(count);
    for _ in 0..count {
        let delay = if decoder.is_animated() {
            decoder.read_frame(&mut source).map_err(|e| e.to_string())?
        } else {
            decoder.read_image(&mut source).map_err(|e| e.to_string())?;
            100
        };
        let mut bgra = vec![0; output_size];
        for y in 0..oh {
            for x in 0..ow {
                let sx = u64::from(x) * u64::from(w) / u64::from(ow);
                let sy = u64::from(y) * u64::from(h) / u64::from(oh);
                let i = (sy as usize * w as usize + sx as usize) * channels;
                let o = (y as usize * ow as usize + x as usize) * 4;
                bgra[o..o + 4].copy_from_slice(&[
                    source[i + 2],
                    source[i + 1],
                    source[i],
                    if channels == 4 { source[i + 3] } else { 255 },
                ]);
            }
        }
        super::common::checker(&mut bgra, ow);
        frames.push(bgra);
        delays_ms.push(delay.clamp(20, 600_000));
    }
    let plays = match decoder.loop_count() {
        image_webp::LoopCount::Forever => 0,
        image_webp::LoopCount::Times(n) => u32::from(n.get()),
    };
    let bgra = frames.remove(0);
    Ok(Image {
        width: ow,
        height: oh,
        original: (w, h),
        bgra,
        animation: if frames.is_empty() {
            None
        } else {
            Some(Animation {
                frames,
                delays_ms,
                plays,
            })
        },
    })
}
