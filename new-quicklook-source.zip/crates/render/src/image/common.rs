//! Shared image limits/compositing; format registration stays in each component.
use quicklook_core::*;
pub fn info(
    id: &'static str,
    name: &'static str,
    extensions: &'static [&'static str],
    magic: &'static [&'static [u8]],
) -> FormatInfo {
    FormatInfo {
        id,
        display_name: name,
        kind: Kind::Image,
        extensions,
        magic,
        modes: &[PreviewMode::Rendered],
        limits: Limits {
            max_input_bytes: PNG_LIMIT,
            allow_truncation: false,
        },
    }
}
pub fn check(input: &Input<'_>) -> Result<(), PreviewError> {
    if input.mode != PreviewMode::Rendered {
        return Err(PreviewError::UnsupportedMode);
    }
    if input.truncated || input.bytes.len() > PNG_LIMIT {
        return Err(PreviewError::LimitExceeded("image input"));
    }
    Ok(())
}
pub fn dimensions(w: u32, h: u32, bounds: (u32, u32)) -> Result<(u32, u32), String> {
    if w == 0 || h == 0 || w > 32768 || h > 32768 || u64::from(w) * u64::from(h) > 100_000_000 {
        return Err("Image dimensions exceed budget".into());
    }
    let size = fit_size(w, h, bounds.0.min(1600), bounds.1.min(1200));
    if size.0 == 0 || size.1 == 0 {
        return Err("Empty viewport".into());
    }
    Ok(size)
}
pub fn checker(pixels: &mut [u8], width: u32) {
    for (i, p) in pixels.as_chunks_mut::<4>().0.iter_mut().enumerate() {
        let x = i % width as usize;
        let y = i / width as usize;
        let bg = if (x / 12 + y / 12).is_multiple_of(2) {
            38
        } else {
            48
        };
        let a = u32::from(p[3]);
        for c in &mut p[..3] {
            *c = ((u32::from(*c) * a + bg * (255 - a)) / 255) as u8;
        }
        p[3] = 255;
    }
}

// ---------------------------------------------------------------------------
// Windows Imaging Component (WIC) codecs. Image-family system API exception:
// only explicit OS codec CLSIDs, no third-party codec enumeration. The rest of
// this module stays platform-neutral; the COM/GDI code below is `cfg(windows)`.
// ---------------------------------------------------------------------------
#[derive(Clone, Copy)]
pub enum Codec {
    Png,
    Jpeg,
    Bmp,
    Ico,
    Tiff,
    Dds,
    Cur,
    Heif,
}
#[cfg(not(windows))]
pub fn decode(_: &[u8], _: (u32, u32), _: Codec) -> Result<Image, String> {
    Err("Windows image codec required".into())
}
/// ISO-BMFF brands accepted by the system HEIF decoder (HEIC/HEIF/AVIF container).
#[cfg(windows)]
fn heif_brand(bytes: &[u8]) -> bool {
    bytes.len() >= 12
        && &bytes[4..8] == b"ftyp"
        && matches!(
            &bytes[8..12],
            b"heic"
                | b"heix"
                | b"hevc"
                | b"hevx"
                | b"mif1"
                | b"msf1"
                | b"heim"
                | b"heis"
                | b"hevm"
                | b"hevs"
                | b"avif"
                | b"avis"
        )
}
#[cfg(windows)]
pub fn decode(bytes: &[u8], bounds: (u32, u32), codec: Codec) -> Result<Image, String> {
    use windows::{
        Win32::{Graphics::Imaging::*, System::Com::*},
        core::Interface,
    };
    let valid = match codec {
        Codec::Png => bytes.starts_with(b"\x89PNG\r\n\x1a\n"),
        Codec::Jpeg => bytes.starts_with(b"\xff\xd8\xff"),
        Codec::Bmp => bytes.starts_with(b"BM"),
        Codec::Ico => bytes.starts_with(b"\0\0\x01\0"),
        Codec::Tiff => bytes.starts_with(b"II*\0") || bytes.starts_with(b"MM\0*"),
        Codec::Dds => bytes.starts_with(b"DDS "),
        Codec::Cur => bytes.starts_with(b"\0\0\x02\0"),
        Codec::Heif => heif_brand(bytes),
    };
    if !valid {
        return Err("Invalid image signature".into());
    }
    // SAFETY: COM objects stay on this thread and die before its matching
    // CoUninitialize. The immutable input outlives the WIC memory stream.
    unsafe {
        let init = CoInitializeEx(None, COINIT_MULTITHREADED);
        if init.is_err() {
            return Err(format!("COM initialization: {init:?}"));
        }
        let result = (|| -> Result<Image, String> {
            let native = (|| -> windows::core::Result<_> {
                let factory: IWICImagingFactory =
                    CoCreateInstance(&CLSID_WICImagingFactory, None, CLSCTX_INPROC_SERVER)?;
                let stream = factory.CreateStream()?;
                stream.InitializeFromMemory(bytes)?;
                // Explicit OS codec, never enumerate arbitrary installed plug-ins.
                let clsid = match codec {
                    Codec::Png => CLSID_WICPngDecoder,
                    Codec::Jpeg => CLSID_WICJpegDecoder,
                    Codec::Bmp => CLSID_WICBmpDecoder,
                    Codec::Ico | Codec::Cur => CLSID_WICIcoDecoder,
                    Codec::Tiff => CLSID_WICTiffDecoder,
                    Codec::Dds => CLSID_WICDdsDecoder,
                    Codec::Heif => CLSID_WICHeifDecoder,
                };
                let decoder: IWICBitmapDecoder =
                    CoCreateInstance(&clsid, None, CLSCTX_INPROC_SERVER)?;
                decoder.Initialize(&stream, WICDecodeMetadataCacheOnDemand)?;
                Ok((factory, stream, decoder))
            })()
            .map_err(|e| e.to_string())?;
            let (factory, _stream, decoder) = native;
            let count = decoder.GetFrameCount().map_err(|e| e.to_string())?;
            if count == 0 || count > 256 {
                return Err("Invalid image frame count".into());
            }
            let mut chosen = 0;
            let mut area = 0;
            if matches!(codec, Codec::Ico) {
                for i in 0..count {
                    let f = decoder.GetFrame(i).map_err(|e| e.to_string())?;
                    let (mut w, mut h) = (0, 0);
                    f.GetSize(&mut w, &mut h).map_err(|e| e.to_string())?;
                    if u64::from(w) * u64::from(h) > area {
                        area = u64::from(w) * u64::from(h);
                        chosen = i;
                    }
                }
            }
            let frame = decoder.GetFrame(chosen).map_err(|e| e.to_string())?;
            let (mut w, mut h) = (0, 0);
            frame.GetSize(&mut w, &mut h).map_err(|e| e.to_string())?;
            let (ow, oh) = super::common::dimensions(w, h, bounds)?;
            let source: IWICBitmapSource = frame.cast().map_err(|e| e.to_string())?;
            let scaler = factory.CreateBitmapScaler().map_err(|e| e.to_string())?;
            scaler
                .Initialize(&source, ow, oh, WICBitmapInterpolationModeFant)
                .map_err(|e| e.to_string())?;
            let converter = factory.CreateFormatConverter().map_err(|e| e.to_string())?;
            converter
                .Initialize(
                    &scaler,
                    &GUID_WICPixelFormat32bppBGRA,
                    WICBitmapDitherTypeNone,
                    None,
                    0.0,
                    WICBitmapPaletteTypeCustom,
                )
                .map_err(|e| e.to_string())?;
            // Only a bounded output bitmap is allocated by this code. The OS
            // codec may allocate internal scratch; input and dimensions are bounded.
            let mut bgra = vec![0; ow as usize * oh as usize * 4];
            converter
                .CopyPixels(std::ptr::null(), ow * 4, &mut bgra)
                .map_err(|e| e.to_string())?;
            super::common::checker(&mut bgra, ow);
            Ok(Image {
                width: ow,
                height: oh,
                original: (w, h),
                bgra,
                animation: None,
            })
        })();
        CoUninitialize();
        result
    }
}
