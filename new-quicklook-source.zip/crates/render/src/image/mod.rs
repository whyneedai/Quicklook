mod bmp;
mod common;
mod cur;
mod dds;
mod gif;
mod heic;
mod ico;
mod jpeg;
mod png;
mod tiff;
mod webp;
use quicklook_core::FormatPreview;
pub fn components() -> &'static [&'static dyn FormatPreview] {
    &[
        &png::Png,
        &jpeg::Component,
        &gif::Component,
        &webp::Component,
        &bmp::Component,
        &ico::Component,
        &tiff::Component,
        &dds::Component,
        &cur::Component,
        &heic::Component,
    ]
}
