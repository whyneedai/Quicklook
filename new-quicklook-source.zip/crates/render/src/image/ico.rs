use quicklook_core::*;
pub struct Component;
impl FormatPreview for Component {
    fn info(&self) -> FormatInfo {
        super::common::info("ico", "ICO", &["ico"], &[b"\0\0\x01\0"])
    }
    fn preview(&self, input: &Input<'_>) -> Result<Output, PreviewError> {
        super::common::check(input)?;
        super::common::decode(input.bytes, input.viewport, super::common::Codec::Ico)
            .map(Output::Image)
            .map_err(PreviewError::InvalidData)
    }
}
