//! Streaming GIF rows into a bounded compositing canvas, including disposal.
use quicklook_core::*;
pub struct Component;
impl FormatPreview for Component {
    fn info(&self) -> FormatInfo {
        super::common::info("gif", "GIF", &["gif"], &[b"GIF87a", b"GIF89a"])
    }
    fn preview(&self, input: &Input<'_>) -> Result<Output, PreviewError> {
        super::common::check(input)?;
        decode(input)
            .map(Output::Image)
            .map_err(PreviewError::InvalidData)
    }
}
fn decode(input: &Input<'_>) -> Result<Image, String> {
    let mut options = ::gif::DecodeOptions::new();
    options.set_color_output(::gif::ColorOutput::RGBA);
    options.check_frame_consistency(true);
    options.check_lzw_end_code(true);
    let mut decoder = options
        .read_info(std::io::Cursor::new(input.bytes))
        .map_err(|e| e.to_string())?;
    let background = decoder
        .bg_color()
        .and_then(|index| {
            decoder
                .global_palette()
                .and_then(|p| p.get(index * 3..index * 3 + 3))
        })
        .map(|p| [p[2], p[1], p[0], 255])
        .unwrap_or([0, 0, 0, 0]);
    let (w, h) = (u32::from(decoder.width()), u32::from(decoder.height()));
    let (ow, oh) =
        super::common::dimensions(w, h, (input.viewport.0.min(800), input.viewport.1.min(600)))?;
    let size = ow as usize * oh as usize * 4;
    let mut canvas = vec![0; size];
    let mut frames = Vec::new();
    let mut delays_ms = Vec::new();
    let mut work = 0u64;
    while let Some(frame) = decoder.next_frame_info().map_err(|e| e.to_string())? {
        let (fw, fh, left, top, interlaced, dispose, delay) = (
            u32::from(frame.width),
            u32::from(frame.height),
            u32::from(frame.left),
            u32::from(frame.top),
            frame.interlaced,
            frame.dispose,
            frame.delay,
        );
        let clear = if frame.transparent.is_some() {
            [0, 0, 0, 0]
        } else {
            background
        };
        if frames.is_empty() {
            for p in canvas.as_chunks_mut::<4>().0 {
                p.copy_from_slice(&clear);
            }
        }
        if fw == 0 || fh == 0 {
            return Err("Empty GIF frame".into());
        }
        work += u64::from(fw) * u64::from(fh);
        if frames.len() >= MAX_ANIMATION_FRAMES
            || (frames.len() + 1) * size > MAX_ANIMATION_BYTES
            || work > 100_000_000
        {
            return Err(
                "GIF exceeds animation budget (300 frames / 64 MiB / 100M decoded pixels)".into(),
            );
        }
        let previous = if dispose == ::gif::DisposalMethod::Previous {
            Some(canvas.clone())
        } else {
            None
        };
        let mut row = vec![0; fw as usize * 4];
        let rows: Vec<u32> = if interlaced {
            [(0, 8), (4, 8), (2, 4), (1, 2)]
                .into_iter()
                .flat_map(|(start, step)| (start..fh).step_by(step))
                .collect()
        } else {
            (0..fh).collect()
        };
        // Sample coordinates map logical screen -> output, so sub-frame offsets
        // and interlace order do not change the sampled pixel grid.
        for sy in rows {
            if !decoder.fill_buffer(&mut row).map_err(|e| e.to_string())? {
                return Err("Incomplete GIF scanline".into());
            }
            let global_y = top + sy;
            let start_y = (u64::from(global_y) * u64::from(oh)).div_ceil(u64::from(h)) as u32;
            let end_y = (u64::from(global_y + 1) * u64::from(oh)).div_ceil(u64::from(h)) as u32;
            for y in start_y..end_y.min(oh) {
                for x in 0..ow {
                    let sx = (u64::from(x) * u64::from(w) / u64::from(ow)) as u32;
                    if sx < left || sx >= left + fw {
                        continue;
                    }
                    let p = &row[(sx - left) as usize * 4..(sx - left) as usize * 4 + 4];
                    if p[3] != 0 {
                        let dest = (y as usize * ow as usize + x as usize) * 4;
                        canvas[dest..dest + 4].copy_from_slice(&[p[2], p[1], p[0], p[3]]);
                    }
                }
            }
        }
        let mut composed = canvas.clone();
        super::common::checker(&mut composed, ow);
        frames.push(composed);
        delays_ms.push((u32::from(delay) * 10).clamp(20, 600_000));
        match dispose {
            ::gif::DisposalMethod::Background => {
                for y in 0..oh {
                    let sy = u64::from(y) * u64::from(h) / u64::from(oh);
                    if sy < u64::from(top) || sy >= u64::from(top + fh) {
                        continue;
                    }
                    for x in 0..ow {
                        let sx = u64::from(x) * u64::from(w) / u64::from(ow);
                        if sx >= u64::from(left) && sx < u64::from(left + fw) {
                            let i = (y as usize * ow as usize + x as usize) * 4;
                            canvas[i..i + 4].copy_from_slice(&clear);
                        }
                    }
                }
            }
            ::gif::DisposalMethod::Previous => canvas = previous.unwrap(),
            _ => {}
        }
    }
    if frames.is_empty() {
        return Err("GIF has no frames".into());
    }
    let plays = match decoder.repeat() {
        ::gif::Repeat::Infinite => 0,
        ::gif::Repeat::Finite(n) => u32::from(n) + 1,
    };
    let bgra = frames.remove(0);
    Ok(Image {
        width: ow,
        height: oh,
        original: (w, h),
        bgra,
        animation: if frames.is_empty() {
            None
        } else {
            Some(Animation {
                frames,
                delays_ms,
                plays,
            })
        },
    })
}
#[cfg(test)]
mod tests {
    use super::*;
    use std::borrow::Cow;
    #[test]
    fn partial_frames_restore_previous_and_background() {
        let mut bytes = Vec::new();
        {
            let palette = [0, 0, 0, 255, 0, 0, 0, 255, 0, 0, 0, 255];
            let mut encoder = ::gif::Encoder::new(&mut bytes, 3, 1, &palette).unwrap();
            let mut emit = |left, width, pixels: Vec<u8>, dispose, transparent| {
                encoder
                    .write_frame(&::gif::Frame {
                        left,
                        width,
                        height: 1,
                        buffer: Cow::Owned(pixels),
                        dispose,
                        transparent,
                        delay: 10,
                        ..Default::default()
                    })
                    .unwrap();
            };
            emit(0, 3, vec![1, 1, 1], ::gif::DisposalMethod::Keep, None);
            emit(1, 1, vec![2], ::gif::DisposalMethod::Previous, None);
            emit(2, 1, vec![3], ::gif::DisposalMethod::Keep, None);
            emit(0, 1, vec![0], ::gif::DisposalMethod::Background, Some(0));
            emit(1, 1, vec![2], ::gif::DisposalMethod::Keep, None);
        }
        let image = decode(&Input {
            bytes: &bytes,
            viewport: (3, 1),
            mode: PreviewMode::Rendered,
            truncated: false,
        })
        .unwrap();
        let a = image.animation.unwrap();
        assert_eq!(a.plays, 1);
        assert_eq!(a.frames.len(), 4);
        assert_eq!(&a.frames[0][4..8], &[0, 255, 0, 255]);
        assert_eq!(&a.frames[1][4..8], &[0, 0, 255, 255]);
        assert_eq!(&a.frames[1][8..12], &[255, 0, 0, 255]);
        assert_eq!(&a.frames[3][..4], &[38, 38, 38, 255]);
    }
    #[test]
    fn interlaced_scanlines_are_reordered_without_full_frame_buffer() {
        let mut bytes = Vec::new();
        {
            let palette = [0, 0, 0, 255, 0, 0];
            let mut e = ::gif::Encoder::new(&mut bytes, 2, 8, &palette).unwrap();
            let rows = [0, 4, 2, 6, 1, 3, 5, 7];
            let pixels: Vec<u8> = rows
                .into_iter()
                .flat_map(|y| [u8::from(y % 2 == 1); 2])
                .collect();
            e.write_frame(&::gif::Frame {
                width: 2,
                height: 8,
                interlaced: true,
                buffer: Cow::Owned(pixels),
                ..Default::default()
            })
            .unwrap();
        }
        let image = decode(&Input {
            bytes: &bytes,
            viewport: (2, 8),
            mode: PreviewMode::Rendered,
            truncated: false,
        })
        .unwrap();
        for y in 0..8 {
            assert_eq!(image.bgra[y * 8 + 2], if y % 2 == 0 { 0 } else { 255 });
        }
    }
}
