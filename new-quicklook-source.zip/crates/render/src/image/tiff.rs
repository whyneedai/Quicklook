use quicklook_core::*;
pub struct Component;
impl FormatPreview for Component {
    fn info(&self) -> FormatInfo {
        super::common::info("tiff", "TIFF", &["tif", "tiff"], &[b"II*\0", b"MM\0*"])
    }
    fn preview(&self, input: &Input<'_>) -> Result<Output, PreviewError> {
        super::common::check(input)?;
        super::common::decode(input.bytes, input.viewport, super::common::Codec::Tiff)
            .map(Output::Image)
            .map_err(PreviewError::InvalidData)
    }
}
