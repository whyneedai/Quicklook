use quicklook_core::*;
pub struct Pdf;
impl FormatPreview for Pdf {
    fn info(&self) -> FormatInfo {
        FormatInfo {
            id: "pdf",
            display_name: "PDF",
            kind: Kind::Paged,
            extensions: &["pdf"],
            magic: &[b"%PDF-"],
            modes: &[PreviewMode::Rendered],
            limits: Limits {
                max_input_bytes: pages::INPUT_BYTES,
                allow_truncation: false,
            },
        }
    }
    fn preview(&self, input: &Input<'_>) -> Result<Output, PreviewError> {
        if !input.bytes.starts_with(b"%PDF-") {
            return Err(PreviewError::InvalidData("Invalid PDF header".into()));
        }
        Ok(Output::Pages(Pages {
            worker: pages::PDF_WORKER,
            source: Some(input.bytes.to_vec()),
            index: 0,
            count: 0,
            image: None,
        }))
    }
}
