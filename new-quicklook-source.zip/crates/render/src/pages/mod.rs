mod pdf;
use quicklook_core::FormatPreview;
pub fn components() -> &'static [&'static dyn FormatPreview] {
    &[&pdf::Pdf]
}
