//! .css source preview. Format-specific policy stays in this module.
use super::common::{self, CODE, Rules};
use quicklook_core::{FormatInfo, FormatPreview, Input, Output, PreviewError};
pub(super) const RULES: Rules = Rules {
    keywords: "important inherit initial unset revert auto none block flex grid solid",
    line_comments: &[],
    keys: true,
    semantic: false,
    types: "",
    ..CODE
};
pub struct Component;
impl FormatPreview for Component {
    fn info(&self) -> FormatInfo {
        common::info("css", "CSS", &["css"])
    }
    fn preview(&self, input: &Input<'_>) -> Result<Output, PreviewError> {
        common::preview(input, RULES)
    }
}
