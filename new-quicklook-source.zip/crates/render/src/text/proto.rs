//! .proto source preview. Format-specific policy stays in this module.
use super::common::{self, PLAIN, Rules};
use quicklook_core::{FormatInfo, FormatPreview, Input, Output, PreviewError};
pub(super) const RULES: Rules = Rules {
    keywords: "syntax import package option message enum service rpc returns repeated optional required oneof map reserved extensions extend group public weak true false",
    line_comments: &["//"],
    blocks: &[("/*", "*/")],
    quotes: b"\"'",
    numbers: true,
    ..PLAIN
};
pub struct Component;
impl FormatPreview for Component {
    fn info(&self) -> FormatInfo {
        common::info("proto", "Protocol Buffers", &["proto"])
    }
    fn preview(&self, input: &Input<'_>) -> Result<Output, PreviewError> {
        common::preview(input, RULES)
    }
}
