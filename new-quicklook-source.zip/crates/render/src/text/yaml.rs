//! .yaml source preview. Format-specific policy stays in this module.
use super::common::{self, HASH, Rules};
use quicklook_core::{FormatInfo, FormatPreview, Input, Output, PreviewError};
pub(super) const RULES: Rules = Rules {
    keywords: "true false null yes no on off",
    keys: true,
    semantic: false,
    insensitive: true,
    ..HASH
};
pub struct Component;
impl FormatPreview for Component {
    fn info(&self) -> FormatInfo {
        common::info("yaml", "YAML", &["yaml"])
    }
    fn preview(&self, input: &Input<'_>) -> Result<Output, PreviewError> {
        common::preview(input, RULES)
    }
}
