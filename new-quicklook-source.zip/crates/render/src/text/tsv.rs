//! .tsv source preview. Format-specific policy stays in this module.
use super::common::{self, PLAIN, Rules};
use quicklook_core::{FormatInfo, FormatPreview, Input, Output, PreviewError, PreviewMode};
pub(super) const RULES: Rules = Rules {
    keywords: "",
    quotes: b"\"",
    multiline_quotes: b"\"",
    delimiter: Some(b'\t'),
    ..PLAIN
};
pub struct Component;
impl FormatPreview for Component {
    fn info(&self) -> FormatInfo {
        let mut info = common::info("tsv", "TSV", &["tsv"]);
        info.modes = &[PreviewMode::Rendered, PreviewMode::Source];
        info
    }
    fn preview(&self, input: &Input<'_>) -> Result<Output, PreviewError> {
        super::table::preview(input, '\t', RULES)
    }
}
