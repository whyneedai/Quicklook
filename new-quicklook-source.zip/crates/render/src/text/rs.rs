use super::common::{self, CODE, Rules};
use quicklook_core::*;
pub(super) const RULES: Rules = Rules {
    keywords: "as async await break const continue crate dyn else enum extern false fn for if impl in let loop match mod move mut pub ref return self Self static struct super trait true type unsafe use where while",
    types: "bool char str f32 f64 i8 i16 i32 i64 i128 isize u8 u16 u32 u64 u128 usize Self String Vec Option Result Box",
    nested_comments: true,
    char_literals: true,
    ..CODE
};
pub struct Rust;
impl FormatPreview for Rust {
    fn info(&self) -> FormatInfo {
        common::info("rust", "Rust", &["rs"])
    }
    fn preview(&self, input: &Input<'_>) -> Result<Output, PreviewError> {
        common::preview(input, RULES)
    }
}
#[cfg(test)]
pub fn parse(bytes: &[u8], truncated: bool) -> Document {
    let Output::Text(doc) = common::preview(
        &Input {
            bytes,
            truncated,
            mode: PreviewMode::Source,
            viewport: (1, 1),
        },
        RULES,
    )
    .unwrap() else {
        unreachable!()
    };
    doc
}
#[cfg(test)]
pub fn rust_line(s: &str, depth: &mut usize) -> Vec<Span> {
    let mut state = common::State::default();
    // Restore block-comment state for this test helper only.
    state.restore_comment(*depth);
    let result = common::highlight(s, RULES, &mut state);
    *depth = state.depth;
    result
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn rust_keywords_comments_strings() {
        let mut in_block = 0;
        let spans = rust_line("pub fn main() { let s = \"hi\"; // note", &mut in_block);
        assert_eq!(spans[0].style, Style::Keyword); // pub
        assert!(spans.iter().any(|s| s.style == Style::String));
        assert_eq!(spans.last().unwrap().style, Style::Comment);
    }
    #[test]
    fn block_comments_span_lines() {
        let mut in_block = 0;
        let open = rust_line("/* start", &mut in_block);
        assert_eq!(in_block, 1);
        assert_eq!(open.last().unwrap().style, Style::Comment);
        let close = rust_line("still comment */ let x = 1;", &mut in_block);
        assert_eq!(in_block, 0);
        assert_eq!(close[0].style, Style::Comment);
    }
    #[test]
    fn lifetimes_and_nested_comments() {
        let mut depth = 0;
        let spans = rust_line("fn f<'a>(s: &'a str) { let c = 'x'; }", &mut depth);
        assert!(
            spans
                .iter()
                .any(|s| s.style == Style::Keyword && s.text == "let")
        );
        assert_eq!(spans.iter().filter(|s| s.style == Style::String).count(), 1);
        rust_line("/* outer /* nested */", &mut depth);
        assert_eq!(depth, 1);
        let spans = rust_line("still outer */ fn", &mut depth);
        assert_eq!(depth, 0);
        assert_eq!(spans.last().unwrap().style, Style::Keyword);
    }
    #[test]
    fn rust_parse_lines_and_caps() {
        let d = parse(b"// c\npub fn f() {}\n", false);
        assert_eq!(d.lines.len(), 2);
        assert_eq!(d.lines[1].source, 2);
        assert!(d.line_numbers);
        assert!(!d.truncated);
    }
}
