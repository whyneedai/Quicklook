use super::common;
use pulldown_cmark::{Event, Parser, Tag, TagEnd};
use quicklook_core::*;
#[derive(Default)]
struct Builder {
    line: Line,
    characters: usize,
}
fn span(text: impl Into<String>, style: Style) -> Span {
    Span {
        math: None,
        text: text.into(),
        style,
    }
}
fn append(line: &mut Builder, doc: &mut Document, value: &str, style: Style) {
    let kept: String = value
        .chars()
        .take(MAX_LINE_CHARS.saturating_sub(line.characters))
        .collect();
    doc.truncated |= kept.len() < value.len();
    line.characters += kept.chars().count();
    if kept.is_empty() {
        return;
    }
    if let Some(last) = line
        .line
        .spans
        .last_mut()
        .filter(|s| s.style == style && s.math.is_none())
    {
        last.text.push_str(&kept);
    } else {
        line.line.spans.push(span(kept, style));
    }
}
fn markdown(text: &str) -> Document {
    let mut doc = Document::default();
    let mut formula_count = 0;
    let mut current = Builder::default();
    let mut bold = 0usize;
    let mut emphasis = 0usize;
    let mut link = 0usize;
    let mut quote = 0usize;
    let mut code = false;
    let mut code_rules = common::fence_rules("");
    let mut code_state = common::State::default();
    let mut heading = 0u8;
    let mut lists: Vec<Option<u64>> = Vec::new();
    let mut line_offsets = vec![0];
    for (i, b) in text.bytes().enumerate() {
        if b == b'\n' {
            line_offsets.push(i + 1);
        }
    }
    let flush = |current: &mut Builder, doc: &mut Document| {
        if !current.line.spans.is_empty() || (current.line.code && current.line.source > 0) {
            doc.lines.push(std::mem::take(current).line);
        } else {
            *current = Builder::default();
        }
    };
    for (event_index, (event, range)) in Parser::new_ext(text, pulldown_cmark::Options::ENABLE_MATH)
        .into_offset_iter()
        .enumerate()
    {
        if event_index >= 100_000 {
            doc.truncated = true;
            break;
        }
        if doc.lines.len() >= MAX_LINES {
            doc.truncated = true;
            break;
        }
        let source = line_offsets.partition_point(|&x| x <= range.start);
        match event {
            Event::Start(tag) => match tag {
                Tag::Paragraph => {}
                Tag::Heading { level, .. } => {
                    flush(&mut current, &mut doc);
                    heading = level as u8;
                }
                Tag::CodeBlock(kind) => {
                    let lang = match &kind {
                        pulldown_cmark::CodeBlockKind::Fenced(s) => {
                            s.split_whitespace().next().unwrap_or("")
                        }
                        _ => "",
                    };
                    code_rules = common::fence_rules(lang);
                    code_state = common::State::default();
                    flush(&mut current, &mut doc);
                    code = true;
                }
                Tag::BlockQuote(_) => {
                    flush(&mut current, &mut doc);
                    quote += 1;
                }
                Tag::List(n) => {
                    flush(&mut current, &mut doc);
                    lists.push(n);
                }
                Tag::Item => {
                    flush(&mut current, &mut doc);
                    current.line.source = source;
                    let prefix = if let Some(Some(n)) = lists.last_mut() {
                        let s = format!("{n}. ");
                        *n = n.saturating_add(1);
                        s
                    } else {
                        "• ".into()
                    };
                    let prefix = format!(
                        "{}{prefix}",
                        "  ".repeat(lists.len().saturating_sub(1).min(16))
                    );
                    append(&mut current, &mut doc, &prefix, Style::Normal);
                }
                Tag::Strong => bold += 1,
                Tag::Emphasis => emphasis += 1,
                Tag::Link { .. } => link += 1,
                Tag::Image { .. } => append(&mut current, &mut doc, "[image: ", Style::Comment),
                _ => {}
            },
            Event::End(tag) => match tag {
                TagEnd::Paragraph | TagEnd::Item => flush(&mut current, &mut doc),
                TagEnd::Heading(_) => {
                    flush(&mut current, &mut doc);
                    heading = 0;
                }
                TagEnd::CodeBlock => {
                    flush(&mut current, &mut doc);
                    code = false;
                }
                TagEnd::BlockQuote(_) => {
                    flush(&mut current, &mut doc);
                    quote = quote.saturating_sub(1);
                }
                TagEnd::List(_) => {
                    flush(&mut current, &mut doc);
                    lists.pop();
                }
                TagEnd::Strong => bold = bold.saturating_sub(1),
                TagEnd::Emphasis => emphasis = emphasis.saturating_sub(1),
                TagEnd::Link => link = link.saturating_sub(1),
                TagEnd::Image => append(&mut current, &mut doc, " — not loaded]", Style::Comment),
                _ => {}
            },
            Event::InlineMath(ref tex) | Event::DisplayMath(ref tex) => {
                let display = matches!(event, Event::DisplayMath(_));
                if display {
                    flush(&mut current, &mut doc);
                }
                let state = if formula_count < 64 && math::structurally_valid(tex) {
                    math::State::Pending
                } else {
                    math::State::Fallback
                };
                formula_count += 1;
                let kept: String = tex
                    .chars()
                    .take(MAX_LINE_CHARS.saturating_sub(current.characters))
                    .collect();
                current.characters += kept.chars().count();
                doc.truncated |= kept.len() < tex.len();
                current.line.source = source;
                current.line.spans.push(Span {
                    text: kept,
                    style: Style::Code,
                    math: Some(math::Formula { display, state }),
                });
                if display {
                    flush(&mut current, &mut doc);
                }
            }
            Event::Code(s) => {
                if current.line.source == 0 {
                    current.line.source = source;
                }
                current.line.heading = heading;
                current.line.quote = quote > 0;
                append(&mut current, &mut doc, &s, Style::Code);
            }
            Event::Text(s) => {
                let style = if code {
                    Style::Code
                } else if bold > 0 {
                    Style::Bold
                } else if emphasis > 0 {
                    Style::Emphasis
                } else if link > 0 {
                    Style::Link
                } else {
                    Style::Normal
                };
                for (i, part) in s.split_terminator('\n').enumerate() {
                    if i > 0 {
                        flush(&mut current, &mut doc);
                    }
                    if current.line.source == 0 {
                        current.line.source = source + i;
                    }
                    current.line.heading = heading;
                    current.line.code = code;
                    current.line.quote = quote > 0;
                    if code {
                        let kept: String = part.chars().take(MAX_LINE_CHARS).collect();
                        doc.truncated |= kept.len() < part.len();
                        for token in common::highlight(&kept, code_rules, &mut code_state) {
                            append(&mut current, &mut doc, &token.text, token.style);
                        }
                    } else {
                        append(&mut current, &mut doc, part, style);
                    }
                    if doc.lines.len() >= MAX_LINES {
                        doc.truncated = true;
                        break;
                    }
                }
            }
            Event::SoftBreak => append(&mut current, &mut doc, " ", Style::Normal),
            Event::HardBreak => flush(&mut current, &mut doc),
            Event::Rule => {
                flush(&mut current, &mut doc);
                doc.lines.push(Line {
                    source,
                    spans: vec![span("────────────────────────────────", Style::Comment)],
                    ..Line::default()
                });
            }
            // Raw HTML is omitted, including script blocks; no browser, execution or URL fetch exists.
            Event::Html(_) | Event::InlineHtml(_) => {}
            _ => {}
        }
    }
    flush(&mut current, &mut doc);
    doc.lines.truncate(MAX_LINES);
    doc
}

pub fn parse(bytes: &[u8], truncated: bool, mode: PreviewMode) -> Document {
    let limited = &bytes[..bytes.len().min(TEXT_LIMIT)];
    let text = String::from_utf8_lossy(limited);
    let text = text.trim_start_matches('\u{feff}');
    let mut doc = if mode == PreviewMode::Source {
        let lines = text
            .lines()
            .take(MAX_LINES)
            .enumerate()
            .map(|(i, line)| {
                let style = if line.starts_with('#') {
                    Style::Keyword
                } else if line.starts_with('>') {
                    Style::Comment
                } else if line.starts_with("```") {
                    Style::String
                } else {
                    Style::Normal
                };
                Line {
                    source: i + 1,
                    code: true,
                    spans: vec![span(
                        line.chars().take(MAX_LINE_CHARS).collect::<String>(),
                        style,
                    )],
                    ..Line::default()
                }
            })
            .collect();
        Document {
            lines,
            line_numbers: true,
            truncated: text.lines().count() > MAX_LINES
                || text
                    .lines()
                    .any(|line| line.chars().count() > MAX_LINE_CHARS),
        }
    } else {
        markdown(text)
    };
    doc.truncated |= truncated || bytes.len() > TEXT_LIMIT;
    if doc.lines.is_empty() {
        doc.lines.push(Line {
            source: 1,
            ..Line::default()
        });
    }
    doc
}
pub struct Markdown;
impl FormatPreview for Markdown {
    fn info(&self) -> FormatInfo {
        FormatInfo {
            id: "markdown",
            display_name: "Markdown",
            kind: Kind::Text,
            extensions: &["md", "markdown"],
            magic: &[],
            modes: &[PreviewMode::Rendered, PreviewMode::Source],
            limits: Limits {
                max_input_bytes: TEXT_LIMIT,
                allow_truncation: true,
            },
        }
    }
    fn preview(&self, input: &Input<'_>) -> Result<Output, PreviewError> {
        if !self.info().modes.contains(&input.mode) {
            return Err(PreviewError::UnsupportedMode);
        }
        Ok(Output::Text(parse(
            input.bytes,
            input.truncated,
            input.mode,
        )))
    }
}
