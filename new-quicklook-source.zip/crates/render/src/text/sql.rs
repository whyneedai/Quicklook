//! .sql source preview. Format-specific policy stays in this module.
use super::common::{self, CODE, Rules};
use quicklook_core::{FormatInfo, FormatPreview, Input, Output, PreviewError};
pub(super) const RULES: Rules = Rules {
    keywords: "select from where insert into update delete create alter drop table index view join inner outer left right full on as and or not null true false values set group by order having limit offset union all distinct case when then else end begin commit rollback primary key foreign references default exists in is like between asc desc",
    line_comments: &["--"],
    insensitive: true,
    semantic: false,
    types: "",
    ..CODE
};
pub struct Component;
impl FormatPreview for Component {
    fn info(&self) -> FormatInfo {
        common::info("sql", "SQL", &["sql"])
    }
    fn preview(&self, input: &Input<'_>) -> Result<Output, PreviewError> {
        common::preview(input, RULES)
    }
}
