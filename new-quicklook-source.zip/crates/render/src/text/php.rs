//! .php source preview. Format-specific policy stays in this module.
use super::common::{self, CODE, Rules};
use quicklook_core::{FormatInfo, FormatPreview, Input, Output, PreviewError};
pub(super) const RULES: Rules = Rules {
    keywords: "abstract and array as break callable case catch class clone const continue declare default do echo else elseif empty endfor endforeach endif endwhile enum extends false final finally fn for foreach function global if implements include include_once instanceof interface isset list match namespace new null or print private protected public readonly require require_once return static switch throw trait true try unset use var while xor yield",
    line_comments: &["//", "#"],
    ..CODE
};
pub struct Component;
impl FormatPreview for Component {
    fn info(&self) -> FormatInfo {
        common::info("php", "PHP", &["php"])
    }
    fn preview(&self, input: &Input<'_>) -> Result<Output, PreviewError> {
        common::preview(input, RULES)
    }
}
