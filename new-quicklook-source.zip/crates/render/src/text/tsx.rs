//! .tsx source preview. Format-specific policy stays in this module.
use super::common::{self, CODE, Rules};
use quicklook_core::{FormatInfo, FormatPreview, Input, Output, PreviewError};
pub(super) const RULES: Rules = Rules {
    keywords: "as async await class const default else export extends false for from function if implements import interface let new null private public readonly return string this true type",
    quotes: b"\"'`",
    multiline_quotes: b"`",
    types: "any boolean bigint never number object string symbol unknown void",
    ..CODE
};
pub struct Component;
impl FormatPreview for Component {
    fn info(&self) -> FormatInfo {
        common::info("tsx", "TSX", &["tsx"])
    }
    fn preview(&self, input: &Input<'_>) -> Result<Output, PreviewError> {
        common::preview(input, RULES)
    }
}
