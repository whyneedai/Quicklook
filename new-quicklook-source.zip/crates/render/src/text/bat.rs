//! .bat source preview. Format-specific policy stays in this module.
use super::common::{self, PLAIN, Rules};
use quicklook_core::{FormatInfo, FormatPreview, Input, Output, PreviewError};
pub(super) const RULES: Rules = Rules {
    keywords: "assoc attrib break call cd chdir choice cls copy date del dir echo endlocal erase errorlevel exist exit for ftype goto if in ipconfig label md mkdir more move net not off on path pause ping popd prompt pushd rd reg rem ren rename rmdir robocopy sc set setlocal shift sort start taskkill tasklist timeout title type verify vol wmic xcopy",
    line_comments: &["::"],
    quotes: b"\"",
    insensitive: true,
    numbers: true,
    ..PLAIN
};
pub struct Component;
impl FormatPreview for Component {
    fn info(&self) -> FormatInfo {
        common::info("bat", "Batch", &["bat"])
    }
    fn preview(&self, input: &Input<'_>) -> Result<Output, PreviewError> {
        common::preview(input, RULES)
    }
}
