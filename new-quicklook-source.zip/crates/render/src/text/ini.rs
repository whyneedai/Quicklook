//! .ini source preview. Format-specific policy stays in this module.
use super::common::{self, HASH, Rules};
use quicklook_core::{FormatInfo, FormatPreview, Input, Output, PreviewError};
pub(super) const RULES: Rules = Rules {
    keywords: "true false",
    line_comments: &[";", "#"],
    keys: true,
    semantic: false,
    ..HASH
};
pub struct Component;
impl FormatPreview for Component {
    fn info(&self) -> FormatInfo {
        common::info("ini", "INI", &["ini"])
    }
    fn preview(&self, input: &Input<'_>) -> Result<Output, PreviewError> {
        common::preview(input, RULES)
    }
}
