//! .tf source preview. Format-specific policy stays in this module.
use super::common::{self, PLAIN, Rules};
use quicklook_core::{FormatInfo, FormatPreview, Input, Output, PreviewError};
pub(super) const RULES: Rules = Rules {
    keywords: "resource data variable output module provider terraform locals backend true false null for in if",
    line_comments: &["#", "//"],
    blocks: &[("/*", "*/")],
    quotes: b"\"",
    numbers: true,
    ..PLAIN
};
pub struct Component;
impl FormatPreview for Component {
    fn info(&self) -> FormatInfo {
        common::info("tf", "Terraform", &["tf"])
    }
    fn preview(&self, input: &Input<'_>) -> Result<Output, PreviewError> {
        common::preview(input, RULES)
    }
}
