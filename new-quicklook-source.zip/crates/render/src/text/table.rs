//! Bounded delimiter parsing shared by the independent CSV and TSV components.
use quicklook_core::*;
const ROWS: usize = 1000;
const COLS: usize = 32;
const CHARS: usize = 256;
pub fn preview(
    input: &Input<'_>,
    delimiter: char,
    rules: super::common::Rules,
) -> Result<Output, PreviewError> {
    if input.mode == PreviewMode::Source {
        return super::common::preview(input, rules);
    }
    if input.mode != PreviewMode::Rendered {
        return Err(PreviewError::UnsupportedMode);
    }
    if input.bytes.len() > TEXT_LIMIT {
        return Err(PreviewError::LimitExceeded("text input"));
    }
    let text = String::from_utf8_lossy(input.bytes);
    let text = text.trim_start_matches('\u{feff}');
    let Ok((rows, truncated)) = parse(text, delimiter) else {
        let source = Input {
            mode: PreviewMode::Source,
            ..*input
        };
        let Output::Text(mut doc) = super::common::preview(&source, rules)? else {
            unreachable!()
        };
        doc.lines.insert(
            0,
            Line {
                spans: vec![Span {
                    text: "Table unavailable: malformed quotes. Showing source; M switches mode."
                        .into(),
                    style: Style::Comment,
                    math: None,
                }],
                ..Line::default()
            },
        );
        return Ok(Output::Text(doc));
    };
    let lines = rows
        .into_iter()
        .enumerate()
        .map(|(i, row)| {
            let last = row.len().saturating_sub(1);
            Line {
                source: i + 1,
                code: true,
                table: true,
                spans: row
                    .into_iter()
                    .enumerate()
                    .map(|(j, mut text)| {
                        if j < last {
                            text.push('\t');
                        }
                        Span {
                            text,
                            style: Style::Normal,
                            math: None,
                        }
                    })
                    .collect(),
                ..Line::default()
            }
        })
        .collect();
    Ok(Output::Text(Document {
        lines,
        truncated: truncated || input.truncated,
        line_numbers: false,
    }))
}
fn parse(text: &str, delimiter: char) -> Result<(Vec<Vec<String>>, bool), ()> {
    let mut rows = Vec::new();
    let mut row = Vec::new();
    let mut field = String::new();
    let (mut quoted, mut closed, mut pending, mut truncated) = (false, false, false, false);
    let (mut chars, mut column) = (0, 0);
    let mut input = text.chars().peekable();
    while let Some(c) = input.next() {
        pending = true;
        if c == '"' {
            if quoted {
                if input.peek() == Some(&'"') {
                    input.next();
                } else {
                    quoted = false;
                    closed = true;
                    continue;
                }
            } else if field.is_empty() && chars == 0 && !closed {
                quoted = true;
                continue;
            } else {
                return Err(());
            }
        } else if !quoted && (c == delimiter || c == '\n' || c == '\r') {
            if column < COLS {
                row.push(std::mem::take(&mut field));
            } else {
                field.clear();
                truncated = true;
            }
            chars = 0;
            column += 1;
            closed = false;
            if c != delimiter {
                if c == '\r' && input.peek() == Some(&'\n') {
                    input.next();
                }
                rows.push(std::mem::take(&mut row));
                column = 0;
                pending = false;
                if rows.len() == ROWS {
                    truncated |= input.peek().is_some();
                    break;
                }
            }
            continue;
        } else if closed {
            return Err(());
        }
        let newline = c == '\n' || c == '\r';
        if c == '\r' && input.peek() == Some(&'\n') {
            input.next();
        }
        let needed = if newline { 2 } else { 1 };
        if column < COLS && chars + needed <= CHARS {
            if newline {
                field.push_str("\\n");
            } else {
                field.push(c);
            }
        } else {
            truncated = true;
        }
        chars += needed;
    }
    if quoted {
        return Err(());
    }
    if pending || !row.is_empty() {
        if column < COLS {
            row.push(field);
        } else {
            truncated = true;
        }
        rows.push(row);
    }
    Ok((rows, truncated))
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn quotes_crlf_empty_fields_and_multiline() {
        let (r, t) = parse(
            "name,note,\r\n中文,\"line1\r\nline2, \"\"yes\"\"\",\r\n",
            ',',
        )
        .unwrap();
        assert!(!t);
        assert_eq!(r[0], vec!["name", "note", ""]);
        assert_eq!(r[1], vec!["中文", "line1\\nline2, \"yes\"", ""]);
        assert!(parse("\"unfinished", ',').is_err());
        assert!(parse("\"closed\"junk", ',').is_err());
    }
    #[test]
    fn budgets_are_visible() {
        let (r, t) = parse(&"x,".repeat(100), ',').unwrap();
        assert!(t);
        assert_eq!(r[0].len(), COLS);
        let (r, t) = parse(&"x\n".repeat(2000), ',').unwrap();
        assert!(t);
        assert_eq!(r.len(), ROWS);
        let (r, t) = parse(&"中".repeat(1000), ',').unwrap();
        assert!(t);
        assert_eq!(r[0][0].chars().count(), CHARS);
    }
    proptest::proptest! {#[test] fn arbitrary_delimited_text_is_bounded(s in ".{0,8192}") {
     if let Ok((rows,_))=parse(&s,',') {proptest::prop_assert!(rows.len()<=ROWS);for row in rows {proptest::prop_assert!(row.len()<=COLS);for cell in row {proptest::prop_assert!(cell.chars().count()<=CHARS);}}}
    }}
}
