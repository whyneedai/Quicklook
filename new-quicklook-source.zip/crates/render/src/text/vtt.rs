//! .vtt source preview. Format-specific policy stays in this module.
use super::common::{self, PLAIN, Rules};
use quicklook_core::{FormatInfo, FormatPreview, Input, Output, PreviewError};
pub(super) const RULES: Rules = Rules {
    keywords: "WEBVTT NOTE STYLE REGION",
    numbers: true,
    ..PLAIN
};
pub struct Component;
impl FormatPreview for Component {
    fn info(&self) -> FormatInfo {
        common::info("vtt", "WebVTT Subtitles", &["vtt"])
    }
    fn preview(&self, input: &Input<'_>) -> Result<Output, PreviewError> {
        common::preview(input, RULES)
    }
}
