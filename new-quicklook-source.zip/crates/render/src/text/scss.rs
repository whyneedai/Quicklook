//! .scss source preview. Format-specific policy stays in this module.
use super::common::{self, CODE, Rules};
use quicklook_core::{FormatInfo, FormatPreview, Input, Output, PreviewError};
pub(super) const RULES: Rules = Rules {
    keywords: "important inherit initial unset revert auto none block flex grid solid mixin include extend function return if else each for while import use media supports",
    line_comments: &["//"],
    keys: true,
    semantic: false,
    types: "",
    ..CODE
};
pub struct Component;
impl FormatPreview for Component {
    fn info(&self) -> FormatInfo {
        common::info("scss", "SCSS", &["scss"])
    }
    fn preview(&self, input: &Input<'_>) -> Result<Output, PreviewError> {
        common::preview(input, RULES)
    }
}
