mod bash;
mod bat;
mod bib;
mod c;
mod cfg;
mod cjs;
mod cmd;
mod common;
mod conf;
mod cpp;
mod cs;
mod css;
mod csv;
mod diff;
mod go;
mod h;
mod hpp;
mod htm;
mod html;
mod ini;
mod java;
mod js;
mod json;
mod jsx;
mod kt;
mod less;
mod log;
mod lua;
mod md;
mod mjs;
mod php;
mod properties;
mod proto;
mod ps1;
mod psd1;
mod psm1;
mod py;
mod r;
mod rb;
mod rs;
mod scss;
mod sh;
mod sql;
mod srt;
mod sty;
mod svg;
mod swift;
mod table;
mod tex;
mod tf;
mod toml;
mod ts;
mod tsv;
mod tsx;
mod txt;
mod vtt;
mod xml;
mod yaml;
mod yml;
mod zsh;
use quicklook_core::FormatPreview;
pub fn components() -> &'static [&'static dyn FormatPreview] {
    &[
        &md::Markdown,
        &py::Python,
        &rs::Rust,
        &txt::Component,
        &log::Component,
        &ini::Component,
        &cfg::Component,
        &conf::Component,
        &properties::Component,
        &json::Component,
        &xml::Component,
        &csv::Component,
        &tsv::Component,
        &toml::Component,
        &yaml::Component,
        &yml::Component,
        &js::Component,
        &ts::Component,
        &jsx::Component,
        &tsx::Component,
        &go::Component,
        &java::Component,
        &c::Component,
        &h::Component,
        &cpp::Component,
        &hpp::Component,
        &sh::Component,
        &bash::Component,
        &css::Component,
        &html::Component,
        &php::Component,
        &lua::Component,
        &sql::Component,
        &kt::Component,
        &swift::Component,
        &r::Component,
        &bat::Component,
        &cmd::Component,
        &ps1::Component,
        &psd1::Component,
        &psm1::Component,
        &cjs::Component,
        &cs::Component,
        &diff::Component,
        &htm::Component,
        &less::Component,
        &mjs::Component,
        &proto::Component,
        &rb::Component,
        &scss::Component,
        &srt::Component,
        &svg::Component,
        &tf::Component,
        &vtt::Component,
        &zsh::Component,
        &bib::Component,
        &sty::Component,
        &tex::Component,
    ]
}

const LANGUAGES: &[(&str, common::Rules)] = &[
    ("txt", txt::RULES),
    ("log", log::RULES),
    ("ini", ini::RULES),
    ("cfg", cfg::RULES),
    ("conf", conf::RULES),
    ("properties", properties::RULES),
    ("json", json::RULES),
    ("xml", xml::RULES),
    ("csv", csv::RULES),
    ("tsv", tsv::RULES),
    ("toml", toml::RULES),
    ("yaml", yaml::RULES),
    ("yml", yml::RULES),
    ("js", js::RULES),
    ("ts", ts::RULES),
    ("jsx", jsx::RULES),
    ("tsx", tsx::RULES),
    ("go", go::RULES),
    ("java", java::RULES),
    ("c", c::RULES),
    ("h", h::RULES),
    ("cpp", cpp::RULES),
    ("hpp", hpp::RULES),
    ("sh", sh::RULES),
    ("bash", bash::RULES),
    ("css", css::RULES),
    ("html", html::RULES),
    ("php", php::RULES),
    ("lua", lua::RULES),
    ("sql", sql::RULES),
    ("kt", kt::RULES),
    ("swift", swift::RULES),
    ("r", r::RULES),
    ("py", py::RULES),
    ("rs", rs::RULES),
    ("python", py::RULES),
    ("rust", rs::RULES),
    ("javascript", js::RULES),
    ("typescript", ts::RULES),
    ("shell", sh::RULES),
    ("ps1", ps1::RULES),
    ("powershell", ps1::RULES),
    ("psm1", psm1::RULES),
    ("psd1", psd1::RULES),
    ("cmd", cmd::RULES),
    ("bat", bat::RULES),
    ("batch", bat::RULES),
    ("ruby", rb::RULES),
    ("csharp", cs::RULES),
    ("cs", cs::RULES),
    ("mjs", mjs::RULES),
    ("cjs", cjs::RULES),
    ("scss", scss::RULES),
    ("less", less::RULES),
    ("zsh", zsh::RULES),
    ("htm", htm::RULES),
    ("svg", svg::RULES),
    ("protobuf", proto::RULES),
    ("proto", proto::RULES),
    ("terraform", tf::RULES),
    ("hcl", tf::RULES),
    ("diff", diff::RULES),
    ("srt", srt::RULES),
    ("vtt", vtt::RULES),
    ("latex", tex::RULES),
    ("tex", tex::RULES),
    ("sty", sty::RULES),
    ("bibtex", bib::RULES),
    ("bib", bib::RULES),
];

#[cfg(test)]
mod tests {
    use super::py::python_line;
    use quicklook_core::*;
    fn parse(bytes: &[u8], mode: Option<PreviewMode>, truncated: bool) -> Document {
        if let Some(mode) = mode {
            super::md::parse(bytes, truncated, mode)
        } else {
            super::py::parse(bytes, truncated)
        }
    }
    use proptest::prelude::*;
    #[test]
    fn rendered_markdown() {
        let d = parse(
            b"# Hello\n\n**bold** and [label](https://x.test)\n",
            Some(PreviewMode::Rendered),
            false,
        );
        assert_eq!(d.lines[0].heading, 1);
        assert_eq!(d.lines[0].spans[0].text, "Hello");
        assert!(d.lines[1].spans.iter().any(|s| s.style == Style::Bold));
        assert!(!format!("{d:?}").contains("https://"));
    }
    #[test]
    fn scripts_omitted() {
        let d = parse(
            b"<script>alert(1)</script>\n\nSafe",
            Some(PreviewMode::Rendered),
            false,
        );
        assert!(!format!("{d:?}").contains("alert"));
    }
    #[test]
    fn markdown_source_mapping_and_inline_limits() {
        let d = parse(
            b"# Head\n\n```python\nx = 1\n```\n\nAfter",
            Some(PreviewMode::Rendered),
            false,
        );
        assert_eq!(d.lines.last().unwrap().source, 7);
        let input = format!("`{}`", "x".repeat(10_000));
        let d = parse(input.as_bytes(), Some(PreviewMode::Rendered), false);
        assert!(d.truncated);
        assert!(
            d.lines[0]
                .spans
                .iter()
                .map(|s| s.text.chars().count())
                .sum::<usize>()
                <= MAX_LINE_CHARS
        );
    }
    #[test]
    fn markdown_lists_are_rendered() {
        let d = parse(
            b"- first\n- **second**\n",
            Some(PreviewMode::Rendered),
            false,
        );
        assert_eq!(d.lines.len(), 2);
        assert!(d.lines[0].spans[0].text.starts_with("• "));
        assert!(d.lines[1].spans.iter().any(|s| s.style == Style::Bold));
    }
    #[test]
    fn python_styles() {
        let x = python_line("def test(): # note");
        assert_eq!(x[0].style, Style::Keyword);
        assert_eq!(x.last().unwrap().style, Style::Comment);
    }
    proptest! {
        #![proptest_config(ProptestConfig::with_cases(128))]
        #[test] fn malformed_never_panics(b in proptest::collection::vec(any::<u8>(),0..8192)) {
            let rust=super::rs::parse(&b,false); prop_assert!(!rust.lines.is_empty()); prop_assert!(rust.lines.len()<=MAX_LINES);
            for k in [Some(PreviewMode::Rendered),None] { let d=parse(&b,k,false); prop_assert!(!d.lines.is_empty()); prop_assert!(d.lines.len()<=MAX_LINES); }
        }
    }
}
