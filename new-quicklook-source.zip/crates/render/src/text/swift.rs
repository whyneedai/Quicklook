//! .swift source preview. Format-specific policy stays in this module.
use super::common::{self, CODE, Rules};
use quicklook_core::{FormatInfo, FormatPreview, Input, Output, PreviewError};
pub(super) const RULES: Rules = Rules {
    keywords: "associatedtype class deinit enum extension fileprivate func import init inout internal let open operator private protocol public rethrows static struct subscript typealias var break case continue default defer do else fallthrough for guard if in repeat return switch where while as Any catch false is nil rethrows self Self super throw throws true try async await",
    ..CODE
};
pub struct Component;
impl FormatPreview for Component {
    fn info(&self) -> FormatInfo {
        common::info("swift", "Swift", &["swift"])
    }
    fn preview(&self, input: &Input<'_>) -> Result<Output, PreviewError> {
        common::preview(input, RULES)
    }
}
