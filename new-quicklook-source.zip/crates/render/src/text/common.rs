//! Shared bounded source model and small lexical primitives, never an evaluator.
use quicklook_core::*;
#[derive(Clone, Copy)]
pub(crate) struct Rules {
    pub keywords: &'static str,
    pub line_comments: &'static [&'static str],
    pub blocks: &'static [(&'static str, &'static str)],
    pub quotes: &'static [u8],
    pub multiline_quotes: &'static [u8],
    pub insensitive: bool,
    pub markup: bool,
    pub keys: bool,
    pub delimiter: Option<u8>,
    pub numbers: bool,
    pub nested_comments: bool,
    pub char_literals: bool,
    pub raw_delimiters: &'static [&'static str],
    pub semantic: bool,
    pub types: &'static str,
    pub diff: bool,
}
pub(crate) const PLAIN: Rules = Rules {
    keywords: "",
    line_comments: &[],
    blocks: &[],
    quotes: &[],
    multiline_quotes: &[],
    insensitive: false,
    markup: false,
    keys: false,
    delimiter: None,
    numbers: false,
    nested_comments: false,
    char_literals: false,
    raw_delimiters: &[],
    semantic: false,
    types: "",
    diff: false,
};
pub(crate) const CODE: Rules = Rules {
    line_comments: &["//"],
    blocks: &[("/*", "*/")],
    quotes: b"\"'",
    numbers: true,
    semantic: true,
    types: "bool char double float int long short string void size_t ssize_t",
    ..PLAIN
};
pub(crate) const HASH: Rules = Rules {
    line_comments: &["#"],
    quotes: b"\"'",
    numbers: true,
    semantic: true,
    ..PLAIN
};
pub(crate) const MARKUP: Rules = Rules {
    blocks: &[("<!--", "-->")],
    quotes: b"\"'",
    markup: true,
    numbers: true,
    ..PLAIN
};
#[derive(Default)]
pub(crate) struct State {
    pub(crate) depth: usize,
    raw: Option<&'static str>,
    block: Option<&'static str>,
    quote: Option<u8>,
    tag: bool,
    tag_name: bool,
    attribute_depth: usize,
    declaration: Option<Style>,
}
fn push(out: &mut Vec<Span>, value: &str, style: Style) {
    if let Some(last) = out.last_mut().filter(|s| s.style == style) {
        last.text.push_str(value);
    } else {
        out.push(Span {
            math: None,
            text: value.into(),
            style,
        });
    }
}
fn quoted(s: &str, mut i: usize, quote: u8) -> (usize, bool) {
    let bytes = s.as_bytes();
    while i < bytes.len() {
        if bytes[i] == b'\\' {
            i = (i + 2).min(bytes.len());
        } else if bytes[i] == quote {
            // SQL/CSV doubled quotes also remain one string run.
            if bytes.get(i + 1) == Some(&quote) {
                i += 2;
            } else {
                return (i + 1, true);
            }
        } else {
            i += 1;
        }
    }
    (s.len(), false)
}
pub(crate) fn highlight(s: &str, rules: Rules, state: &mut State) -> Vec<Span> {
    if rules.diff {
        let style = if ["+++", "---", "@@", "diff ", "index "]
            .iter()
            .any(|prefix| s.starts_with(prefix))
        {
            Style::Meta
        } else if s.starts_with('+') {
            Style::Added
        } else if s.starts_with('-') {
            Style::Removed
        } else if s.starts_with("\\ No newline") {
            Style::Comment
        } else {
            Style::Normal
        };
        return vec![Span {
            math: None,
            text: s.into(),
            style,
        }];
    }
    let mut out = Vec::new();
    let mut i = 0;
    while i < s.len() {
        let start = i;
        let tail = &s[i..];
        let byte = s.as_bytes()[i];
        let style = if let Some(end) = state.raw {
            if let Some(n) = tail.find(end) {
                i += n + end.len();
                state.raw = None;
            } else {
                i = s.len();
            }
            Style::String
        } else if let Some(end) = state.block {
            i = block_end(s, i, end, rules, state);
            Style::Comment
        } else if let Some(quote) = state.quote {
            let (end, closed) = quoted(s, i, quote);
            i = end;
            if closed {
                state.quote = None;
            }
            Style::String
        } else if let Some((open, end)) =
            rules.blocks.iter().find(|(open, _)| tail.starts_with(open))
        {
            state.block = Some(end);
            state.depth = 1;
            i = block_end(s, i + open.len(), end, rules, state);
            Style::Comment
        } else if let Some(delim) = rules.raw_delimiters.iter().find(|d| tail.starts_with(**d)) {
            i += delim.len();
            if let Some(n) = s[i..].find(*delim) {
                i += n + delim.len();
            } else {
                i = s.len();
                state.raw = Some(delim);
            }
            Style::String
        } else if rules.line_comments.iter().any(|p| tail.starts_with(p)) {
            i = s.len();
            Style::Comment
        } else if rules.quotes.contains(&byte)
            && (!rules.char_literals
                || byte != b'\''
                || tail[1..].starts_with('\\')
                || tail[1..].chars().nth(1) == Some('\''))
        {
            let (end, closed) = quoted(s, i + 1, byte);
            i = end;
            if !closed && rules.multiline_quotes.contains(&byte) {
                state.quote = Some(byte);
            }
            if closed && rules.keys && s[i..].trim_start().starts_with(['=', ':']) {
                Style::Key
            } else {
                Style::String
            }
        } else if rules.markup && byte == b'<' {
            state.tag = true;
            state.tag_name = true;
            i += 1;
            Style::Keyword
        } else if rules.markup && byte == b'>' {
            state.tag = false;
            state.tag_name = false;
            i += 1;
            Style::Keyword
        } else if rules.delimiter == Some(byte) {
            i += 1;
            Style::Keyword
        } else if rules.numbers && byte.is_ascii_digit() {
            i += 1;
            while i < s.len()
                && (s.as_bytes()[i].is_ascii_alphanumeric() || b"._".contains(&s.as_bytes()[i]))
            {
                i += 1;
            }
            Style::Number
        } else if rules.semantic && tail.starts_with("#[") {
            state.attribute_depth = 1;
            i += 2;
            Style::Attribute
        } else {
            let c = tail.chars().next().unwrap();
            if c.is_alphabetic() || c == '_' || c == '$' {
                i += c.len_utf8();
                while i < s.len() {
                    let c = s[i..].chars().next().unwrap();
                    if !(c.is_alphanumeric()
                        || c == '_'
                        || c == '$'
                        || (rules.keys && matches!(c, '.' | '-'))
                        || (rules.markup && state.tag && matches!(c, ':' | '-')))
                    {
                        break;
                    }
                    i += c.len_utf8();
                }
                let word = &s[start..i];
                identifier_style(s, start, i, word, rules, state)
            } else {
                i += c.len_utf8();
                if state.attribute_depth > 0 {
                    match c {
                        '[' => state.attribute_depth += 1,
                        ']' => state.attribute_depth -= 1,
                        _ => {}
                    }
                }
                if matches!(c, ';' | '=' | '{' | '}') {
                    state.declaration = None;
                }
                Style::Normal
            }
        };
        push(&mut out, &s[start..i], style);
    }
    out
}

fn listed(word: &str, words: &str, insensitive: bool) -> bool {
    words.split_ascii_whitespace().any(|candidate| {
        if insensitive {
            word.eq_ignore_ascii_case(candidate)
        } else {
            word == candidate
        }
    })
}
/// Bounded lexical roles, not symbol resolution or a complete language parser.
/// Comments and strings have already been consumed before this runs.
fn identifier_style(
    s: &str,
    start: usize,
    end: usize,
    word: &str,
    rules: Rules,
    state: &mut State,
) -> Style {
    let following = s[end..].trim_start();
    if rules.markup && state.tag {
        if state.tag_name {
            state.tag_name = false;
            return Style::Tag;
        }
        return Style::Attribute;
    }
    if rules.keys && following.starts_with(['=', ':']) {
        return Style::Key;
    }
    let preceding = s[..start].trim_end();
    if rules.semantic && (state.attribute_depth > 0 || preceding.trim_start() == "@") {
        return Style::Attribute;
    }
    if listed(word, rules.types, rules.insensitive) {
        return Style::Type;
    }
    if listed(word, rules.keywords, rules.insensitive) {
        if rules.semantic {
            if listed(word, "fn def func fun function", rules.insensitive) {
                state.declaration = Some(Style::Function);
            } else if listed(
                word,
                "class struct enum trait interface type",
                rules.insensitive,
            ) {
                state.declaration = Some(Style::Type);
            } else if word == "const" || (word == "static" && rules.char_literals) {
                state.declaration = Some(Style::Constant);
            } else if !listed(word, "mut pub unsafe async ref", rules.insensitive) {
                state.declaration = None;
            }
        }
        if ["true", "false", "null", "none", "nil"]
            .iter()
            .any(|value| word.eq_ignore_ascii_case(value))
        {
            return Style::Constant;
        }
        return Style::Keyword;
    }
    if rules.semantic
        && let Some(style) = state.declaration.take()
    {
        return style;
    }
    if !rules.semantic {
        return Style::Normal;
    }
    if word.len() > 1
        && word.chars().any(char::is_uppercase)
        && word
            .chars()
            .all(|c| c.is_uppercase() || c.is_ascii_digit() || matches!(c, '_' | '$'))
    {
        return Style::Constant;
    }
    if following.starts_with('(')
        || following
            .strip_prefix('!')
            .is_some_and(|rest| rest.trim_start().starts_with(['(', '[', '{']))
    {
        return Style::Function;
    }
    if preceding.ends_with('.') && !preceding.ends_with("..") {
        return Style::Property;
    }
    if word.chars().next().is_some_and(char::is_uppercase) {
        return Style::Type;
    }
    Style::Normal
}
pub(crate) fn info(
    id: &'static str,
    name: &'static str,
    extension: &'static [&'static str],
) -> FormatInfo {
    FormatInfo {
        id,
        display_name: name,
        kind: Kind::Text,
        extensions: extension,
        magic: &[],
        modes: &[PreviewMode::Source],
        limits: Limits {
            max_input_bytes: TEXT_LIMIT,
            allow_truncation: true,
        },
    }
}
pub(crate) fn preview(input: &Input<'_>, rules: Rules) -> Result<Output, PreviewError> {
    if input.mode != PreviewMode::Source {
        return Err(PreviewError::UnsupportedMode);
    }
    let text = String::from_utf8_lossy(&input.bytes[..input.bytes.len().min(TEXT_LIMIT)]);
    let text = text.strip_prefix('\u{feff}').unwrap_or(&text);
    let mut truncated = input.truncated || input.bytes.len() > TEXT_LIMIT;
    let mut state = State::default();
    let mut lines = Vec::new();
    for (index, line) in text.lines().enumerate() {
        if index == MAX_LINES {
            truncated = true;
            break;
        }
        let end = line
            .char_indices()
            .nth(MAX_LINE_CHARS)
            .map(|(i, _)| i)
            .unwrap_or(line.len());
        truncated |= end < line.len();
        lines.push(Line {
            source: index + 1,
            code: true,
            spans: highlight(&line[..end], rules, &mut state),
            ..Line::default()
        });
    }
    if lines.is_empty() {
        lines.push(Line {
            source: 1,
            code: true,
            ..Line::default()
        });
    }
    Ok(Output::Text(Document {
        lines,
        truncated,
        line_numbers: true,
    }))
}
fn block_end(s: &str, mut i: usize, end: &'static str, rules: Rules, state: &mut State) -> usize {
    while i < s.len() {
        if rules.nested_comments && s[i..].starts_with("/*") {
            state.depth += 1;
            i += 2;
        } else if s[i..].starts_with(end) {
            i += end.len();
            state.depth = state.depth.saturating_sub(1);
            if state.depth == 0 {
                state.block = None;
                return i;
            }
        } else {
            i += s[i..].chars().next().unwrap().len_utf8();
        }
    }
    i
}
pub(crate) fn fence_rules(lang: &str) -> Rules {
    super::LANGUAGES
        .iter()
        .find(|(name, _)| name.eq_ignore_ascii_case(lang))
        .map(|(_, r)| *r)
        .unwrap_or(PLAIN)
}

#[cfg(test)]
impl State {
    pub(crate) fn restore_comment(&mut self, depth: usize) {
        self.depth = depth;
        self.block = if depth > 0 { Some("*/") } else { None };
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn comments_strings_and_unicode_are_lossless() {
        let mut state = State::default();
        for line in ["let 中文 = \"//字\"; /* start", " comment */ return 42;"] {
            let spans = highlight(
                line,
                Rules {
                    keywords: "let return",
                    ..CODE
                },
                &mut state,
            );
            assert_eq!(
                spans.iter().map(|s| s.text.as_str()).collect::<String>(),
                line
            );
            assert!(spans.iter().any(|s| s.style == Style::Comment));
            assert!(spans.iter().any(|s| s.style == Style::Keyword));
        }
    }
    #[test]
    fn quoted_delimiters_and_markup_comments() {
        let spans = highlight(
            "\"a,b\",c",
            Rules {
                quotes: b"\"",
                delimiter: Some(b','),
                ..PLAIN
            },
            &mut State::default(),
        );
        assert_eq!(spans[0].text, "\"a,b\"");
        assert_eq!(spans[1].style, Style::Keyword);
        let spans = highlight(
            "<!-- <script> --> <p id=\"x\">Hi</p>",
            MARKUP,
            &mut State::default(),
        );
        assert_eq!(spans[0].style, Style::Comment);
        assert!(
            spans
                .iter()
                .any(|s| s.style == Style::Tag && s.text.contains('p'))
        );
    }
}
