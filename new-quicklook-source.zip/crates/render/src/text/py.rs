use super::common::{self, HASH, Rules};
use quicklook_core::*;
pub(super) const RULES: Rules = Rules {
    keywords: "def class return if else elif for while in import from as try except finally with yield lambda True False None and or not is pass break continue async await raise",
    types: "bool bytes dict float frozenset int list object set str tuple type",
    raw_delimiters: &["\"\"\"", "'''"],
    ..HASH
};
pub struct Python;
impl FormatPreview for Python {
    fn info(&self) -> FormatInfo {
        common::info("python", "Python", &["py", "pyw"])
    }
    fn preview(&self, input: &Input<'_>) -> Result<Output, PreviewError> {
        common::preview(input, RULES)
    }
}
#[cfg(test)]
pub fn parse(bytes: &[u8], truncated: bool) -> Document {
    let Output::Text(doc) = common::preview(
        &Input {
            bytes,
            truncated,
            mode: PreviewMode::Source,
            viewport: (1, 1),
        },
        RULES,
    )
    .unwrap() else {
        unreachable!()
    };
    doc
}
#[cfg(test)]
pub fn python_line(s: &str) -> Vec<Span> {
    common::highlight(s, RULES, &mut common::State::default())
}
