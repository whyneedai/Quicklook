//! .bib source preview. Format-specific policy stays in this module.
use super::common::{self, PLAIN, Rules};
use quicklook_core::{FormatInfo, FormatPreview, Input, Output, PreviewError};
pub(super) const RULES: Rules = Rules {
    keywords: "article book booklet conference inbook incollection inproceedings manual mastersthesis misc phdthesis proceedings techreport unpublished online patent string preamble comment",
    line_comments: &["%"],
    quotes: b"\"",
    numbers: true,
    ..PLAIN
};
pub struct Component;
impl FormatPreview for Component {
    fn info(&self) -> FormatInfo {
        common::info("bib", "BibTeX", &["bib"])
    }
    fn preview(&self, input: &Input<'_>) -> Result<Output, PreviewError> {
        common::preview(input, RULES)
    }
}
