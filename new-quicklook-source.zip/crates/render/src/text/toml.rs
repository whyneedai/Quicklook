//! .toml source preview. Format-specific policy stays in this module.
use super::common::{self, HASH, Rules};
use quicklook_core::{FormatInfo, FormatPreview, Input, Output, PreviewError};
pub(super) const RULES: Rules = Rules {
    keywords: "true false inf nan",
    keys: true,
    semantic: false,
    ..HASH
};
pub struct Component;
impl FormatPreview for Component {
    fn info(&self) -> FormatInfo {
        common::info("toml", "TOML", &["toml"])
    }
    fn preview(&self, input: &Input<'_>) -> Result<Output, PreviewError> {
        common::preview(input, RULES)
    }
}
