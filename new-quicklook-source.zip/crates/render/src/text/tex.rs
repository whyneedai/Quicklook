//! .tex source preview. Format-specific policy stays in this module.
use super::common::{self, PLAIN, Rules};
use quicklook_core::{FormatInfo, FormatPreview, Input, Output, PreviewError};
pub(super) const RULES: Rules = Rules {
    keywords: "documentclass usepackage begin end section subsection subsubsection chapter part paragraph label ref cite bibliography bibliographystyle item enumerate description figure table center include input frac sqrt sum int alpha beta gamma delta epsilon theta lambda mu pi rho sigma phi psi omega Gamma Delta Theta Lambda Pi Sigma Phi Psi Omega left right cdot times pm le ge ne approx equiv to rightarrow partial nabla forall exists in notin subset cup cap emptyset vec hat bar overline underline mathrm mathbf mathit text quad qquad ldots cdots newcommand renewcommand def let textbf textit emph footnote caption title author date maketitle",
    line_comments: &["%"],
    delimiter: Some(b'$'),
    numbers: true,
    ..PLAIN
};
pub struct Component;
impl FormatPreview for Component {
    fn info(&self) -> FormatInfo {
        common::info("tex", "LaTeX", &["tex"])
    }
    fn preview(&self, input: &Input<'_>) -> Result<Output, PreviewError> {
        common::preview(input, RULES)
    }
}
