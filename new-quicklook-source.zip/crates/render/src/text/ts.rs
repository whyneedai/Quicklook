//! .ts source preview. Format-specific policy stays in this module.
use super::common::{self, CODE, Rules};
use quicklook_core::{FormatInfo, FormatPreview, Input, Output, PreviewError};
pub(super) const RULES: Rules = Rules {
    keywords: "abstract any as async await boolean break case catch class const constructor continue declare default delete do else enum export extends false finally for from function if implements import in infer instanceof interface is keyof let namespace never new null number of private protected public readonly return static string super switch symbol this throw true try type typeof undefined unknown var void while yield",
    quotes: b"\"'`",
    multiline_quotes: b"`",
    types: "any boolean bigint never number object string symbol unknown void",
    ..CODE
};
pub struct Component;
impl FormatPreview for Component {
    fn info(&self) -> FormatInfo {
        common::info("ts", "TypeScript", &["ts"])
    }
    fn preview(&self, input: &Input<'_>) -> Result<Output, PreviewError> {
        common::preview(input, RULES)
    }
}
