//! .sh source preview. Format-specific policy stays in this module.
use super::common::{self, HASH, Rules};
use quicklook_core::{FormatInfo, FormatPreview, Input, Output, PreviewError};
pub(super) const RULES: Rules = Rules {
    keywords: "if then else elif fi case esac for while until do done in function select time export local readonly return break continue",
    ..HASH
};
pub struct Component;
impl FormatPreview for Component {
    fn info(&self) -> FormatInfo {
        common::info("sh", "Shell", &["sh"])
    }
    fn preview(&self, input: &Input<'_>) -> Result<Output, PreviewError> {
        common::preview(input, RULES)
    }
}
