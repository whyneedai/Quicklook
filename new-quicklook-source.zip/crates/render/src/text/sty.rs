//! .sty source preview. Format-specific policy stays in this module.
use super::common::{self, PLAIN, Rules};
use quicklook_core::{FormatInfo, FormatPreview, Input, Output, PreviewError};
pub(super) const RULES: Rules = Rules {
    keywords: "NeedsTeXFormat ProvidesPackage ProvidesClass DeclareOption ProcessOptions LoadClass RequirePackage def newcommand renewcommand let begin end ifelse fi else newif",
    line_comments: &["%"],
    numbers: true,
    ..PLAIN
};
pub struct Component;
impl FormatPreview for Component {
    fn info(&self) -> FormatInfo {
        common::info("sty", "LaTeX Package", &["sty"])
    }
    fn preview(&self, input: &Input<'_>) -> Result<Output, PreviewError> {
        common::preview(input, RULES)
    }
}
