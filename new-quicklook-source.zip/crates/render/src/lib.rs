//! Components organized by model family; no cross-family imports.
mod image;
mod pages;
mod text;
use quicklook_core::FormatPreview;
pub fn components() -> &'static [&'static dyn FormatPreview] {
    static REGISTRY: std::sync::OnceLock<Vec<&'static dyn FormatPreview>> =
        std::sync::OnceLock::new();
    REGISTRY.get_or_init(|| {
        text::components()
            .iter()
            .chain(image::components())
            .chain(pages::components())
            .copied()
            .collect()
    })
}
