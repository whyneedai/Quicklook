//! Versioned, bounded formula IPC and a renderer-independent bitmap model.
use std::io::{self, Read, Write};
pub const MAX_TEX: usize = 2048;
pub const MAX_BITMAP: usize = 2048 * 512 * 4;
pub const CACHE_BYTES: usize = 8 * 1024 * 1024;
pub const WORKER: crate::worker::Spec = crate::worker::Spec {
    id: 1,
    exe: "math-worker.exe",
    memory_bytes: 128 * 1024 * 1024,
    timeout_ms: 1000,
    idle_ms: 30_000,
    cache_bytes: CACHE_BYTES,
    request_bytes: MAX_TEX + 32,
    response_bytes: MAX_BITMAP + 52,
};
#[derive(Clone, Debug)]
pub enum State {
    Pending,
    Ready(std::sync::Arc<Bitmap>),
    Fallback,
}
#[derive(Clone, Debug)]
pub struct Formula {
    pub display: bool,
    pub state: State,
}
/// Which renderer produced a bitmap (diagnostic; routing happens inside the worker).
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Backend {
    Rich,
    SelfRender,
    Fallback,
}
impl Backend {
    pub fn label(self) -> &'static str {
        match self {
            Self::Rich => "rich",
            Self::SelfRender => "self",
            Self::Fallback => "fallback",
        }
    }
}
#[derive(Clone, Debug)]
pub struct Bitmap {
    pub backend: Backend,
    pub dpi: u32,
    pub convert_us: u32,
    pub draw_us: u32,
    pub width: u32,
    pub height: u32,
    pub baseline: u32,
    pub bgra: Vec<u8>,
}
#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub struct Request {
    pub id: u64,
    pub generation: u64,
    pub tex: String,
    pub display: bool,
    pub dpi: u32,
}
fn invalid() -> io::Error {
    io::Error::new(
        io::ErrorKind::InvalidData,
        "Invalid or over-budget math IPC",
    )
}
/// Structural gate only: length, encoding, brace balance/depth. Whether a command
/// can be *rendered* is decided inside the worker (RichEdit first, then the
/// self-written subset); the main process must not pre-reject commands, because
/// RichEdit typesets far more than the old whitelist allowed.
pub fn structurally_valid(tex: &str) -> bool {
    if tex.is_empty()
        || tex.len() > MAX_TEX
        || tex
            .chars()
            .any(|c| c == '\0' || (c.is_control() && !matches!(c, '\n' | '\r' | '\t')))
    {
        return false;
    }
    let mut depth = 0u32;
    for c in tex.chars() {
        match c {
            '{' => {
                depth += 1;
                if depth > 16 {
                    return false;
                }
            }
            '}' => {
                if depth == 0 {
                    return false;
                }
                depth -= 1;
            }
            _ => {}
        }
    }
    depth == 0
}

/// Braced argument at `i` (which must point at `{`) -> (content, next index).
fn take_braced(s: &str, i: usize) -> Option<(String, usize)> {
    if s.as_bytes().get(i) != Some(&b'{') {
        return None;
    }
    let mut depth = 0usize;
    for (off, c) in s[i..].char_indices() {
        match c {
            '{' => depth += 1,
            '}' => {
                depth -= 1;
                if depth == 0 {
                    return Some((s[i + 1..i + off].to_string(), i + off + 1));
                }
            }
            _ => {}
        }
    }
    None
}

/// `\begin{env} ... \end{env}` at `i` -> (env, body, next index).
fn take_environment(s: &str, i: usize) -> Option<(String, String, usize)> {
    let head = s[i..].strip_prefix("\\begin{")?;
    let close = head.find('}')?;
    let env = head[..close].to_string();
    let body_start = i + "\\begin{".len() + close + 1;
    let end_token = format!("\\end{{{env}}}");
    let end_pos = s[body_start..].find(&end_token)? + body_start;
    Some((
        env,
        s[body_start..end_pos].to_string(),
        end_pos + end_token.len(),
    ))
}

/// Best-effort rewrite of constructs RichEdit prints literally, into equivalents it
/// typesets. Returns None only when the input is structurally invalid.
pub fn normalize(tex: &str) -> Option<String> {
    if !structurally_valid(tex) {
        return None;
    }
    let mut out = String::with_capacity(tex.len() + 16);
    let mut i = 0usize;
    while i < tex.len() {
        let rest = &tex[i..];
        if rest.starts_with("\\begin{")
            && let Some((env, body, next)) = take_environment(tex, i)
        {
            let (open, close) = match env.as_str() {
                "bmatrix" => ("\\left[", "\\right]"),
                "Bmatrix" => ("\\left\\{", "\\right\\}"),
                "vmatrix" => ("\\left|", "\\right|"),
                "pmatrix" => ("\\left(", "\\right)"),
                "cases" => ("\\left\\{", "\\right."),
                _ => ("", ""),
            };
            let body = if env == "array" {
                let trimmed = body.trim_start();
                if trimmed.starts_with('{') {
                    take_braced(trimmed, 0)
                        .map(|(_, n)| trimmed[n..].to_string())
                        .unwrap_or_else(|| trimmed.to_string())
                } else {
                    trimmed.to_string()
                }
            } else {
                body
            };
            out.push_str(open);
            out.push_str("\\begin{matrix}");
            out.push_str(&body);
            out.push_str("\\end{matrix}");
            out.push_str(close);
            i = next;
            continue;
        }
        if rest.starts_with("\\dfrac") || rest.starts_with("\\tfrac") {
            out.push_str("\\frac");
            i += "\\dfrac".len();
            continue;
        }
        if rest.starts_with("\\operatorname") {
            let mut j = i + "\\operatorname".len();
            if tex[j..].starts_with('*') {
                j += 1;
            }
            if let Some((arg, next)) = take_braced(tex, j) {
                out.push_str("\\mathrm{");
                out.push_str(&arg);
                out.push('}');
                i = next;
                continue;
            }
        }
        if rest.starts_with("\\color") {
            let after = i + "\\color".len();
            if let Some((_, next)) = take_braced(tex, after) {
                i = next;
                continue;
            }
            let mut j = after;
            while tex.as_bytes().get(j) == Some(&b' ') {
                j += 1;
            }
            while tex.as_bytes().get(j).is_some_and(u8::is_ascii_alphabetic) {
                j += 1;
            }
            i = j;
            continue;
        }
        let c = rest.chars().next().unwrap();
        out.push(c);
        i += c.len_utf8();
    }
    Some(out)
}

fn u32_read(r: &mut impl Read) -> io::Result<u32> {
    let mut b = [0; 4];
    r.read_exact(&mut b)?;
    Ok(u32::from_le_bytes(b))
}
fn u64_read(r: &mut impl Read) -> io::Result<u64> {
    let mut b = [0; 8];
    r.read_exact(&mut b)?;
    Ok(u64::from_le_bytes(b))
}
pub fn write_request(w: &mut impl Write, q: &Request) -> io::Result<()> {
    if !structurally_valid(&q.tex) || !(96..=384).contains(&q.dpi) {
        return Err(invalid());
    }
    w.write_all(b"NQM1")?;
    w.write_all(&q.id.to_le_bytes())?;
    w.write_all(&q.generation.to_le_bytes())?;
    for n in [q.dpi, u32::from(q.display), q.tex.len() as u32] {
        w.write_all(&n.to_le_bytes())?;
    }
    w.write_all(q.tex.as_bytes())?;
    w.flush()
}
pub fn read_request(r: &mut impl Read) -> io::Result<Request> {
    let mut magic = [0; 4];
    r.read_exact(&mut magic)?;
    if &magic != b"NQM1" {
        return Err(invalid());
    }
    let id = u64_read(r)?;
    let generation = u64_read(r)?;
    let dpi = u32_read(r)?;
    let display = u32_read(r)?;
    let len = u32_read(r)? as usize;
    if len > MAX_TEX || display > 1 || !(96..=384).contains(&dpi) {
        return Err(invalid());
    }
    let mut bytes = vec![0; len];
    r.read_exact(&mut bytes)?;
    let tex = String::from_utf8(bytes).map_err(|_| invalid())?;
    if !structurally_valid(&tex) {
        return Err(invalid());
    }
    Ok(Request {
        id,
        generation,
        tex,
        display: display != 0,
        dpi,
    })
}
pub fn write_response(w: &mut impl Write, q: &Request, bitmap: Option<&Bitmap>) -> io::Result<()> {
    w.write_all(b"NQR2")?;
    w.write_all(&q.id.to_le_bytes())?;
    w.write_all(&q.generation.to_le_bytes())?;
    let (width, height, baseline, pixels) = bitmap
        .map(|b| (b.width, b.height, b.baseline, b.bgra.as_slice()))
        .unwrap_or((0, 0, 0, &[]));
    for n in [
        width,
        height,
        baseline,
        pixels.len() as u32,
        q.dpi,
        bitmap.map_or(0, |b| b.convert_us),
        bitmap.map_or(0, |b| b.draw_us),
        match bitmap.map(|b| b.backend) {
            Some(Backend::Rich) => 0,
            Some(Backend::SelfRender) => 1,
            _ => 2,
        },
    ] {
        w.write_all(&n.to_le_bytes())?;
    }
    w.write_all(pixels)?;
    w.flush()
}
pub fn read_response(r: &mut impl Read) -> io::Result<(u64, u64, Option<Bitmap>)> {
    let mut magic = [0; 4];
    r.read_exact(&mut magic)?;
    if &magic != b"NQR2" {
        return Err(invalid());
    }
    let id = u64_read(r)?;
    let generation = u64_read(r)?;
    let width = u32_read(r)?;
    let height = u32_read(r)?;
    let baseline = u32_read(r)?;
    let len = u32_read(r)? as usize;
    let dpi = u32_read(r)?;
    let convert_us = u32_read(r)?;
    let draw_us = u32_read(r)?;
    let backend = match u32_read(r)? {
        0 => Backend::Rich,
        1 => Backend::SelfRender,
        _ => Backend::Fallback,
    };
    if !(96..=384).contains(&dpi) {
        return Err(invalid());
    }
    if width == 0 && height == 0 && baseline == 0 && len == 0 {
        return Ok((id, generation, None));
    }
    if width == 0
        || width > 2048
        || height == 0
        || height > 512
        || baseline > height
        || len > MAX_BITMAP
        || len != width as usize * height as usize * 4
    {
        return Err(invalid());
    }
    let mut bgra = vec![0; len];
    r.read_exact(&mut bgra)?;
    Ok((
        id,
        generation,
        Some(Bitmap {
            backend,
            dpi,
            convert_us,
            draw_us,
            width,
            height,
            baseline,
            bgra,
        }),
    ))
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn boundaries_and_roundtrip() {
        for t in [
            "\\frac{1}{2}",
            "x^2",
            "\\sqrt{x}",
            "\\begin{cases}x",
            "\\unknown{x}",
        ] {
            assert!(structurally_valid(t), "{t}");
        }
        for t in ["a\0b", "{x", "}", "a\u{1}b"] {
            assert!(!structurally_valid(t), "{t}");
        }
        assert!(!structurally_valid(&"{".repeat(17)));
        assert!(!structurally_valid(&"x".repeat(2049)));
        let q = Request {
            id: 3,
            generation: 8,
            tex: "x^2".into(),
            display: false,
            dpi: 144,
        };
        let mut b = vec![];
        write_request(&mut b, &q).unwrap();
        assert_eq!(read_request(&mut &b[..]).unwrap(), q);
    }
    #[test]
    fn normalize_rewrites_unsupported_constructs() {
        assert_eq!(normalize("\\dfrac{1}{2}").unwrap(), "\\frac{1}{2}");
        assert_eq!(normalize("\\tfrac{1}{2}").unwrap(), "\\frac{1}{2}");
        assert_eq!(
            normalize("\\operatorname{sgn}(x)").unwrap(),
            "\\mathrm{sgn}(x)"
        );
        assert_eq!(normalize("\\color{red} x").unwrap(), " x");
        assert_eq!(
            normalize("\\begin{bmatrix} a & b \\\\ c & d \\end{bmatrix}").unwrap(),
            "\\left[\\begin{matrix} a & b \\\\ c & d \\end{matrix}\\right]"
        );
        assert_eq!(
            normalize("\\begin{cases} x & x>0 \\\\ -x & x\\le 0 \\end{cases}").unwrap(),
            "\\left\\{\\begin{matrix} x & x>0 \\\\ -x & x\\le 0 \\end{matrix}\\right."
        );
        assert!(normalize("{x").is_none());
    }
    proptest::proptest! { #[test] fn malformed_wire_never_panics(bytes in proptest::collection::vec(proptest::prelude::any::<u8>(),0..8192)) { let _=read_request(&mut &bytes[..]);let _=read_response(&mut &bytes[..]); } }
}
