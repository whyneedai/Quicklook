//! Bounded, versioned transport shared by isolated rendering processes.
use std::io::{self, Read, Write};
pub const VERSION: u16 = 1;
#[derive(Clone, Copy, Debug)]
pub struct Spec {
    pub id: u16,
    pub exe: &'static str,
    pub memory_bytes: usize,
    pub timeout_ms: u64,
    pub idle_ms: u64,
    pub cache_bytes: usize,
    pub request_bytes: usize,
    pub response_bytes: usize,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
#[repr(u16)]
pub enum Message {
    Hello = 1,
    Welcome = 2,
    Request = 3,
    Response = 4,
}
#[derive(Debug, PartialEq, Eq)]
pub struct Frame {
    pub message: Message,
    pub id: u64,
    pub generation: u64,
    pub payload: Vec<u8>,
}
pub fn invalid() -> io::Error {
    io::Error::new(io::ErrorKind::InvalidData, "Invalid worker protocol")
}
pub fn read(r: &mut impl Read, limit: usize) -> io::Result<Frame> {
    let mut h = [0u8; 28];
    r.read_exact(&mut h)?;
    if &h[..4] != b"NQW1" || u16::from_le_bytes(h[4..6].try_into().unwrap()) != VERSION {
        return Err(invalid());
    }
    let message = match u16::from_le_bytes(h[6..8].try_into().unwrap()) {
        1 => Message::Hello,
        2 => Message::Welcome,
        3 => Message::Request,
        4 => Message::Response,
        _ => return Err(invalid()),
    };
    let len = u32::from_le_bytes(h[24..28].try_into().unwrap()) as usize;
    if len > limit {
        return Err(invalid());
    }
    let mut payload = vec![0; len];
    r.read_exact(&mut payload)?;
    Ok(Frame {
        message,
        id: u64::from_le_bytes(h[8..16].try_into().unwrap()),
        generation: u64::from_le_bytes(h[16..24].try_into().unwrap()),
        payload,
    })
}
pub fn write(w: &mut impl Write, f: &Frame, limit: usize) -> io::Result<()> {
    if f.payload.len() > limit || f.payload.len() > u32::MAX as usize {
        return Err(invalid());
    }
    w.write_all(b"NQW1")?;
    w.write_all(&VERSION.to_le_bytes())?;
    w.write_all(&(f.message as u16).to_le_bytes())?;
    w.write_all(&f.id.to_le_bytes())?;
    w.write_all(&f.generation.to_le_bytes())?;
    w.write_all(&(f.payload.len() as u32).to_le_bytes())?;
    w.write_all(&f.payload)?;
    w.flush()
}
pub fn hello(spec: Spec, message: Message) -> Frame {
    Frame {
        message,
        id: 0,
        generation: 0,
        payload: spec.id.to_le_bytes().to_vec(),
    }
}
pub fn serve(
    r: &mut impl Read,
    w: &mut impl Write,
    spec: Spec,
    mut handle: impl FnMut(&Frame) -> io::Result<Vec<u8>>,
) -> io::Result<()> {
    if read(r, 2)? != hello(spec, Message::Hello) {
        return Err(invalid());
    }
    write(w, &hello(spec, Message::Welcome), 2)?;
    loop {
        let f = read(r, spec.request_bytes)?;
        if f.message != Message::Request || f.id == 0 {
            return Err(invalid());
        }
        let payload = handle(&f)?;
        write(
            w,
            &Frame {
                message: Message::Response,
                id: f.id,
                generation: f.generation,
                payload,
            },
            spec.response_bytes,
        )?;
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn rejects_headers_before_payload_allocation() {
        let f = Frame {
            message: Message::Request,
            id: 7,
            generation: 11,
            payload: vec![3; 32],
        };
        let mut bytes = Vec::new();
        write(&mut bytes, &f, 32).unwrap();
        assert_eq!(read(&mut &bytes[..], 32).unwrap(), f);
        assert!(read(&mut &bytes[..28], 31).is_err());
        for offset in [0, 4, 6] {
            let mut bad = bytes.clone();
            bad[offset] = 255;
            assert!(read(&mut &bad[..], 32).is_err());
        }
        assert!(read(&mut &bytes[..40], 32).is_err());
        assert!(write(&mut Vec::new(), &f, 31).is_err());
    }
    proptest::proptest! { #[test] fn malformed_frames_are_bounded(bytes in proptest::collection::vec(proptest::prelude::any::<u8>(),0..4096)) { let _ = read(&mut &bytes[..],1024); } }
}
