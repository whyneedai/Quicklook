pub fn fit_size(width: u32, height: u32, bound_w: u32, bound_h: u32) -> (u32, u32) {
    if width == 0 || height == 0 || bound_w == 0 || bound_h == 0 {
        return (0, 0);
    }
    let bw = bound_w.min(width);
    let bh = bound_h.min(height);
    if u64::from(width) * u64::from(bh) > u64::from(height) * u64::from(bw) {
        (
            bw,
            ((u64::from(height) * u64::from(bw) / u64::from(width)) as u32).max(1),
        )
    } else {
        (
            ((u64::from(width) * u64::from(bh) / u64::from(height)) as u32).max(1),
            bh,
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use proptest::prelude::*;
    proptest! { #[test] fn fit_is_bounded(w in 1u32..=u32::MAX,h in 1u32..=u32::MAX,bw in 1u32..2000,bh in 1u32..2000) {let (x,y)=fit_size(w,h,bw,bh);prop_assert!(x>0&&y>0&&x<=bw&&y<=bh&&x<=w&&y<=h);} }
}
