//! Generic paginated-worker payloads: bounded input, page metadata and encoded image.
use crate::worker::{Spec, invalid};
use std::io;
pub const INPUT_BYTES: usize = 64 * 1024 * 1024;
pub const IMAGE_BYTES: usize = 16 * 1024 * 1024;
pub const MAX_PAGES: u32 = 10_000;
pub const PDF_WORKER: Spec = Spec {
    id: 2,
    exe: "pdf-worker.exe",
    memory_bytes: 256 * 1024 * 1024,
    timeout_ms: 5000,
    idle_ms: 30_000,
    cache_bytes: 16 * 1024 * 1024,
    request_bytes: INPUT_BYTES + 20,
    response_bytes: IMAGE_BYTES + 24,
};
pub struct Request<'a> {
    pub source: Option<&'a [u8]>,
    pub index: u32,
    pub bounds: (u32, u32),
}
fn word(bytes: &[u8], offset: usize) -> u32 {
    u32::from_le_bytes(bytes[offset..offset + 4].try_into().unwrap())
}
pub fn dimensions((w, h): (u32, u32)) -> bool {
    w > 0 && h > 0 && w <= 2048 && h <= 2048 && u64::from(w) * u64::from(h) <= 4_000_000
}
impl Request<'_> {
    pub fn encode(&self) -> io::Result<Vec<u8>> {
        let bytes = self.source.unwrap_or_default();
        if self.index >= MAX_PAGES
            || !dimensions(self.bounds)
            || bytes.len() > INPUT_BYTES
            || self.source.is_some_and(|b| b.is_empty())
        {
            return Err(invalid());
        }
        let mut result = Vec::with_capacity(20 + bytes.len());
        for v in [
            if self.source.is_some() { 1 } else { 2 },
            self.index,
            self.bounds.0,
            self.bounds.1,
            bytes.len() as u32,
        ] {
            result.extend_from_slice(&v.to_le_bytes());
        }
        result.extend_from_slice(bytes);
        Ok(result)
    }
    pub fn decode(bytes: &[u8]) -> io::Result<Request<'_>> {
        if bytes.len() < 20 {
            return Err(invalid());
        }
        let len = word(bytes, 16) as usize;
        let tag = word(bytes, 0);
        let bounds = (word(bytes, 8), word(bytes, 12));
        let index = word(bytes, 4);
        if len > INPUT_BYTES
            || len != bytes.len() - 20
            || !dimensions(bounds)
            || index >= MAX_PAGES
            || !matches!((tag, len), (1, 1..) | (2, 0))
        {
            return Err(invalid());
        }
        Ok(Request {
            source: (tag == 1).then_some(&bytes[20..]),
            index,
            bounds,
        })
    }
}
#[derive(Debug)]
pub struct Response<'a> {
    pub index: u32,
    pub count: u32,
    pub size: (u32, u32),
    pub image: &'a [u8],
}
pub fn success(index: u32, count: u32, size: (u32, u32), image: &[u8]) -> io::Result<Vec<u8>> {
    if count == 0
        || count > MAX_PAGES
        || index >= count
        || !dimensions(size)
        || image.is_empty()
        || image.len() > IMAGE_BYTES
    {
        return Err(invalid());
    }
    let mut result = Vec::with_capacity(24 + image.len());
    for v in [0, index, count, size.0, size.1, image.len() as u32] {
        result.extend_from_slice(&v.to_le_bytes());
    }
    result.extend_from_slice(image);
    Ok(result)
}
pub fn failure(message: &str) -> Vec<u8> {
    let mut text = message.to_string();
    while text.len() > 1024 {
        text.pop();
    }
    let mut result = Vec::new();
    for v in [1, 0, 0, 0, 0, text.len() as u32] {
        result.extend_from_slice(&v.to_le_bytes());
    }
    result.extend_from_slice(text.as_bytes());
    result
}
pub fn decode(bytes: &[u8]) -> io::Result<Result<Response<'_>, String>> {
    if bytes.len() < 24 {
        return Err(invalid());
    }
    let len = word(bytes, 20) as usize;
    if len != bytes.len() - 24 {
        return Err(invalid());
    }
    if word(bytes, 0) == 1 {
        if len == 0 || len > 1024 || bytes[4..20].iter().any(|b| *b != 0) {
            return Err(invalid());
        }
        return Ok(Err(std::str::from_utf8(&bytes[24..])
            .map_err(|_| invalid())?
            .into()));
    }
    let index = word(bytes, 4);
    let count = word(bytes, 8);
    let size = (word(bytes, 12), word(bytes, 16));
    if word(bytes, 0) != 0
        || count == 0
        || count > MAX_PAGES
        || index >= count
        || !dimensions(size)
        || len == 0
        || len > IMAGE_BYTES
    {
        return Err(invalid());
    }
    // The paginated payload uses PNG. Check the real IHDR before handing bytes
    // to a decoder: a lying worker cannot request a larger WIC source allocation.
    let image = &bytes[24..];
    if image.len() < 33
        || &image[..8] != b"\x89PNG\r\n\x1a\n"
        || &image[8..16] != b"\0\0\0\rIHDR"
        || (
            u32::from_be_bytes(image[16..20].try_into().unwrap()),
            u32::from_be_bytes(image[20..24].try_into().unwrap()),
        ) != size
    {
        return Err(invalid());
    }
    Ok(Ok(Response {
        index,
        count,
        size,
        image,
    }))
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn paginated_payloads_validate_bounds_and_metadata() {
        let bytes = Request {
            source: Some(b"document"),
            index: 1,
            bounds: (1200, 1600),
        }
        .encode()
        .unwrap();
        assert_eq!(
            Request::decode(&bytes).unwrap().source,
            Some(&b"document"[..])
        );
        assert!(
            Request {
                source: None,
                index: MAX_PAGES,
                bounds: (1, 1)
            }
            .encode()
            .is_err()
        );
        assert!(!dimensions((2048, 2048)));
        assert!(!dimensions((0, 1)));
        let mut image = vec![0; 33];
        image[..16].copy_from_slice(b"\x89PNG\r\n\x1a\n\0\0\0\rIHDR");
        image[16..20].copy_from_slice(&600u32.to_be_bytes());
        image[20..24].copy_from_slice(&800u32.to_be_bytes());
        let bytes = success(1, 3, (600, 800), &image).unwrap();
        assert_eq!(decode(&bytes).unwrap().unwrap().count, 3);
        let mut forged = bytes.clone();
        forged[40..44].copy_from_slice(&100_000u32.to_be_bytes());
        assert!(decode(&forged).is_err());
        assert!(success(3, 3, (600, 800), b"image").is_err());
        assert!(decode(&bytes[..25]).is_err());
        assert_eq!(
            decode(&failure("PDF requires a password"))
                .unwrap()
                .err()
                .unwrap(),
            "PDF requires a password"
        );
    }
    proptest::proptest! { #[test] fn malformed_page_payloads_never_panic(bytes in proptest::collection::vec(proptest::prelude::any::<u8>(),0..8192)) { let _=Request::decode(&bytes);let _=decode(&bytes); } }
}
