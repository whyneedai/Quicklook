#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum Style {
    #[default]
    Normal,
    Keyword,
    String,
    Comment,
    Number,
    Type,
    Function,
    Constant,
    Property,
    Attribute,
    Tag,
    Key,
    Added,
    Removed,
    Meta,
    Bold,
    Emphasis,
    Link,
    Code,
}
#[derive(Clone, Debug)]
pub struct Span {
    pub math: Option<crate::math::Formula>,
    pub text: String,
    pub style: Style,
}
#[derive(Clone, Debug, Default)]
pub struct Line {
    pub table: bool,
    pub source: usize,
    pub heading: u8,
    pub code: bool,
    pub quote: bool,
    pub spans: Vec<Span>,
}
#[derive(Clone, Debug, Default)]
pub struct Document {
    pub lines: Vec<Line>,
    pub truncated: bool,
    pub line_numbers: bool,
}

#[derive(Debug)]
pub struct Image {
    pub width: u32,
    pub height: u32,
    pub original: (u32, u32),
    pub bgra: Vec<u8>,
    pub animation: Option<Animation>,
}

#[derive(Debug)]
pub enum Output {
    Text(Document),
    Image(Image),
    Pages(Pages),
    Error(String),
}
/// A component advertises its worker through the model, never through a frontend suffix.
#[derive(Debug)]
pub struct Pages {
    pub worker: crate::worker::Spec,
    /// Only the initial engine output carries source bytes; discarded after Open.
    pub source: Option<Vec<u8>>,
    pub index: u32,
    pub count: u32,
    pub image: Option<std::sync::Arc<Image>>,
}
impl Output {
    pub fn image(&self) -> Option<&Image> {
        match self {
            Self::Image(i) => Some(i),
            Self::Pages(p) => p.image.as_deref(),
            _ => None,
        }
    }
}
impl Output {
    pub fn plain_text(&self) -> Option<String> {
        match self {
            Self::Text(document) => Some(
                document
                    .lines
                    .iter()
                    .map(|line| {
                        line.spans
                            .iter()
                            .map(|span| span.text.as_str())
                            .collect::<String>()
                    })
                    .collect::<Vec<_>>()
                    .join("\r\n"),
            ),
            _ => None,
        }
    }
}

#[derive(Debug)]
pub struct Animation {
    /// Remaining composited frames; frame zero is Image::bgra.
    pub frames: Vec<Vec<u8>>,
    pub delays_ms: Vec<u32>,
    /// Total plays, zero means forever.
    pub plays: u32,
}
impl Image {
    pub fn frame_index(&self, elapsed_ms: u64) -> usize {
        let Some(a) = &self.animation else { return 0 };
        let total: u64 = a.delays_ms.iter().map(|d| u64::from(*d)).sum();
        if total == 0 {
            return 0;
        }
        if a.plays > 0 && elapsed_ms >= total * u64::from(a.plays) {
            return a.frames.len();
        }
        let mut t = elapsed_ms % total;
        for (index, delay) in a.delays_ms.iter().enumerate() {
            if t < u64::from(*delay) {
                return index;
            }
            t -= u64::from(*delay);
        }
        0
    }
    pub fn is_playing(&self, elapsed_ms: u64) -> bool {
        self.animation.as_ref().is_some_and(|a| {
            a.plays == 0
                || elapsed_ms
                    < a.delays_ms.iter().map(|d| u64::from(*d)).sum::<u64>() * u64::from(a.plays)
        })
    }
    pub fn pixels_at(&self, elapsed_ms: u64) -> &[u8] {
        let index = self.frame_index(elapsed_ms);
        if index == 0 {
            &self.bgra
        } else {
            &self.animation.as_ref().unwrap().frames[index - 1]
        }
    }
}
