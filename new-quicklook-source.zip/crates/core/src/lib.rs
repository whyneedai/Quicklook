//! Platform-neutral contracts. Zero runtime dependencies, no built-in format knowledge.
mod geometry;
mod model;
pub use geometry::fit_size;
pub use model::*;
use std::{fmt, path::Path};
pub const TEXT_LIMIT: usize = 256 * 1024;
pub const PNG_LIMIT: usize = 32 * 1024 * 1024;
pub const MAX_LINES: usize = 6000;
pub const MAX_LINE_CHARS: usize = 2000;
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Kind {
    Text,
    Image,
    Paged,
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PreviewMode {
    Rendered,
    Source,
    Effect,
}
impl PreviewMode {
    pub fn label(self) -> &'static str {
        match self {
            Self::Rendered => "RENDERED",
            Self::Source => "SOURCE",
            Self::Effect => "EFFECT",
        }
    }
}
#[derive(Debug, Clone, Copy)]
pub struct Limits {
    pub max_input_bytes: usize,
    pub allow_truncation: bool,
}
#[derive(Debug, Clone, Copy)]
pub struct FormatInfo {
    pub id: &'static str,
    pub display_name: &'static str,
    pub kind: Kind,
    pub extensions: &'static [&'static str],
    pub magic: &'static [&'static [u8]],
    pub modes: &'static [PreviewMode],
    pub limits: Limits,
}
#[derive(Debug, Clone, Copy)]
pub struct Input<'a> {
    pub bytes: &'a [u8],
    pub viewport: (u32, u32),
    pub mode: PreviewMode,
    pub truncated: bool,
}
#[derive(Debug)]
pub struct Preview {
    pub format: FormatInfo,
    pub mode: PreviewMode,
    pub output: Output,
}
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum PreviewError {
    UnsupportedFormat,
    UnsupportedMode,
    LimitExceeded(&'static str),
    InvalidData(String),
    InvalidRegistry(String),
    Io(String),
}
impl fmt::Display for PreviewError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::UnsupportedFormat => f.write_str("No preview component recognizes this file"),
            Self::UnsupportedMode => f.write_str("This preview mode is not supported"),
            Self::LimitExceeded(s) => write!(f, "Preview limit exceeded: {s}"),
            Self::InvalidData(s) | Self::InvalidRegistry(s) | Self::Io(s) => f.write_str(s),
        }
    }
}
impl std::error::Error for PreviewError {}
pub trait FormatPreview: Sync {
    fn info(&self) -> FormatInfo;
    fn id(&self) -> &'static str {
        self.info().id
    }
    fn extensions(&self) -> &'static [&'static str] {
        self.info().extensions
    }
    fn magic(&self) -> &'static [&'static [u8]] {
        self.info().magic
    }
    fn preview(&self, input: &Input<'_>) -> Result<Output, PreviewError>;
}
/// Generic policy: a non-empty advertised magic wins, then case-insensitive extension.
/// Registry order is deterministic; NUL-bearing bytes cannot enter a text renderer.
pub fn sniff<'a>(
    path: &Path,
    prefix: &[u8],
    formats: &'a [&dyn FormatPreview],
) -> Option<&'a dyn FormatPreview> {
    if let Some(format) = formats.iter().find(|format| {
        format
            .magic()
            .iter()
            .any(|magic| !magic.is_empty() && prefix.starts_with(magic))
    }) {
        return Some(*format);
    }
    let extension = path.extension()?.to_str()?;
    formats.iter().copied().find(|format| {
        format
            .extensions()
            .iter()
            .any(|ext| extension.eq_ignore_ascii_case(ext))
            && (format.info().kind != Kind::Text || !prefix.contains(&0))
    })
}

pub const MAX_ANIMATION_BYTES: usize = 64 * 1024 * 1024;
pub const MAX_ANIMATION_FRAMES: usize = 300;

pub mod math;
pub mod pages;
pub mod worker;
