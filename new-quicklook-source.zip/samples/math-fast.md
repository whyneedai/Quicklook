# Math

Inline $x^2$ and $\frac{1}{2}$ text.

$$\int_0^1 x^2 dx$$
