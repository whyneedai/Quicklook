// Rust preview sample · Unicode: 新预览
/// A tiny example with a block comment.
fn main() {
    let message = "hello from new-quicklook";
    /* block
       comment */
    for i in 0..=9 {
        println!("{message} #{i}");
    }
}
