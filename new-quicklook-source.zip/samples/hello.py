# Python preview · Unicode: 你好，世界
from pathlib import Path

class Preview:
    def __init__(self, name: str):
        self.name = name

    def show(self):
        message = f"Hello, {self.name}!"
        return message

if __name__ == "__main__":
    for index in range(42):
        print(Preview("Windows").show())
