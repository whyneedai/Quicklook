# Stress

Inline $x_{0}^2 + \frac{1}{2}$ and display:

$$\sum_{k=1}^{1} \frac{k}{k+1}$$

Inline $x_{1}^2 + \frac{1}{3}$ and display:

$$\sum_{k=1}^{2} \frac{k}{k+1}$$

Inline $x_{2}^2 + \frac{1}{4}$ and display:

$$\sum_{k=1}^{3} \frac{k}{k+1}$$

Inline $x_{3}^2 + \frac{1}{5}$ and display:

$$\sum_{k=1}^{4} \frac{k}{k+1}$$

Inline $x_{4}^2 + \frac{1}{6}$ and display:

$$\sum_{k=1}^{5} \frac{k}{k+1}$$

Inline $x_{5}^2 + \frac{1}{7}$ and display:

$$\sum_{k=1}^{6} \frac{k}{k+1}$$

Inline $x_{6}^2 + \frac{1}{8}$ and display:

$$\sum_{k=1}^{7} \frac{k}{k+1}$$

Inline $x_{7}^2 + \frac{1}{9}$ and display:

$$\sum_{k=1}^{8} \frac{k}{k+1}$$

Inline $x_{8}^2 + \frac{1}{10}$ and display:

$$\sum_{k=1}^{9} \frac{k}{k+1}$$

Inline $x_{9}^2 + \frac{1}{11}$ and display:

$$\sum_{k=1}^{10} \frac{k}{k+1}$$

Inline $x_{10}^2 + \frac{1}{12}$ and display:

$$\sum_{k=1}^{11} \frac{k}{k+1}$$

Inline $x_{11}^2 + \frac{1}{13}$ and display:

$$\sum_{k=1}^{12} \frac{k}{k+1}$$

Inline $x_{12}^2 + \frac{1}{14}$ and display:

$$\sum_{k=1}^{13} \frac{k}{k+1}$$

Inline $x_{13}^2 + \frac{1}{15}$ and display:

$$\sum_{k=1}^{14} \frac{k}{k+1}$$

Inline $x_{14}^2 + \frac{1}{16}$ and display:

$$\sum_{k=1}^{15} \frac{k}{k+1}$$

Inline $x_{15}^2 + \frac{1}{17}$ and display:

$$\sum_{k=1}^{16} \frac{k}{k+1}$$

Inline $x_{16}^2 + \frac{1}{18}$ and display:

$$\sum_{k=1}^{17} \frac{k}{k+1}$$

Inline $x_{17}^2 + \frac{1}{19}$ and display:

$$\sum_{k=1}^{18} \frac{k}{k+1}$$

Inline $x_{18}^2 + \frac{1}{20}$ and display:

$$\sum_{k=1}^{19} \frac{k}{k+1}$$

Inline $x_{19}^2 + \frac{1}{21}$ and display:

$$\sum_{k=1}^{20} \frac{k}{k+1}$$
