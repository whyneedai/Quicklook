# B1 routing sample

Inline basics: $x^2 + \frac{1}{2}$ and a sum $\sum_{i=1}^{n} i$.

Formerly-whitelisted (now routed through preprocessing):

$$\begin{bmatrix} a & b \\ c & d \end{bmatrix}$$

$$\begin{cases} x & x>0 \\ -x & x\le 0 \end{cases}$$

$$\operatorname{sgn}(x) + \dfrac{1}{2} + \color{red} y$$

$$\begin{aligned} a &= b \\ c &= d \end{aligned}$$
