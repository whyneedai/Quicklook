# Native formula preview

Inline text before $\frac{1}{2}$ and after, then $x^2+y^2=z^2$.

$$
x^2+y^2=z^2
$$

$$
\frac{1}{2}
$$

$$
\sqrt{x+1}
$$

$$
\int_0^1 x^2 dx
$$

$$
\sum_{i=1}^n i
$$

$$
a_1+a_2
$$

$$
e^{i\pi}+1=0
$$

$$
\alpha+\beta=\gamma
$$

$$
\frac{a+b}{c+d}
$$

$$
\sqrt{\frac{a}{b}}
$$

$$
\prod_{i=1}^n i
$$

$$
\lim_{x\to 0}\frac{\sin x}{x}
$$

$$
\sin^2 x+\cos^2 x=1
$$

$$
\log x+\ln y
$$

$$
\partial f/\partial x
$$

$$
\nabla f
$$

$$
a\cdot b
$$

$$
a\times b
$$

$$
x\pm y
$$

$$
x\le y
$$

$$
x\ge y
$$

$$
x\ne y
$$

$$
x\approx y
$$

$$
a\equiv b
$$

$$
\forall x
$$

$$
\exists y
$$

$$
x\in A
$$

$$
A\subset B
$$

$$
A\cup B
$$

$$
A\cap B
$$

$$
\vec{x}
$$

$$
\hat{x}
$$

$$
\bar{x}
$$

$$
\overline{AB}
$$

$$
\underline{x}
$$

$$
\mathrm{sin}(x)
$$

$$
\mathbf{x}
$$

$$
\mathit{abc}
$$

$$
\theta+\lambda+\mu
$$

$$
\Gamma+\Delta+\Omega
$$

Unsupported: $\begin{cases} x \end{cases}$.
