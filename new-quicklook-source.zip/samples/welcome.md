# A quieter way to preview

**new-quicklook** brings fast, native previews to Windows.

## Made for the Space key

- Select a file in Explorer
- Press **Space** to take a look
- Press **Esc** to return to your work

> Small core. Bounded memory. No browser runtime.

### Code belongs here too

```python
def hello(name):
    return f"Hello, {name}!"
```

You can read *emphasis*, **strong text**, and [a safe link label](https://example.com).

---

External images and HTML scripts are never loaded.
