@echo off
:: Source only sample
set "NAME=Preview"
if exist "%TEMP%" (
    echo Hello %NAME%
) else (
    echo Missing temp
)
for %%F in (*.txt) do echo %%F
