// C# sample
public class Preview {
    public static void Main(string[] args) {
        var items = new[] { "Hello", "Preview" };
        foreach (var item in items) Console.WriteLine(item);
    }
}
