// C++ source
#include <string>
class Preview { public: std::string name = "Hello"; };
