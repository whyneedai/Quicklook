# R source
greet <- function(name) {
  if (is.null(name)) return(NA)
  paste("Hello", name)
}
