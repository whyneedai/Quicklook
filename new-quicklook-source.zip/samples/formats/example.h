#ifndef PREVIEW_H
#define PREVIEW_H
int preview(void);
#endif
