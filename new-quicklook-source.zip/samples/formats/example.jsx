// JSX source only
export function Preview() {
  return <section title="Quicklook">Hello</section>;
}
