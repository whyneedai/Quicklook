# Ruby sample
def greet(name)
  items = ["Hello", "Preview"]
  items.each { |x| puts "#{name} #{x}" }
end
