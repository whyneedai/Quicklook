# Module sample
function Get-Sample {
    [CmdletBinding()]
    param([int]$Count = 1)
    return 1..$Count | ForEach-Object { "Item $_" }
}
Export-ModuleMember -Function Get-Sample
