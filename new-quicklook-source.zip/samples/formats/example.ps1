# Source only sample
function Get-Preview {
    param([string]$Name)
    $items = @("Hello", "Preview")
    foreach ($item in $items) {
        Write-Output "$Name $item"
    }
}
<# Block comment
   spans lines #>
Get-Preview -Name "Sample"
