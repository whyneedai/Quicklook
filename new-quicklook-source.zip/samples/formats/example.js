// Source only
export function greet(name) {
  const message = `Hello ${name}`;
  return message;
}
