# Module manifest sample
@{
    RootModule        = 'Sample.psm1'
    ModuleVersion     = '1.0.0'
    GUID              = '00000000-0000-0000-0000-000000000000'
    FunctionsToExport = @('Get-Sample')
}
