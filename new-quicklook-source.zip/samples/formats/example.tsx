// TSX source only
interface Props { name: string; }
export function Preview(p: Props) { return <div>{p.name}</div>; }
