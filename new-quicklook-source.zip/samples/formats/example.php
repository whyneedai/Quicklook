<?php
// Source only
function greet($name) { return "Hello " . $name; }
?>
