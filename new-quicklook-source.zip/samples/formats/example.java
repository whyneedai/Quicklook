// Java
public class Preview {
  public static void main(String[] args) { System.out.println("Hello"); }
}
