package preview
data class Preview(val name: String)
fun greet(p: Preview): String = p.name
