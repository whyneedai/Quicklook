-- Source only
SELECT name, count(*) FROM previews
WHERE enabled = true GROUP BY name;
