// Swift
struct Preview { let name: String }
func greet(_ p: Preview) -> String { return p.name }
