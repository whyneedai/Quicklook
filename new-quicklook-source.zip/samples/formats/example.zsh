#!/bin/zsh
# Zsh sample
setopt extended_glob
autoload -Uz compinit
for f in *.md; do
  print -r -- "$f"
done
