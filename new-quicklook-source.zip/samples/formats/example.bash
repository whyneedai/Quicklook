#!/bin/bash
# Source only
declare -a names=("Hello" "Preview")
for name in "${names[@]}"; do echo "$name"; done
