@echo off
rem Source only sample
setlocal enabledelayedexpansion
set COUNT=0
for %%F in (*.md) do (
    set /a COUNT+=1
    echo !COUNT! %%F
)
if "%COUNT%"=="0" echo No Markdown files
endlocal
