#pragma once
namespace preview { struct Options { bool enabled = true; }; }
