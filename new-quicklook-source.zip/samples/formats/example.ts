// Source only
interface Preview { name: string; }
export const greet = (p: Preview): string => p.name;
