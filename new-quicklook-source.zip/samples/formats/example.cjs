// CommonJS sample
const fs = require("node:fs");
module.exports = function count(file) {
  return fs.readFileSync(file, "utf8").length;
};
