terraform {
  required_version = ">= 1.5"
}
resource "null_resource" "sample" {
  triggers = { name = "preview" }
}
