#!/bin/sh
# Source only
if [ -n "$HOME" ]; then
  printf "%s\n" "Hello"
fi
