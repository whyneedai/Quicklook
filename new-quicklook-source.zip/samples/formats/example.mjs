// ESM sample
import { readFile } from "node:fs/promises";
const data = await readFile("file.txt", "utf8");
export default data.length;
